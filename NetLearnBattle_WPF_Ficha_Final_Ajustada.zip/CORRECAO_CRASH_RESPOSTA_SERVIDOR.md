# Correção crash ao desligar servidor durante resposta

Foi corrigida a exceção `NullReferenceException` quando o servidor era desligado no momento em que o aluno respondia a uma pergunta.

O problema acontecia porque `_currentQuestion` era limpo pelo tratamento de desconexão enquanto o método da resposta ainda estava a usar essa variável para mostrar o resultado.

Correção aplicada:
- a pergunta atual é guardada numa variável local antes do envio para o servidor;
- se o servidor cair, a app mostra a mensagem de ligação perdida e volta ao modo seguro;
- o resultado da pergunta não tenta desenhar por cima da mensagem de desconexão.
