# Correção do painel Servidor/Professor

Foi corrigido o problema em que a zona do professor não deixava claro onde ligar o servidor.

Alterações:
- botão direto no ecrã inicial: “Abrir painel Servidor/Professor”;
- painel do professor redesenhado com botão grande “LIGAR SERVIDOR TCP/UDP”;
- campos visíveis para porta TCP e UDP;
- estado claro: servidor ligado/desligado;
- mostra IP 127.0.0.1 e IP da rede local;
- instruções passo a passo para o aluno ligar;
- mensagem de confirmação ao iniciar servidor;
- logs de atividade do servidor.
