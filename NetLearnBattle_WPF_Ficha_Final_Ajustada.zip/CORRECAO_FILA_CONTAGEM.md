# Correção fila 1v1 e contagem de perguntas

Alterações aplicadas:

- Adicionado botão **Cancelar fila** no ecrã de espera do duelo 1v1.
- Adicionado comando de servidor `DUEL_CANCEL` para remover o aluno da fila/duelo ativo.
- Corrigida contagem duplicada no modo normal: agora a resposta fica bloqueada após o primeiro clique, evitando duplo clique/dupla submissão da mesma pergunta.
- A contagem passa a refletir as 10 perguntas reais respondidas.
