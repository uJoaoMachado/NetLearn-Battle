# Correções aplicadas

- As perguntas, respostas e explicações agora respeitam o idioma selecionado: PT, EN, ES, FR e DE.
- As opções das respostas continuam embaralhadas automaticamente em cada pergunta.
- Os botões "Abrir" dos cartões do menu principal foram uniformizados para a mesma cor principal.
- Os botões secundários também foram ajustados para não ficarem com tons estranhos ou inconsistentes.
