namespace NetLearnBattle.Wpf.Modelos;

public sealed class SessionClassStatistics
{
    public string SessionId { get; set; } = "";
    public string ProfessorId { get; set; } = "";
    public int TotalStudents { get; set; }
    public int ActiveStudents { get; set; }
    public int TotalQuestions { get; set; }
    public int CorrectAnswers { get; set; }
    public double AverageScore { get; set; }
    public DateTime GeneratedAt { get; set; } = DateTime.Now;
    public List<Attempt> SourceAttempts { get; set; } = new();
    public List<ScoreEntry> SourceScores { get; set; } = new();

    public List<Score> GetTopRanking(int top, IEnumerable<Score>? scores = null)
        => new Ranking { Top = top }.GetTopPlayers(scores ?? SourceScores.Select(Score.FromEntry));

    public Dictionary<string, int> GetScoreDistribution()
        => SourceScores
            .GroupBy(s => s.Username, StringComparer.OrdinalIgnoreCase)
            .ToDictionary(g => g.Key, g => g.Sum(s => s.Score), StringComparer.OrdinalIgnoreCase);

    public Dictionary<int, double> GetAccuracyByLevel()
        => SourceAttempts
            .GroupBy(a => a.Level)
            .OrderBy(g => g.Key)
            .ToDictionary(g => g.Key, g => g.Count() == 0 ? 0 : Math.Round(g.Count(a => a.Correct) * 100.0 / g.Count(), 1));

    public Dictionary<string, double> GetAccuracyByType()
        => SourceAttempts
            .GroupBy(a => a.Level switch
            {
                1 => "IPv4",
                2 => "Sub-redes IPv4",
                3 => "Super-redes IPv4",
                4 => "IPv6",
                5 => "ACLs",
                _ => "Geral"
            })
            .ToDictionary(g => g.Key, g => g.Count() == 0 ? 0 : Math.Round(g.Count(a => a.Correct) * 100.0 / g.Count(), 1));

    public TimeSpan GetAverageTime()
        => SourceAttempts.Count == 0 ? TimeSpan.Zero : TimeSpan.FromSeconds(SourceAttempts.Average(a => a.DurationSeconds));

    public TimeSpan GetMedianTime()
    {
        var values = SourceAttempts.Select(a => a.DurationSeconds).OrderBy(x => x).ToList();
        if (!values.Any()) return TimeSpan.Zero;
        var mid = values.Count / 2;
        return TimeSpan.FromSeconds(values.Count % 2 == 1 ? values[mid] : (values[mid - 1] + values[mid]) / 2.0);
    }

    public List<string> GetWeakTopics()
        => SourceAttempts.Where(a => !a.Correct)
            .GroupBy(a => a.Level)
            .OrderByDescending(g => g.Count())
            .Select(g => g.Key switch
            {
                1 => "IPv4 básico",
                2 => "Sub-redes IPv4",
                3 => "Super-redes IPv4",
                4 => "IPv6",
                5 => "ACLs",
                _ => "Geral"
            })
            .Take(5)
            .ToList();

    public static SessionClassStatistics FromAttempts(string sessionId, string professorId, IEnumerable<Attempt> attempts)
    {
        var list = attempts.ToList();
        return new SessionClassStatistics
        {
            SessionId = sessionId,
            ProfessorId = professorId,
            TotalStudents = list.Select(a => a.Username).Distinct(StringComparer.OrdinalIgnoreCase).Count(),
            ActiveStudents = list.Select(a => a.Username).Distinct(StringComparer.OrdinalIgnoreCase).Count(),
            TotalQuestions = list.Count,
            CorrectAnswers = list.Count(a => a.Correct),
            AverageScore = list.Count == 0 ? 0 : Math.Round(list.Average(a => a.Points), 1),
            GeneratedAt = DateTime.Now,
            SourceAttempts = list
        };
    }
}
