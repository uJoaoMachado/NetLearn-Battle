namespace NetLearnBattle.Wpf.Modelos;

public sealed class RankingDto
{
    public string Username { get; set; } = "";
    public int Score { get; set; }
    public int Total { get; set; }
    public int Correct { get; set; }
}
