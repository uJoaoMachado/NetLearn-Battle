namespace NetLearnBattle.Wpf.Modelos;

public sealed class Ranking
{
    public int Top { get; set; } = 5;

    public List<Score> GetTopPlayers(IEnumerable<Score> scores)
        => scores
            .OrderByDescending(s => s.BestScore)
            .ThenBy(s => s.Username)
            .Take(Top)
            .ToList();
}
