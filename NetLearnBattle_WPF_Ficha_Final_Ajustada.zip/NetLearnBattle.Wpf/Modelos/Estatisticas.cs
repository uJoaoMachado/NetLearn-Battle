namespace NetLearnBattle.Wpf.Modelos;

public sealed class Statistics
{
    public string UserId { get; set; } = "";
    public string SessionId { get; set; } = "";
    public int TotalQuestions { get; set; }
    public int CorrectAnswers { get; set; }
    public TimeSpan TotalTime { get; set; }
    public List<Attempt> SourceAttempts { get; set; } = new();

    public double GetAccuracy() => TotalQuestions == 0 ? 0 : Math.Round((double)CorrectAnswers / TotalQuestions * 100, 1);

    public TimeSpan GetAverageTime()
        => TotalQuestions == 0 ? TimeSpan.Zero : TimeSpan.FromSeconds(SourceAttempts.Any() ? SourceAttempts.Average(a => a.DurationSeconds) : TotalTime.TotalSeconds / TotalQuestions);

    public TimeSpan GetMedianTime()
    {
        var values = SourceAttempts.Select(a => a.DurationSeconds).Where(x => x >= 0).OrderBy(x => x).ToList();
        if (!values.Any()) return TimeSpan.Zero;
        var mid = values.Count / 2;
        var median = values.Count % 2 == 1 ? values[mid] : (values[mid - 1] + values[mid]) / 2.0;
        return TimeSpan.FromSeconds(median);
    }

    public TimeSpan GetModeTime()
    {
        var mode = SourceAttempts
            .Select(a => a.DurationSeconds)
            .Where(x => x >= 0)
            .GroupBy(x => x)
            .OrderByDescending(g => g.Count())
            .ThenBy(g => g.Key)
            .FirstOrDefault()?.Key ?? 0;
        return TimeSpan.FromSeconds(mode);
    }

    public Dictionary<int, double> GetAccuracyByLevel()
        => SourceAttempts
            .GroupBy(a => a.Level)
            .OrderBy(g => g.Key)
            .ToDictionary(g => g.Key, g => g.Count() == 0 ? 0 : Math.Round(g.Count(a => a.Correct) * 100.0 / g.Count(), 1));

    public List<Score> GetScoreEvolution()
    {
        var total = 0;
        return SourceAttempts
            .OrderBy(a => a.AnsweredAt)
            .Select(a =>
            {
                total += a.Points;
                return new Score
                {
                    Id = a.Id,
                    UserId = a.Username,
                    Username = a.Username,
                    CurrentScore = total,
                    BestScore = total,
                    LastUpdated = a.AnsweredAt
                };
            })
            .ToList();
    }

    public List<string> GetWeakTopics()
        => SourceAttempts
            .Where(a => !a.Correct)
            .GroupBy(a => a.Level)
            .OrderByDescending(g => g.Count())
            .ThenBy(g => g.Key)
            .Select(g => g.Key switch
            {
                1 => "IPv4 básico (/8, /16, /24)",
                2 => "Sub-redes IPv4",
                3 => "Super-redes / sumarização IPv4",
                4 => "IPv6",
                5 => "ACLs",
                _ => "Geral"
            })
            .Distinct()
            .Take(5)
            .ToList();

    public static Statistics FromAttempts(string userId, IEnumerable<Attempt> attempts)
    {
        var list = attempts.Where(a => a.Username.Equals(userId, StringComparison.OrdinalIgnoreCase) || a.Username == userId).ToList();
        return new Statistics
        {
            UserId = userId,
            TotalQuestions = list.Count,
            CorrectAnswers = list.Count(a => a.Correct),
            TotalTime = TimeSpan.FromSeconds(list.Sum(a => a.DurationSeconds)),
            SourceAttempts = list
        };
    }
}
