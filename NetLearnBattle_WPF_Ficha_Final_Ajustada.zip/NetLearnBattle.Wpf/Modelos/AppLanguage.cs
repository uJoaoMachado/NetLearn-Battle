namespace NetLearnBattle.Wpf.Modelos;

public enum AppLanguage
{
    PT,
    EN,
    ES,
    FR,
    DE,
    LT
}
