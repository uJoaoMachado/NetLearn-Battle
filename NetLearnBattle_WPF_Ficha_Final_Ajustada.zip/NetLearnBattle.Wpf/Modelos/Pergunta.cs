namespace NetLearnBattle.Wpf.Modelos;

public sealed class Question
{
    public string Id { get; set; } = Guid.NewGuid().ToString("N");
    public int Level { get; set; }
    public string Type { get; set; } = "";
    public string Text { get; set; } = "";
    public List<string> Options { get; set; } = new();
    public int CorrectAnswerIndex { get; set; }
    public int CorrectIndex
    {
        get => CorrectAnswerIndex;
        set => CorrectAnswerIndex = value;
    }
    public int PointsCorrect { get; set; }
    public int PointsWrong { get; set; }
    public string Explanation { get; set; } = "";

    public bool IsCorrect(int answerIndex) => answerIndex == CorrectAnswerIndex;
}
