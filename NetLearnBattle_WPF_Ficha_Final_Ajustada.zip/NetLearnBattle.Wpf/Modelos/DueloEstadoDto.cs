namespace NetLearnBattle.Wpf.Modelos;

public sealed class DuelStateDto
{
    public string Status { get; set; } = "WAIT";
    public string RoomId { get; set; } = "";
    public int Level { get; set; }
    public int Round { get; set; }
    public string Player1 { get; set; } = "";
    public string Player2 { get; set; } = "";
    public int Score1 { get; set; }
    public int Score2 { get; set; }
    public string Question { get; set; } = "";
    public List<string> Options { get; set; } = new();
    public int CorrectIndex { get; set; } = -1;
    public string LastResult { get; set; } = "";
}
