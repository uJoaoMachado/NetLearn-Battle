namespace NetLearnBattle.Wpf.Modelos;

// Representa a entidade User do diagrama de classes.
// Mantém-se concreta para permitir guardar/carregar diretamente de users.json.
public class User
{
    public string Id { get; set; } = Guid.NewGuid().ToString("N");
    public string Username { get; set; } = "";
    public string PasswordHash { get; set; } = "";
    public string Salt { get; set; } = "";
    public Role Role { get; set; } = Role.Student;
    public DateTime CreatedAt { get; set; } = DateTime.Now;

    public bool Register(string username, string password)
    {
        if (string.IsNullOrWhiteSpace(username) || string.IsNullOrWhiteSpace(password)) return false;
        Username = username.Trim();
        PasswordHash = password;
        CreatedAt = DateTime.Now;
        return true;
    }

    public bool Login(string username, string password)
        => Username.Equals(username, StringComparison.OrdinalIgnoreCase) && PasswordHash == password;

    public string GetRole() => Role.ToString();
}

public sealed class Student : User
{
    public string EnrollmentId { get; set; } = "";
    public Statistics GetStatistics(IEnumerable<Attempt> attempts)
        => Statistics.FromAttempts(Username, attempts);
}

public sealed class Professor : User
{
    public GameSession CreateServer(ProtocolMode protocol, int port)
        => new()
        {
            HostUserId = Id,
            Protocol = protocol,
            Port = port,
            Mode = "Network",
            Status = "Waiting",
            CreatedAt = DateTime.Now
        };

    public SessionClassStatistics ViewClassStatistics(string sessionId, IEnumerable<Attempt> attempts)
        => SessionClassStatistics.FromAttempts(sessionId, Id, attempts);

    public void ManageQuestions() { }
    public void ManageACLs() { }
    public void ViewReports() { }
}

public sealed class Visitor : User
{
    public List<Score> ViewTopRanking(IEnumerable<Score> scores)
        => new Ranking().GetTopPlayers(scores);

    public string ViewRules()
        => "Guest apenas pode consultar Ranking Top 5 e Regras.";
}
