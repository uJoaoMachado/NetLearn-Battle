namespace NetLearnBattle.Wpf.Modelos;

public enum Role
{
    Guest,
    Student,
    Teacher
}
