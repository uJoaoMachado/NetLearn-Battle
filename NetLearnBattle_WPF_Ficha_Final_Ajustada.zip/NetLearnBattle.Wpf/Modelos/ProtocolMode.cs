namespace NetLearnBattle.Wpf.Modelos;

public enum ProtocolMode
{
    TCP,
    UDP
}
