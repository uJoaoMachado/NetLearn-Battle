namespace NetLearnBattle.Wpf.Modelos;

public sealed class ScoreEntry
{
    public string Id { get; set; } = Guid.NewGuid().ToString("N");
    public string Username { get; set; } = "";
    public int Score { get; set; }
    public int Correct { get; set; }
    public int Total { get; set; }
    public DateTime Date { get; set; } = DateTime.Now;
}

public sealed class Score
{
    public string Id { get; set; } = Guid.NewGuid().ToString("N");
    public string UserId { get; set; } = "";
    public string Username { get; set; } = "";
    public int CurrentScore { get; set; }
    public int BestScore { get; set; }
    public DateTime LastUpdated { get; set; } = DateTime.Now;

    public void AddPoints(int points)
    {
        CurrentScore += points;
        if (CurrentScore > BestScore) BestScore = CurrentScore;
        LastUpdated = DateTime.Now;
    }

    public void ResetScore()
    {
        CurrentScore = 0;
        LastUpdated = DateTime.Now;
    }

    public static Score FromEntry(ScoreEntry entry) => new()
    {
        Id = entry.Id,
        UserId = entry.Username,
        Username = entry.Username,
        CurrentScore = entry.Score,
        BestScore = entry.Score,
        LastUpdated = entry.Date
    };
}
