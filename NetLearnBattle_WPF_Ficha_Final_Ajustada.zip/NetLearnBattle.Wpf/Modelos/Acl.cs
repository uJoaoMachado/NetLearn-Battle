namespace NetLearnBattle.Wpf.Modelos;

public sealed class ACL
{
    public string Id { get; set; } = Guid.NewGuid().ToString("N");
    public string Name { get; set; } = "";
    public string Description { get; set; } = "";
    public List<ACLRule> Rules { get; set; } = new();

    public string Evaluate(Packet packet)
    {
        foreach (var rule in Rules.OrderBy(r => r.Order))
        {
            if (rule.Matches(packet)) return rule.Action;
        }
        return "deny";
    }
}

public sealed class ACLRule
{
    public string Id { get; set; } = Guid.NewGuid().ToString("N");
    public string Action { get; set; } = "permit";
    public string Protocol { get; set; } = "ip";
    public string SourceIp { get; set; } = "any";
    public string SourcePort { get; set; } = "any";
    public string DestinationIp { get; set; } = "any";
    public string DestinationPort { get; set; } = "any";
    public int Order { get; set; }

    public bool Matches(Packet packet)
    {
        bool protocolOk = Protocol == "ip" || Protocol.Equals(packet.Protocol, StringComparison.OrdinalIgnoreCase);
        bool sourceIpOk = SourceIp == "any" || SourceIp == packet.SourceIp;
        bool destIpOk = DestinationIp == "any" || DestinationIp == packet.DestinationIp;
        bool sourcePortOk = SourcePort == "any" || SourcePort == packet.SourcePort;
        bool destPortOk = DestinationPort == "any" || DestinationPort == packet.DestinationPort;
        return protocolOk && sourceIpOk && destIpOk && sourcePortOk && destPortOk;
    }
}

public sealed class Packet
{
    public string SourceIp { get; set; } = "";
    public string DestinationIp { get; set; } = "";
    public string Protocol { get; set; } = "tcp";
    public string SourcePort { get; set; } = "";
    public string DestinationPort { get; set; } = "";
}
