namespace NetLearnBattle.Wpf.Modelos;

public sealed class DuelJoinDto
{
    public string Username { get; set; } = "";
    public int Level { get; set; } = 1;
}
