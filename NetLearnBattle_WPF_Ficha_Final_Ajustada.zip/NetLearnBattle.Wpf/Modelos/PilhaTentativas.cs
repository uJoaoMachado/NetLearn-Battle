namespace NetLearnBattle.Wpf.Modelos;

public sealed class AttemptStack
{
    public string SessionId { get; set; } = "";
    public Stack<Attempt> Stack { get; set; } = new();
    public IEnumerable<Attempt> Items => Stack;

    public void Push(Attempt attempt) => Stack.Push(attempt);
    public Attempt Pop() => Stack.Pop();
    public Attempt? Peek() => Stack.Count == 0 ? null : Stack.Peek();
    public bool IsEmpty() => Stack.Count == 0;
    public int Size() => Stack.Count;
}
