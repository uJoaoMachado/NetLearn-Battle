namespace NetLearnBattle.Wpf.Modelos;

public sealed class DuelRankDto
{
    public string Username { get; set; } = "";
    public int Points { get; set; }
    public int Wins { get; set; }
    public int Losses { get; set; }
    public int Draws { get; set; }
    public int Matches { get; set; }
    public string Rank { get; set; } = "Bronze";
}
