namespace NetLearnBattle.Wpf.Modelos;

public sealed class QuestionQueue
{
    public string SessionId { get; set; } = "";
    public int Level { get; set; }
    public Queue<Question> Queue { get; set; } = new();

    public void Enqueue(Question question) => Queue.Enqueue(question);
    public Question Dequeue() => Queue.Dequeue();
    public Question? Peek() => Queue.Count == 0 ? null : Queue.Peek();
    public bool IsEmpty() => Queue.Count == 0;
    public int Size() => Queue.Count;
}
