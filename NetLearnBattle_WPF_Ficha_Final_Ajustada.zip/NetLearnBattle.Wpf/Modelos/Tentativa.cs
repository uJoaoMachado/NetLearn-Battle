namespace NetLearnBattle.Wpf.Modelos;

public sealed class Attempt
{
    public string Id { get; set; } = Guid.NewGuid().ToString("N");
    public string SessionId { get; set; } = "";
    public string Username { get; set; } = "";
    public string QuestionId { get; set; } = "";
    public string Question { get; set; } = "";
    public int SelectedAnswerIndex { get; set; }
    public int CorrectAnswerIndex { get; set; }
    public string Answer { get; set; } = "";
    public bool Correct { get; set; }
    public int Level { get; set; }
    public int Points { get; set; }
    public int DurationSeconds { get; set; }
    public TimeSpan TimeTaken { get; set; }
    public DateTime AnsweredAt { get; set; } = DateTime.Now;
    public DateTime Date
    {
        get => AnsweredAt;
        set => AnsweredAt = value;
    }
}
