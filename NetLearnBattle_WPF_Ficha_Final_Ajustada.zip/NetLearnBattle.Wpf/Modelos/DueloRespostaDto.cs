namespace NetLearnBattle.Wpf.Modelos;

public sealed class DuelAnswerDto
{
    public string RoomId { get; set; } = "";
    public string Username { get; set; } = "";
    public int SelectedIndex { get; set; }
}
