namespace NetLearnBattle.Wpf.Modelos;

public sealed class NetworkAttemptDto
{
    public string Id { get; set; } = Guid.NewGuid().ToString("N");
    public string Username { get; set; } = "";
    public int Level { get; set; }
    public string Question { get; set; } = "";
    public string Answer { get; set; } = "";
    public bool Correct { get; set; }
    public int DurationSeconds { get; set; }
    public int Score { get; set; }
    public DateTime Date { get; set; } = DateTime.Now;
}
