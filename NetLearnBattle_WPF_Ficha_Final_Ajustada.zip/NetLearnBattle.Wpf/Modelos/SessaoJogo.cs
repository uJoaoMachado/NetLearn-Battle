namespace NetLearnBattle.Wpf.Modelos;

public sealed class GameSession
{
    public string Id { get; set; } = Guid.NewGuid().ToString("N");
    public string HostUserId { get; set; } = "";
    public ProtocolMode Protocol { get; set; } = ProtocolMode.TCP;
    public string IP { get; set; } = "127.0.0.1";
    public int Port { get; set; } = 5000;
    public string Mode { get; set; } = "Single";
    public int Level { get; set; } = 1;
    public DateTime CreatedAt { get; set; } = DateTime.Now;
    public DateTime? StartedAt { get; set; }
    public DateTime? EndedAt { get; set; }
    public string Status { get; set; } = "Waiting";
    public QuestionQueue Questions { get; set; } = new();
    public AttemptStack Attempts { get; set; } = new();

    public void Start()
    {
        StartedAt = DateTime.Now;
        Status = "InProgress";
    }

    public void End()
    {
        EndedAt = DateTime.Now;
        Status = "Finished";
    }

    public TimeSpan GetDuration()
        => (EndedAt ?? DateTime.Now) - (StartedAt ?? CreatedAt);

    public SessionClassStatistics GetStatistics()
        => SessionClassStatistics.FromAttempts(Id, HostUserId, Attempts.Items);
}
