namespace NetLearnBattle.Wpf.Modelos;

public sealed class AppSettings
{
    public AppLanguage Language { get; set; } = AppLanguage.PT;
    public string Background { get; set; } = "#07061A";
    public string Card { get; set; } = "#12103A";
    public string Button { get; set; } = "#7C3AED";
    public string Accent { get; set; } = "#06B6D4";
    public double FontSize { get; set; } = 15;
}
