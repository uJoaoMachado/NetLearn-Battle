using System;
using System.Net.Sockets;
using System.Windows;
using System.Windows.Threading;
using System.Threading.Tasks;

namespace NetLearnBattle.Wpf;

public partial class App : Application
{
    protected override void OnStartup(StartupEventArgs e)
    {
        base.OnStartup(e);
        DispatcherUnhandledException += App_DispatcherUnhandledException;
        AppDomain.CurrentDomain.UnhandledException += (_, __) => { };
        TaskScheduler.UnobservedTaskException += (_, args) =>
        {
            args.SetObserved();
        };
    }

    private void App_DispatcherUnhandledException(object sender, DispatcherUnhandledExceptionEventArgs e)
    {
        e.Handled = true;
        try
        {
            if (MainWindow is MainWindow mw)
            {
                mw.ForceSafeServerLost();
                return;
            }
        }
        catch { }

        MessageBox.Show(
            "O servidor foi desligado ou a ligação caiu. As atividades online foram fechadas e podes continuar no modo seguro.",
            "Ligação perdida",
            MessageBoxButton.OK,
            MessageBoxImage.Warning);
    }
}
