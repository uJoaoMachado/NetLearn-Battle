using System;
using System.Collections.Generic;
using System.IO;
using System.Net;
using System.Net.Sockets;
using System.Net.NetworkInformation;
using System.Text;
using System.Text.Json;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Media;
using System.Windows.Threading;
using NetLearnBattle.Wpf.Modelos;
using NetLearnBattle.Wpf.Servicos;

namespace NetLearnBattle.Wpf;

public partial class MainWindow : Window
{
    private readonly JsonStore _store = new();
    private readonly QuestionGenerator _questions = new();
    private readonly LocalServer _server = new();
    private User? _current;
    private Question? _currentQuestion;
    private Queue<Question> _sessionQuestions = new();
    private int _sessionLevel;
    private int _sessionIndex;
    private int _sessionScore;
    private DateTime _questionStart;
    private AppSettings _settings;
    private ListBox? _serverLog;
    private string _connectedHost = "127.0.0.1";
    private int _connectedPort = 5000;
    private ProtocolMode _connectedProtocol = ProtocolMode.TCP;
    private bool _connectionOk;
    private int _lastTcpPort = 5000;
    private int _lastUdpPort = 5001;
    private DispatcherTimer? _onlineDuelTimer;
    private DuelStateDto? _onlineDuel;
    private DispatcherTimer? _serverMonitorTimer;
    private bool _answerLocked;

    private readonly Dictionary<string, (string Bg, string Card, string Button, string Accent)> _themes = new()
    {
        ["Roxo moderno"] = ("#07061A", "#12103A", "#7C3AED", "#06B6D4"),
        ["Azul profissional"] = ("#071827", "#0F2A3D", "#2563EB", "#38BDF8"),
        ["Verde técnico"] = ("#04110B", "#0B2317", "#16A34A", "#22C55E"),
        ["Claro limpo"] = ("#F4F7FB", "#FFFFFF", "#2563EB", "#0891B2"),
        ["Preto azul"] = ("#050505", "#151515", "#2563EB", "#38BDF8")
    };

    public MainWindow()
    {
        InitializeComponent();
        _settings = SanitizeSettings(_store.Settings);
        _store.Settings = _settings;
        _server.Log += msg => Dispatcher.Invoke(() => _serverLog?.Items.Insert(0, $"{DateTime.Now:HH:mm:ss}  {msg}"));
        _server.DataChanged += () => Dispatcher.Invoke(() => { if (_current?.Role == Role.Teacher) ApplySettings(); });
        ApplySettings();
        ShowLogin();
    }
}
