using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.NetworkInformation;
using System.Net.Sockets;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Media;
using System.Windows.Threading;
using NetLearnBattle.Wpf.Modelos;
using NetLearnBattle.Wpf.Servicos;

namespace NetLearnBattle.Wpf;

public partial class MainWindow : Window
{
    private void ShowTraining()
    {
        if (_current?.Role != Role.Student) { ShowHome(); return; }
        Clear();
        ViewHost.Children.Add(Txt("🧠 " + T("Modo treino", "Training mode", "Modo entrenamiento", "Mode entraînement", "Trainingsmodus"), 36, FontWeights.Black));
        ViewHost.Children.Add(Txt(T("Funciona mesmo sem servidor. Não altera ranking nem estatísticas oficiais.", "Works even without a server. It does not change ranking or official statistics.", "Funciona incluso sin servidor. No cambia ranking ni estadísticas oficiales.", "Fonctionne même sans serveur. Ne modifie pas le classement ni les statistiques officielles.", "Funktioniert auch ohne Server. Ändert Rangliste und offizielle Statistiken nicht."), 16, FontWeights.Bold, "#FDE68A"));

        var root = new StackPanel { Margin = new Thickness(0, 18, 0, 0) };
        var myUniqueAttempts = UniqueAttempts(_store.Attempts.Where(a => a.Username.Equals(_current.Username, StringComparison.OrdinalIgnoreCase)));
        var failedCount = myUniqueAttempts.Count(a => !a.Correct);
        root.Children.Add(Txt(T("Escolhe como queres treinar:", "Choose how you want to train:", "Elige cómo quieres entrenar:", "Choisis comment t'entraîner :", "Wähle dein Training:"), 22, FontWeights.Black));
        root.Children.Add(Txt(T($"Perguntas falhadas guardadas: {failedCount}", $"Saved failed questions: {failedCount}", $"Preguntas falladas guardadas: {failedCount}", $"Questions ratées enregistrées : {failedCount}", $"Gespeicherte falsche Fragen: {failedCount}"), 15, null, "#9A94C7"));

        var wrap = new WrapPanel { Margin = new Thickness(0, 14, 0, 0) };
        for (int i = 1; i <= 5; i++)
        {
            int level = i;
            var card = new StackPanel { Width = 245 };
            card.Children.Add(Txt($"{T("Nível", "Level", "Nivel", "Niveau", "Level")} {level}", 24, FontWeights.Black));
            card.Children.Add(Txt(LevelName(level), 14, null, "#9A94C7"));
            card.Children.Add(Txt(T("10 perguntas aleatórias de treino", "10 random training questions", "10 preguntas aleatorias de entrenamiento", "10 questions aléatoires d'entraînement", "10 zufällige Trainingsfragen"), 13, null, "#9A94C7"));
            card.Children.Add(Btn(T("Treinar nível", "Train level", "Entrenar nivel", "Entraîner niveau", "Level trainieren"), (_, __) => StartTraining(level, false)));
            wrap.Children.Add(Card(card, new Thickness(0, 0, 14, 14)));
        }
        root.Children.Add(wrap);
        root.Children.Add(Btn(T("Treinar só perguntas falhadas", "Train only failed questions", "Entrenar solo preguntas falladas", "Réviser seulement les questions ratées", "Nur falsche Fragen trainieren"), (_, __) => StartTraining(1, true), false));
        ViewHost.Children.Add(Card(root));
    }

    private void StartTraining(int level, bool onlyFailed)
    {
        _sessionIndex = 0;
        _sessionScore = 0;
        if (onlyFailed)
        {
            var failedLevels = _store.Attempts
                .Where(a => _current is not null && a.Username.Equals(_current.Username, StringComparison.OrdinalIgnoreCase) && !a.Correct)
                .Select(a => Math.Clamp(a.Level, 1, 5))
                .Distinct()
                .OrderBy(_ => Random.Shared.Next())
                .ToList();

            if (!failedLevels.Any())
            {
                failedLevels.Add(1);
            }

            var training = new List<Question>();
            while (training.Count < 10)
            {
                foreach (var failedLevel in failedLevels.OrderBy(_ => Random.Shared.Next()))
                {
                    training.AddRange(_questions.GenerateSet(failedLevel, 2, _settings.Language));
                    if (training.Count >= 10) break;
                }
            }

            _sessionQuestions = new Queue<Question>(training.OrderBy(_ => Random.Shared.Next()).Take(10));
        }
        else
        {
            _sessionLevel = level;
            _sessionQuestions = new Queue<Question>(_questions.GenerateSet(level, 10, _settings.Language));
        }
        AskNextTraining();
    }

    private void AskNextTraining()
    {
        if (_sessionQuestions.Count == 0)
        {
            Clear();
            var done = new StackPanel();
            done.Children.Add(Txt("✅ " + T("Treino terminado", "Training finished", "Entrenamiento terminado", "Entraînement terminé", "Training beendet"), 36, FontWeights.Black));
            done.Children.Add(Txt(T("O treino não alterou o ranking. Podes repetir para consolidar.", "Training did not change the ranking. You can repeat it to consolidate.", "El entrenamiento no cambió el ranking. Puedes repetir para consolidar.", "L'entraînement n'a pas modifié le classement. Tu peux répéter pour consolider.", "Training hat die Rangliste nicht geändert. Du kannst wiederholen."), 17, null, "#9A94C7"));
            done.Children.Add(Btn(T("Voltar ao treino", "Back to training", "Volver al entrenamiento", "Retour à l'entraînement", "Zurück zum Training"), (_, __) => ShowTraining()));
            ViewHost.Children.Add(Card(done));
            return;
        }
        _currentQuestion = _sessionQuestions.Dequeue();
        _answerLocked = false;
        _sessionIndex++;
        Clear();
        var sp = new StackPanel();
        sp.Children.Add(Txt(T("Treino", "Training", "Entrenamiento", "Entraînement", "Training") + $" · {_sessionIndex}/10", 15, FontWeights.Bold, _settings.Accent));
        sp.Children.Add(Txt(_currentQuestion.Text, 30, FontWeights.Black));
        var answerButtons = new List<Button>();
        var feedback = new StackPanel { Margin = new Thickness(0, 14, 0, 0) };
        for (int i = 0; i < _currentQuestion.Options.Count; i++)
        {
            int ix = i;
            var btn = Btn($"{(char)('A' + i)}. {_currentQuestion.Options[i]}", (_, __) =>
            {
                foreach (var ab in answerButtons) ab.IsEnabled = false;
                var ok = ix == _currentQuestion.CorrectIndex;
                feedback.Children.Clear();
                feedback.Children.Add(Txt(ok ? "✅ " + T("Certo!", "Correct!", "¡Correcto!", "Correct !", "Richtig!") : "❌ " + T("Errado.", "Wrong.", "Incorrecto.", "Faux.", "Falsch."), 24, FontWeights.Black, ok ? "#86EFAC" : "#FCA5A5"));
                feedback.Children.Add(Txt(T("Resposta correta: ", "Correct answer: ", "Respuesta correcta: ", "Bonne réponse : ", "Richtige Antwort: ", "Teisingas atsakymas: ") + _currentQuestion.Options[_currentQuestion.CorrectIndex], 16, FontWeights.Bold, "#EDE9FF"));
                feedback.Children.Add(Txt(T("Explicação da matéria:", "Topic explanation:", "Explicación de la materia:", "Explication du sujet :", "Erklärung des Themas:", "Temos paaiškinimas:"), 16, FontWeights.Bold, _settings.Accent));
                feedback.Children.Add(Txt(BuildTrainingExplanation(_currentQuestion, ok), 15, null, "#C4B5FD"));
                feedback.Children.Add(Txt(_currentQuestion.Explanation, 15, null, "#9A94C7"));
                feedback.Children.Add(Btn(T("Próxima pergunta", "Next question", "Siguiente pregunta", "Question suivante", "Nächste Frage", "Kitas klausimas"), (_, ___) => AskNextTraining()));
            }, false);
            answerButtons.Add(btn);
            sp.Children.Add(btn);
        }
        sp.Children.Add(feedback);
        ViewHost.Children.Add(Card(sp));
    }


    private string BuildTrainingExplanation(Question question, bool wasCorrect)
    {
        var correctAnswer = question.Options.ElementAtOrDefault(question.CorrectIndex) ?? "";
        var intro = wasCorrect
            ? T("Respondeste bem. O importante agora é perceber a regra para conseguires repetir o raciocínio noutros exercícios.",
                "You answered correctly. The important part now is understanding the rule so you can repeat the reasoning in other exercises.",
                "Has respondido bien. Lo importante ahora es entender la regla para repetir el razonamiento en otros ejercicios.",
                "Tu as bien répondu. L'important est maintenant de comprendre la règle pour refaire le raisonnement dans d'autres exercices.",
                "Du hast richtig geantwortet. Wichtig ist jetzt, die Regel zu verstehen, damit du die Überlegung in anderen Aufgaben wiederholen kannst.",
                "Atsakei teisingai. Dabar svarbiausia suprasti taisyklę, kad galėtum tokį patį mąstymą pritaikyti kitose užduotyse.")
            : T("A resposta não foi a correta, mas este é precisamente o objetivo do treino: perceber o erro e corrigir o raciocínio.",
                "The answer was not correct, but that is exactly the purpose of training: understand the mistake and correct the reasoning.",
                "La respuesta no fue correcta, pero ese es precisamente el objetivo del entrenamiento: entender el error y corregir el razonamiento.",
                "La réponse n'était pas correcte, mais c'est précisément le but de l'entraînement : comprendre l'erreur et corriger le raisonnement.",
                "Die Antwort war nicht richtig, aber genau dafür ist das Training da: den Fehler verstehen und die Denkweise korrigieren.",
                "Atsakymas nebuvo teisingas, tačiau tam ir skirtas treniravimasis: suprasti klaidą ir pataisyti mąstymą.");

        var rule = question.Level switch
        {
            1 => T("Neste nível trabalhas endereçamento IPv4 básico. Observa o prefixo: /8 usa o primeiro octeto para a rede, /16 usa os dois primeiros e /24 usa os três primeiros. A parte que sobra identifica hosts dentro dessa rede.",
                "This level focuses on basic IPv4 addressing. Watch the prefix: /8 uses the first octet for the network, /16 uses the first two, and /24 uses the first three. The remaining part identifies hosts inside that network.",
                "En este nivel trabajas direccionamiento IPv4 básico. Mira el prefijo: /8 usa el primer octeto para la red, /16 usa los dos primeros y /24 usa los tres primeros. La parte restante identifica hosts dentro de esa red.",
                "Dans ce niveau tu travailles l'adressage IPv4 de base. Regarde le préfixe : /8 utilise le premier octet pour le réseau, /16 les deux premiers et /24 les trois premiers. Le reste identifie les hôtes du réseau.",
                "In diesem Level geht es um grundlegende IPv4-Adressierung. Achte auf das Präfix: /8 nutzt das erste Oktett für das Netz, /16 die ersten zwei und /24 die ersten drei. Der Rest identifiziert Hosts im Netz.",
                "Šiame lygyje mokomasi pagrindinio IPv4 adresavimo. Žiūrėk į prefiksą: /8 tinklui naudoja pirmą oktetą, /16 – pirmus du, o /24 – pirmus tris. Likusi dalis skirta hostams tame tinkle."),
            2 => T("Neste nível a chave é o tamanho do bloco. Depois de saberes o prefixo, calculas quantos bits sobram para endereços e obténs o salto entre sub-redes. Esse salto ajuda a encontrar a rede correta de qualquer IP.",
                "Here the key is the block size. After reading the prefix, calculate how many address bits remain and you get the jump between subnets. That jump helps you find the correct network for any IP.",
                "Aquí la clave es el tamaño del bloque. Después de leer el prefijo, calcula cuántos bits quedan para direcciones y obtienes el salto entre subredes. Ese salto te ayuda a encontrar la red correcta de cualquier IP.",
                "Ici la clé est la taille du bloc. Après avoir lu le préfixe, calcule combien de bits restent pour les adresses et tu obtiens le pas entre les sous-réseaux. Ce pas aide à trouver le bon réseau.",
                "Hier ist die Blockgröße entscheidend. Aus dem Präfix berechnest du, wie viele Adressbits übrig bleiben, und erhältst den Sprung zwischen Subnetzen. Damit findest du das passende Netz.",
                "Šiame lygyje svarbiausias yra bloko dydis. Pagal prefiksą apskaičiuoji, kiek bitų lieka adresams, ir gauni potinklių žingsnį. Šis žingsnis padeda rasti teisingą IP tinklą."),
            3 => T("Na sumarização juntas várias redes consecutivas numa só rota maior. Quanto mais redes /24 juntares, menor fica o prefixo. A ideia é reduzir várias entradas de routing para uma entrada única e correta.",
                "Summarization combines several consecutive networks into one larger route. The more /24 networks you combine, the smaller the prefix becomes. The goal is to replace multiple routing entries with one correct entry.",
                "La sumarización une varias redes consecutivas en una ruta mayor. Cuantas más redes /24 juntes, menor será el prefijo. La idea es reducir varias entradas de routing a una entrada única correcta.",
                "La summarisation regroupe plusieurs réseaux consécutifs dans une route plus grande. Plus tu regroupes de réseaux /24, plus le préfixe diminue. L'objectif est de remplacer plusieurs routes par une seule entrée correcte.",
                "Bei der Zusammenfassung werden mehrere aufeinanderfolgende Netze zu einer größeren Route kombiniert. Je mehr /24-Netze du zusammenfasst, desto kleiner wird das Präfix. Ziel ist eine einzige korrekte Routing-Route.",
                "Apibendrinimas sujungia kelis nuoseklius tinklus į vieną didesnį maršrutą. Kuo daugiau /24 tinklų sujungiama, tuo mažesnis tampa prefiksas. Tikslas – kelis maršrutus pakeisti vienu teisingu įrašu."),
            4 => T("No IPv6 não existe broadcast como no IPv4. O raciocínio principal é identificar a parte da rede pelo prefixo, normalmente agrupando blocos hexadecimais e completando a parte de host com zeros.",
                "IPv6 does not use broadcast like IPv4. The main reasoning is identifying the network part from the prefix, usually grouping hexadecimal blocks and filling the host part with zeros.",
                "En IPv6 no existe broadcast como en IPv4. El razonamiento principal es identificar la parte de red por el prefijo, normalmente agrupando bloques hexadecimales y rellenando la parte de host con ceros.",
                "En IPv6 il n'y a pas de broadcast comme en IPv4. Le raisonnement consiste à identifier la partie réseau par le préfixe, souvent en groupant les blocs hexadécimaux et en mettant la partie hôte à zéro.",
                "In IPv6 gibt es kein Broadcast wie in IPv4. Wichtig ist, anhand des Präfixes den Netzanteil zu erkennen, meist durch Gruppieren hexadezimaler Blöcke und Nullen im Hostanteil.",
                "IPv6 neturi broadcast kaip IPv4. Pagrindinė logika – pagal prefiksą nustatyti tinklo dalį, dažniausiai grupuojant šešioliktainius blokus ir host dalį užpildant nuliais."),
            _ => T("Nas ACLs a ordem das regras é essencial. O equipamento lê as regras de cima para baixo e aplica a primeira que corresponde ao tráfego. Por isso, uma regra permit ou deny no sítio errado pode mudar completamente o resultado.",
                "In ACLs, rule order is essential. The device reads rules from top to bottom and applies the first one that matches the traffic. Therefore a permit or deny rule in the wrong place can completely change the result.",
                "En las ACL el orden de las reglas es esencial. El equipo lee las reglas de arriba hacia abajo y aplica la primera que coincide con el tráfico. Por eso, una regla permit o deny mal colocada puede cambiar totalmente el resultado.",
                "Dans les ACL, l'ordre des règles est essentiel. L'équipement lit les règles de haut en bas et applique la première qui correspond au trafic. Une règle permit ou deny mal placée peut donc changer totalement le résultat.",
                "Bei ACLs ist die Reihenfolge der Regeln entscheidend. Das Gerät liest von oben nach unten und wendet die erste passende Regel an. Eine permit- oder deny-Regel an der falschen Stelle kann das Ergebnis komplett ändern.",
                "ACL taisyklėse labai svarbi jų tvarka. Įrenginys skaito taisykles iš viršaus į apačią ir pritaiko pirmą, kuri atitinka srautą. Todėl netinkamoje vietoje esanti permit arba deny taisyklė gali visiškai pakeisti rezultatą.")
        };

        return intro + "\n\n" + rule + "\n\n" + T("Resposta correta nesta pergunta: ", "Correct answer in this question: ", "Respuesta correcta en esta pregunta: ", "Bonne réponse dans cette question : ", "Richtige Antwort in dieser Frage: ", "Teisingas šio klausimo atsakymas: ") + correctAnswer;
    }
}
