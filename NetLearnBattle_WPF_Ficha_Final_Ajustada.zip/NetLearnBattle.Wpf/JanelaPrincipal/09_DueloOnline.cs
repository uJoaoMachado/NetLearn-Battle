using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.NetworkInformation;
using System.Net.Sockets;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Media;
using System.Windows.Threading;
using NetLearnBattle.Wpf.Modelos;
using NetLearnBattle.Wpf.Servicos;

namespace NetLearnBattle.Wpf;

public partial class MainWindow : Window
{
    private async void ShowOnlineDuelSetup()
    {
        if (_current?.Role != Role.Student) { ShowHome(); return; }
        if (!IsServerAvailableForClient()) { RequireServerForOnline(T("Duelo 1v1 online", "Online 1v1 Duel", "Duelo 1v1 online", "Duel 1v1 en ligne", "Online-1v1-Duell")); return; }
        Clear();
        ViewHost.Children.Add(Txt("⚔️ " + T("Duelo 1v1 online", "Online 1v1 Duel", "Duelo 1v1 online", "Duel 1v1 en ligne", "Online-1v1-Duell"), 36, FontWeights.Black));
        var root = new StackPanel();
        root.Children.Add(Txt(T("Dois alunos ligados ao mesmo servidor entram na fila e jogam 5 rondas com a mesma pergunta.", "Two students connected to the same server join the queue and play 5 rounds with the same question.", "Dos alumnos conectados al mismo servidor entran en cola y juegan 5 rondas con la misma pregunta.", "Deux élèves connectés au même serveur rejoignent la file et jouent 5 manches avec la même question.", "Zwei Schüler am selben Server treten der Warteschlange bei und spielen 5 Runden mit derselben Frage."), 16, null, "#9A94C7"));
        var level = new ComboBox { Height = 42, Margin = new Thickness(0, 12, 0, 12), ItemsSource = Enumerable.Range(1, 5).Select(i => $"{T("Nível", "Level", "Nivel", "Niveau", "Level")} {i} - {LevelName(i)}"), SelectedIndex = 0 };
        root.Children.Add(Txt(T("Nível", "Level", "Nivel", "Niveau", "Level"), 14, FontWeights.Bold, "#9A94C7"));
        root.Children.Add(level);
        root.Children.Add(Btn(T("Entrar na fila 1v1", "Join 1v1 queue", "Entrar en cola 1v1", "Rejoindre la file 1v1", "1v1-Warteschlange beitreten"), async (_, __) => await JoinOnlineDuelAsync(level.SelectedIndex + 1)));
        ViewHost.Children.Add(Card(root));
    }

    private async Task JoinOnlineDuelAsync(int level)
    {
        var dto = new DuelJoinDto { Username = _current?.Username ?? "Aluno", Level = level };
        var response = await SendServerCommandAsync("DUEL_JOIN\t" + PackPayload(dto), 2500);
        _onlineDuel = string.IsNullOrWhiteSpace(response) ? null : UnpackPayload<DuelStateDto>(response, "DUEL");
        if (_onlineDuel is null)
        {
            MessageBox.Show(T("Não foi possível entrar no duelo. Confirma a ligação ao servidor.", "Could not join the duel. Check the server connection.", "No fue posible entrar en el duelo. Comprueba la conexión al servidor.", "Impossible de rejoindre le duel. Vérifie la connexion au serveur.", "Duellbeitritt nicht möglich. Prüfe die Serververbindung."));
            return;
        }
        StartOnlineDuelPolling();
        RenderOnlineDuel();
    }

    private void StartOnlineDuelPolling()
    {
        _onlineDuelTimer?.Stop();
        _onlineDuelTimer = new DispatcherTimer { Interval = TimeSpan.FromSeconds(1.2) };
        _onlineDuelTimer.Tick += async (_, __) => await PollOnlineDuelAsync();
        _onlineDuelTimer.Start();
    }

    private async Task PollOnlineDuelAsync()
    {
        // A queda do servidor não pode deixar uma exceção escapar pelo DispatcherTimer.
        try
        {
            if (_current is null || _onlineDuel is null || !_connectionOk) return;
            var payload = Convert.ToBase64String(Encoding.UTF8.GetBytes(_current.Username));
            var response = await SendServerCommandAsync("DUEL_POLL\t" + payload, 1200, false);
            if (string.IsNullOrWhiteSpace(response))
            {
                HandleServerLost();
                return;
            }
            var state = UnpackPayload<DuelStateDto>(response, "DUEL");
            if (state is not null && JsonSerializer.Serialize(state) != JsonSerializer.Serialize(_onlineDuel))
            {
                _onlineDuel = state;
                RenderOnlineDuel();
            }
        }
        catch (Exception)
        {
            HandleServerLost();
        }
    }

    private void RenderOnlineDuel()
    {
        Clear();
        var d = _onlineDuel;
        if (d is null) { ShowHome(); return; }
        ViewHost.Children.Add(Txt("⚔️ " + T("Duelo 1v1 online", "Online 1v1 Duel", "Duelo 1v1 online", "Duel 1v1 en ligne", "Online-1v1-Duell"), 36, FontWeights.Black));
        var root = new StackPanel();
        root.Children.Add(Txt($"{d.Player1} {d.Score1} pts  VS  {d.Player2} {d.Score2} pts", 26, FontWeights.Black, _settings.Accent));
        if (!string.IsNullOrWhiteSpace(d.LastResult)) root.Children.Add(Txt(d.LastResult, 15, FontWeights.Bold, "#FDE68A"));

        if (d.Status == "WAIT" || string.IsNullOrWhiteSpace(d.Player2))
        {
            root.Children.Add(Txt(T("À espera de outro aluno ligado ao servidor...", "Waiting for another student connected to the server...", "Esperando a otro alumno conectado al servidor...", "En attente d'un autre élève connecté au serveur...", "Warte auf einen anderen Schüler am Server..."), 22, FontWeights.Black));
            root.Children.Add(Txt(T("Deixa esta janela aberta. Quando outro jogador entrar, o duelo começa automaticamente.", "Keep this window open. When another player joins, the duel starts automatically.", "Deja esta ventana abierta. Cuando entre otro jugador, el duelo empieza automáticamente.", "Garde cette fenêtre ouverte. Quand un autre joueur arrive, le duel commence automatiquement.", "Lass dieses Fenster offen. Wenn ein anderer Spieler beitritt, startet das Duell automatisch."), 15, null, "#9A94C7"));
            root.Children.Add(Btn("✖ " + T("Cancelar fila", "Cancel queue", "Cancelar cola", "Annuler la file", "Warteschlange abbrechen"), async (_, __) => await CancelOnlineDuelQueueAsync(), false));
            ViewHost.Children.Add(Card(root));
            return;
        }

        if (d.Status == "FINISHED")
        {
            var winner = d.Score1 == d.Score2 ? T("Empate", "Draw", "Empate", "Égalité", "Unentschieden") : (d.Score1 > d.Score2 ? d.Player1 : d.Player2);
            root.Children.Add(Txt("🏁 " + T("Duelo terminado", "Duel finished", "Duelo terminado", "Duel terminé", "Duell beendet"), 30, FontWeights.Black));
            root.Children.Add(Txt(T("Vencedor: ", "Winner: ", "Ganador: ", "Gagnant : ", "Sieger: ") + winner, 26, FontWeights.Black, "#86EFAC"));
            root.Children.Add(Txt(T("Os pontos de rank foram atualizados no ranking 1v1 online.", "Rank points were updated in the online 1v1 ranking.", "Los puntos de rango se actualizaron en el ranking 1v1 online.", "Les points de rang ont été mis à jour dans le classement 1v1 en ligne.", "Rangpunkte wurden in der Online-1v1-Rangliste aktualisiert."), 15, null, "#9A94C7"));
            root.Children.Add(Btn(T("Ver ranking 1v1", "View 1v1 ranking", "Ver ranking 1v1", "Voir classement 1v1", "1v1-Rangliste ansehen"), (_, __) => { _onlineDuelTimer?.Stop(); ShowDuelRanking(); }, false));
            root.Children.Add(Btn(T("Novo duelo", "New duel", "Nuevo duelo", "Nouveau duel", "Neues Duell"), (_, __) => { _onlineDuelTimer?.Stop(); ShowOnlineDuelSetup(); }));
            ViewHost.Children.Add(Card(root));
            return;
        }

        var iAmP1 = _current is not null && d.Player1.Equals(_current.Username, StringComparison.OrdinalIgnoreCase);
        var iAmP2 = _current is not null && d.Player2.Equals(_current.Username, StringComparison.OrdinalIgnoreCase);
        root.Children.Add(Txt($"{T("Ronda", "Round", "Ronda", "Manche", "Runde")} {d.Round}/5", 18, FontWeights.Bold, "#FDE68A"));
        root.Children.Add(Txt(d.Question, 28, FontWeights.Black));
        for (int i = 0; i < d.Options.Count; i++)
        {
            int ix = i;
            root.Children.Add(Btn($"{(char)('A' + i)}. {d.Options[i]}", async (_, __) => await SubmitOnlineDuelAnswerAsync(ix), false));
        }
        if (!iAmP1 && !iAmP2) root.Children.Add(Txt(T("Estás a ver este duelo como observador.", "You are viewing this duel as a spectator.", "Estás viendo este duelo como observador.", "Tu regardes ce duel comme spectateur.", "Du schaust als Zuschauer zu."), 14, null, "#9A94C7"));
        if (d.Status == "WAIT_ANSWER") root.Children.Add(Txt(T("Resposta enviada. A aguardar o outro jogador...", "Answer sent. Waiting for the other player...", "Respuesta enviada. Esperando al otro jugador...", "Réponse envoyée. En attente de l'autre joueur...", "Antwort gesendet. Warte auf den anderen Spieler..."), 15, FontWeights.Bold, "#FDE68A"));
        ViewHost.Children.Add(Card(root));
    }

    private async Task CancelOnlineDuelQueueAsync()
    {
        if (_current is null) { ShowHome(); return; }
        try
        {
            var payload = Convert.ToBase64String(Encoding.UTF8.GetBytes(_current.Username));
            await SendServerCommandAsync("DUEL_CANCEL\t" + payload, 1500, false);
        }
        catch { }
        _onlineDuelTimer?.Stop();
        _onlineDuel = null;
        ShowOnlineDuelSetup();
    }

    private async Task SubmitOnlineDuelAnswerAsync(int selectedIndex)
    {
        try
        {
            if (_onlineDuel is null || _current is null) return;
            var dto = new DuelAnswerDto { RoomId = _onlineDuel.RoomId, Username = _current.Username, SelectedIndex = selectedIndex };
            var response = await SendServerCommandAsync("DUEL_ANSWER\t" + PackPayload(dto), 2000);
            if (string.IsNullOrWhiteSpace(response))
            {
                HandleServerLost();
                return;
            }
            var state = UnpackPayload<DuelStateDto>(response, "DUEL");
            if (state is not null) _onlineDuel = state;
            RenderOnlineDuel();
        }
        catch
        {
            HandleServerLost();
        }
    }

    private async Task<List<DuelRankDto>?> TryFetchDuelRankingFromServerAsync()
    {
        var response = await SendServerCommandAsync("DUEL_RANKING", 1800);
        return string.IsNullOrWhiteSpace(response) ? null : UnpackPayload<List<DuelRankDto>>(response, "DUEL_RANKING");
    }

    private static string RankIcon(string rank) => rank switch
    {
        "Mestre" => "👑",
        "Diamante" => "💎",
        "Ouro" => "🥇",
        "Prata" => "🥈",
        _ => "🥉"
    };

    private async void ShowDuelRanking()
    {
        if (_current?.Role == Role.Guest) { ShowHome(); return; }
        if (!IsServerAvailableForClient() && !_server.IsRunning)
        {
            RequireServerForOnline(T("Ranking 1v1", "1v1 Ranking", "Ranking 1v1", "Classement 1v1", "1v1-Rangliste"));
            return;
        }

        Clear();
        ViewHost.Children.Add(Txt("💎 " + T("Ranking 1v1 Online", "Online 1v1 Ranking", "Ranking 1v1 Online", "Classement 1v1 en ligne", "Online-1v1-Rangliste"), 36, FontWeights.Black));
        ViewHost.Children.Add(Txt(T("Ranking separado do modo normal. Quanto mais alto o rank, menos pontos ganhas por vitória.", "Separate from the normal ranking. The higher your rank, the fewer points you earn per win.", "Ranking separado del modo normal. Cuanto más alto el rango, menos puntos ganas por victoria.", "Classement séparé du mode normal. Plus le rang est élevé, moins tu gagnes de points par victoire.", "Getrennt von der normalen Rangliste. Je höher der Rang, desto weniger Punkte pro Sieg."), 15, null, "#9A94C7"));

        var ranks = _server.IsRunning
            ? _store.DuelRanks
            : await TryFetchDuelRankingFromServerAsync();

        ranks ??= new List<DuelRankDto>();
        var list = ranks
            .OrderByDescending(x => x.Points)
            .ThenByDescending(x => x.Wins)
            .ThenBy(x => x.Username)
            .ToList();

        var root = new StackPanel { Margin = new Thickness(0, 14, 0, 0) };
        var info = new WrapPanel { Margin = new Thickness(0, 0, 0, 12) };
        foreach (var item in new[] { "🥉 Bronze 0+", "🥈 Prata 100+", "🥇 Ouro 250+", "💎 Diamante 500+", "👑 Mestre 800+" })
            info.Children.Add(new Border { Background = SafeBrush(Blend(_settings.Card, _settings.Button, .25)), CornerRadius = new CornerRadius(14), Padding = new Thickness(12,8,12,8), Margin = new Thickness(0,0,8,8), Child = Txt(item, 14, FontWeights.Bold) });
        root.Children.Add(info);

        if (!list.Any())
        {
            var empty = new StackPanel();
            empty.Children.Add(Txt("📭", 44, FontWeights.Black));
            empty.Children.Add(Txt(T("Ainda não há duelos 1v1 terminados.", "No finished 1v1 duels yet.", "Aún no hay duelos 1v1 terminados.", "Aucun duel 1v1 terminé pour l'instant.", "Noch keine abgeschlossenen 1v1-Duelle."), 22, FontWeights.Bold));
            empty.Children.Add(Txt(T("Joga um duelo online para aparecer neste ranking.", "Play an online duel to appear in this ranking.", "Juega un duelo online para aparecer en este ranking.", "Joue un duel en ligne pour apparaître dans ce classement.", "Spiele ein Online-Duell, um hier zu erscheinen."), 15, null, "#9A94C7"));
            root.Children.Add(Card(empty));
            ViewHost.Children.Add(root);
            return;
        }

        int pos = 1;
        foreach (var r in list)
        {
            var row = new Grid { Margin = new Thickness(0, 0, 0, 10) };
            row.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(70) });
            row.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
            row.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(150) });
            row.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(190) });

            var rankName = string.IsNullOrWhiteSpace(r.Rank) ? (r.Points >= 800 ? "Mestre" : r.Points >= 500 ? "Diamante" : r.Points >= 250 ? "Ouro" : r.Points >= 100 ? "Prata" : "Bronze") : r.Rank;
            var c0 = Txt($"#{pos}", 24, FontWeights.Black, pos == 1 ? "#FDE68A" : "#EDE9FF");
            var c1 = new StackPanel();
            c1.Children.Add(Txt(r.Username, 20, FontWeights.Black));
            c1.Children.Add(Txt($"{r.Matches} jogos · {r.Wins}V/{r.Losses}D/{r.Draws}E", 13, null, "#9A94C7"));
            var c2 = Txt($"{r.Points} pts", 22, FontWeights.Black, "#86EFAC");
            var c3 = Txt($"{RankIcon(rankName)} {rankName}", 22, FontWeights.Black, rankName == "Diamante" || rankName == "Mestre" ? "#67E8F9" : "#FDE68A");
            Grid.SetColumn(c0, 0); Grid.SetColumn(c1, 1); Grid.SetColumn(c2, 2); Grid.SetColumn(c3, 3);
            row.Children.Add(c0); row.Children.Add(c1); row.Children.Add(c2); row.Children.Add(c3);
            root.Children.Add(Card(row, new Thickness(0,0,0,0)));
            pos++;
        }
        ViewHost.Children.Add(root);
    }
}
