using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.NetworkInformation;
using System.Net.Sockets;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Media;
using System.Windows.Threading;
using NetLearnBattle.Wpf.Modelos;
using NetLearnBattle.Wpf.Servicos;

namespace NetLearnBattle.Wpf;

public partial class MainWindow : Window
{
    private void ShowRules()
    {
        Clear(); ViewHost.Children.Add(Txt("📘 " + T("Regras do jogo", "Game rules", "Reglas del juego", "Règles du jeu", "Spielregeln"), 36, FontWeights.Black));
        var sp = new StackPanel();
        sp.Children.Add(Txt(T("Permissões", "Permissions", "Permisos", "Permissions", "Berechtigungen"), 24, FontWeights.Black));
        sp.Children.Add(Txt(T("Guest: apenas Ranking Top 5 e Regras. Aluno autenticado: jogar, score, histórico e estatísticas. Professor: criar sessão TCP/UDP e consultar relatórios.", "Guest: only Top 5 Ranking and Rules. Authenticated student: play, score, history and statistics. Teacher: create TCP/UDP session and view reports.", "Guest: solo Ranking Top 5 y Reglas. Alumno autenticado: jugar, puntuación, historial y estadísticas. Profesor: crear sesión TCP/UDP y ver informes.", "Guest : seulement Top 5 et règles. Élève connecté : jouer, score, historique et statistiques. Professeur : créer session TCP/UDP et voir rapports.", "Guest: nur Top 5 und Regeln. Schüler: spielen, Punkte, Verlauf und Statistiken. Lehrer: TCP/UDP-Sitzung erstellen und Berichte ansehen."), 16, null, "#9A94C7"));
        sp.Children.Add(Txt(T("Níveis", "Levels", "Niveles", "Niveaux", "Level"), 24, FontWeights.Black));
        for (int i=1;i<=5;i++)
        {
            var pts = QuestionGenerator.PointsForLevel(i);
            sp.Children.Add(Txt($"{i}. {LevelName(i)} — ✅ +{pts.Correct} pts / ❌ {pts.Wrong} pts", 16, FontWeights.Bold, "#9A94C7"));
        }
        sp.Children.Add(Txt(T("Perguntas", "Questions", "Preguntas", "Questions", "Fragen"), 24, FontWeights.Black));
        sp.Children.Add(Txt(T("Cada nível tem 10 perguntas aleatórias. Quando o aluno acerta ou erra, o jogo mostra o feedback e passa para a próxima pergunta. As respostas ficam guardadas para ranking, histórico e relatórios do professor.", "Each level has 10 random questions. When the student is right or wrong, the game shows feedback and moves to the next question. Answers are stored for ranking, history and teacher reports.", "Cada nivel tiene 10 preguntas aleatorias. Cuando el alumno acierta o falla, el juego muestra feedback y pasa a la siguiente pregunta. Las respuestas se guardan para ranking, historial e informes del profesor.", "Chaque niveau contient 10 questions aléatoires. Après une bonne ou mauvaise réponse, le jeu affiche le feedback et passe à la question suivante. Les réponses sont enregistrées pour le classement, l’historique et les rapports du professeur.", "Jedes Level hat 10 zufällige Fragen. Nach richtiger oder falscher Antwort zeigt das Spiel Feedback und geht zur nächsten Frage. Antworten werden für Rangliste, Verlauf und Lehrerberichte gespeichert."), 16, null, "#9A94C7"));
        sp.Children.Add(Txt(T("Rede", "Network", "Red", "Réseau", "Netzwerk"), 24, FontWeights.Black));
        sp.Children.Add(Txt(T("O professor deve iniciar o servidor no painel Servidor/Professor. O aluno testa a ligação no ecrã de entrada com IP/porta/protocolo.", "The teacher must start the server in Server/Teacher. The student tests the connection on the entry screen with IP/port/protocol.", "El profesor debe iniciar el servidor en Servidor/Profesor. El alumno prueba la conexión en la pantalla de entrada con IP/puerto/protocolo.", "Le professeur démarre le serveur dans Serveur/Professeur. L'élève teste la connexion à l'entrée avec IP/port/protocole.", "Der Lehrer startet den Server unter Server/Lehrer. Der Schüler testet die Verbindung am Startbildschirm mit IP/Port/Protokoll."), 16, null, "#9A94C7"));
        ViewHost.Children.Add(Card(sp));
    }

    private void ShowTeacher()
    {
        if (_current is null || _current.Role != Role.Teacher)
        {
            MessageBox.Show(T("Entra como professor para ligar o servidor.", "Sign in as teacher to start the server.", "Entra como profesor para iniciar el servidor.", "Connecte-toi comme professeur pour démarrer le serveur.", "Melde dich als Lehrer an, um den Server zu starten."));
            ShowLogin();
            return;
        }

        Clear();
        var localIps = GetUsableLocalIps();
        var localIp = localIps.FirstOrDefault() ?? "127.0.0.1";
        ViewHost.Children.Add(Txt("🖥️ " + T("Servidor / Professor", "Server / Teacher", "Servidor / Profesor", "Serveur / Professeur", "Server / Lehrer"), 32, FontWeights.Black));
        ViewHost.Children.Add(Txt(T("Painel principal para iniciar a sessão de rede. Sem isto, os alunos não conseguem testar a ligação TCP/UDP.", "Main panel to start the network session. Without this, students cannot test the TCP/UDP connection.", "Panel principal para iniciar la sesión de red. Sin esto, los alumnos no pueden probar TCP/UDP.", "Panneau principal pour démarrer la session réseau. Sans cela, les élèves ne peuvent pas tester TCP/UDP.", "Hauptbereich zum Starten der Netzwerksitzung. Ohne dies können Schüler TCP/UDP nicht testen."), 16, FontWeights.Bold, "#FDE68A"));

        var grid = new Grid { Margin = new Thickness(0, 18, 0, 0) };
        grid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1.1, GridUnitType.Star) });
        grid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(0.9, GridUnitType.Star) });

        var left = new StackPanel { Margin = new Thickness(0, 0, 18, 0) };
        var status = Txt(_server.IsRunning
            ? "🟢 " + T("Servidor ligado", "Server running", "Servidor activo", "Serveur actif", "Server aktiv")
            : "🔴 " + T("Servidor desligado", "Server off", "Servidor apagado", "Serveur arrêté", "Server aus"),
            18, FontWeights.Bold, _server.IsRunning ? "#86EFAC" : "#FCA5A5");

        var tcp = Input(_lastTcpPort.ToString());
        var udp = Input(_lastUdpPort.ToString());
        tcp.FontSize = 16; tcp.FontWeight = FontWeights.SemiBold; tcp.Height = 42;
        udp.FontSize = 16; udp.FontWeight = FontWeights.SemiBold; udp.Height = 42;

        var serverCard = new StackPanel();
        serverCard.Children.Add(Txt("🚀 " + T("Ligar servidor", "Start server", "Iniciar servidor", "Démarrer serveur", "Server starten"), 24, FontWeights.Black));
        serverCard.Children.Add(status);
        serverCard.Children.Add(Txt(T("Endereço para alunos no mesmo computador", "Address for students on the same computer", "Dirección para alumnos en el mismo ordenador", "Adresse pour élèves sur le même PC", "Adresse für Schüler am gleichen PC"), 14, FontWeights.Bold, "#9A94C7"));
        serverCard.Children.Add(Txt($"127.0.0.1", 18, FontWeights.Black, _settings.Accent));
        serverCard.Children.Add(Txt(T("IP recomendado para alunos noutro computador da mesma rede", "Recommended IP for students on another computer in the same network", "IP recomendada para alumnos en otro ordenador de la misma red", "IP recommandée pour élèves sur un autre PC du même réseau", "Empfohlene IP für Schüler auf anderem PC im selben Netzwerk"), 14, FontWeights.Bold, "#9A94C7"));
        serverCard.Children.Add(Txt(localIp, 18, FontWeights.Black, _settings.Accent));
        if (localIps.Count > 1)
            serverCard.Children.Add(Txt(T("Outros IPs detetados: ", "Other detected IPs: ", "Otros IP detectados: ", "Autres IP détectées : ", "Andere erkannte IPs: ") + string.Join(", ", localIps.Skip(1)), 13, FontWeights.Bold, "#9A94C7"));
        if (localIp == "127.0.0.1")
            serverCard.Children.Add(Txt(T("Não foi encontrado um IP de rede. Usa 127.0.0.1 apenas se aluno e professor estiverem no mesmo PC.", "No network IP was found. Use 127.0.0.1 only if student and teacher are on the same PC.", "No se encontró IP de red. Usa 127.0.0.1 solo si alumno y profesor están en el mismo PC.", "Aucune IP réseau trouvée. Utilise 127.0.0.1 seulement si élève et professeur sont sur le même PC.", "Keine Netzwerk-IP gefunden. Nutze 127.0.0.1 nur auf demselben PC."), 13, FontWeights.Bold, "#FDE68A"));

        var portGrid = new Grid();
        portGrid.ColumnDefinitions.Add(new ColumnDefinition());
        portGrid.ColumnDefinitions.Add(new ColumnDefinition());
        var tcpBox = new StackPanel { Margin = new Thickness(0, 0, 10, 0) };
        tcpBox.Children.Add(Txt("TCP", 16, FontWeights.Black, "#9A94C7")); tcpBox.Children.Add(tcp);
        var udpBox = new StackPanel { Margin = new Thickness(10, 0, 0, 0) };
        udpBox.Children.Add(Txt("UDP", 16, FontWeights.Black, "#9A94C7")); udpBox.Children.Add(udp);
        Grid.SetColumn(tcpBox, 0); Grid.SetColumn(udpBox, 1); portGrid.Children.Add(tcpBox); portGrid.Children.Add(udpBox);
        serverCard.Children.Add(portGrid);

        var startBtn = Btn("▶  " + T("Ligar servidor TCP/UDP", "Start TCP/UDP server", "Iniciar servidor TCP/UDP", "Démarrer serveur TCP/UDP", "TCP/UDP-Server starten"), (_, __) =>
        {
            if (!int.TryParse(tcp.Text.Trim(), out var t) || !int.TryParse(udp.Text.Trim(), out var u) || t <= 0 || u <= 0 || t > 65535 || u > 65535)
            {
                MessageBox.Show(T("As portas devem estar entre 1 e 65535.", "Ports must be between 1 and 65535.", "Los puertos deben estar entre 1 y 65535.", "Les ports doivent être entre 1 et 65535.", "Ports müssen zwischen 1 und 65535 liegen."));
                return;
            }
            try
            {
                if (_server.IsRunning) _server.Stop();
                _lastTcpPort = t; _lastUdpPort = u;
                _server.Start(t, u);
                _connectedHost = "127.0.0.1";
                _connectedPort = t;
                _connectedProtocol = ProtocolMode.TCP;
                _connectionOk = true;
                StartServerMonitor();
                status.Text = "🟢 " + T("Servidor ligado", "Server running", "Servidor activo", "Serveur actif", "Server aktiv");
                status.Foreground = SafeBrush("#86EFAC");
                _serverLog?.Items.Insert(0, $"{DateTime.Now:HH:mm:ss}  {T("Servidor ligado", "Server started", "Servidor iniciado", "Serveur démarré", "Server gestartet")} TCP {t} / UDP {u}");
                ApplySettings();
                MessageBox.Show(T($"Servidor ligado. Alunos usam IP 127.0.0.1 ou {localIp}, TCP {t}, UDP {u}.", $"Server started. Students use IP 127.0.0.1 or {localIp}, TCP {t}, UDP {u}.", $"Servidor iniciado. Alumnos usan IP 127.0.0.1 o {localIp}, TCP {t}, UDP {u}.", $"Serveur démarré. Élèves utilisent IP 127.0.0.1 ou {localIp}, TCP {t}, UDP {u}.", $"Server gestartet. Schüler nutzen IP 127.0.0.1 oder {localIp}, TCP {t}, UDP {u}."));
            }
            catch (Exception ex)
            {
                // Se a porta ficou ocupada por uma execução anterior do Visual Studio, tenta automaticamente portas livres.
                try
                {
                    var free = FindAvailablePorts(t + 1, u + 1);
                    _lastTcpPort = free.Tcp;
                    _lastUdpPort = free.Udp;
                    tcp.Text = free.Tcp.ToString();
                    udp.Text = free.Udp.ToString();
                    _server.Start(free.Tcp, free.Udp);
                    _connectedHost = "127.0.0.1";
                    _connectedPort = free.Tcp;
                    _connectedProtocol = ProtocolMode.TCP;
                    _connectionOk = true;
                    StartServerMonitor();
                    status.Text = "🟢 " + T("Servidor ligado", "Server running", "Servidor activo", "Serveur actif", "Server aktiv", "Serveris veikia");
                    status.Foreground = SafeBrush("#86EFAC");
                    _serverLog?.Items.Insert(0, $"{DateTime.Now:HH:mm:ss}  {T("Portas anteriores ocupadas. Servidor iniciado em portas livres.", "Previous ports were busy. Server started on free ports.", "Puertos anteriores ocupados. Servidor iniciado en puertos libres.", "Ports précédents occupés. Serveur démarré sur des ports libres.", "Vorherige Ports belegt. Server auf freien Ports gestartet.", "Ankstesni prievadai buvo užimti. Serveris paleistas laisvuose prievaduose.")} TCP {free.Tcp} / UDP {free.Udp}");
                    ApplySettings();
                    MessageBox.Show(T(
                        $"As portas escolhidas estavam ocupadas. O servidor foi ligado automaticamente em TCP {free.Tcp} / UDP {free.Udp}.",
                        $"The selected ports were busy. The server was automatically started on TCP {free.Tcp} / UDP {free.Udp}.",
                        $"Los puertos elegidos estaban ocupados. El servidor se inició automáticamente en TCP {free.Tcp} / UDP {free.Udp}.",
                        $"Les ports choisis étaient occupés. Le serveur a démarré automatiquement sur TCP {free.Tcp} / UDP {free.Udp}.",
                        $"Die gewählten Ports waren belegt. Der Server wurde automatisch auf TCP {free.Tcp} / UDP {free.Udp} gestartet.",
                        $"Pasirinkti prievadai buvo užimti. Serveris automatiškai paleistas TCP {free.Tcp} / UDP {free.Udp}."));
                }
                catch
                {
                    MessageBox.Show(T("Não foi possível ligar o servidor. Fecha outras janelas antigas da app ou escolhe outras portas. Erro: ", "Could not start the server. Close older app windows or choose other ports. Error: ", "No fue posible iniciar el servidor. Cierra otras ventanas antiguas de la app o elige otros puertos. Error: ", "Impossible de démarrer le serveur. Ferme les anciennes fenêtres de l'app ou choisis d'autres ports. Erreur : ", "Server konnte nicht gestartet werden. Schließe alte App-Fenster oder wähle andere Ports. Fehler: ", "Nepavyko paleisti serverio. Uždaryk senus programos langus arba pasirink kitus prievadus. Klaida: ") + ex.Message);
                }
            }
        });
        startBtn.FontSize = 15; startBtn.MinHeight = 48;
        serverCard.Children.Add(startBtn);
        serverCard.Children.Add(Btn("⏹  " + T("Desligar servidor", "Stop server", "Parar servidor", "Arrêter serveur", "Server stoppen"), (_, __) =>
        {
            _server.Stop();
            _connectionOk = false;
            _serverMonitorTimer?.Stop();
            status.Text = "🔴 " + T("Servidor desligado", "Server off", "Servidor apagado", "Serveur arrêté", "Server aus");
            status.Foreground = SafeBrush("#FCA5A5");
            _serverLog?.Items.Insert(0, $"{DateTime.Now:HH:mm:ss}  {T("Servidor desligado", "Server stopped", "Servidor parado", "Serveur arrêté", "Server gestoppt")}");
            ApplySettings();
        }, false));
        left.Children.Add(Card(serverCard));

        var how = new StackPanel();
        how.Children.Add(Txt("📌 " + T("Como o aluno liga", "How the student connects", "Cómo conecta el alumno", "Connexion de l'élève", "So verbindet sich der Schüler"), 24, FontWeights.Black));
        how.Children.Add(Txt(T("1. Professor clica em Ligar servidor TCP/UDP.", "1. Teacher clicks Start TCP/UDP server.", "1. El profesor hace clic en Iniciar servidor TCP/UDP.", "1. Le professeur clique sur Démarrer serveur TCP/UDP.", "1. Lehrer klickt TCP/UDP-Server starten."), 16, FontWeights.Bold));
        how.Children.Add(Txt(T("2. Aluno abre a app, coloca IP/Host e porta.", "2. Student opens the app and enters IP/Host and port.", "2. El alumno abre la app e introduce IP/Host y puerto.", "2. L'élève ouvre l'app et saisit IP/Host et port.", "2. Schüler öffnet die App und gibt IP/Host und Port ein."), 16, FontWeights.Bold));
        how.Children.Add(Txt(T("3. Aluno clica em Testar ligação e depois faz login/registo.", "3. Student clicks Test connection and then signs in/registers.", "3. El alumno prueba la conexión y luego inicia sesión/registro.", "3. L'élève teste la connexion puis se connecte/s'inscrit.", "3. Schüler testet die Verbindung und meldet sich an/registriert sich."), 16, FontWeights.Bold));
        left.Children.Add(Card(how));
        Grid.SetColumn(left, 0); grid.Children.Add(left);

        var right = new StackPanel();
        right.Children.Add(Txt("📡 " + T("Atividade do servidor", "Server activity", "Actividad del servidor", "Activité du serveur", "Serveraktivität"), 26, FontWeights.Black));
        _serverLog = new ListBox
        {
            Height = 300,
            Background = SafeBrush(Blend(_settings.Card, "#000000", 0.35), "#0D0B26"),
            Foreground = Brushes.White,
            BorderThickness = new Thickness(0),
            Padding = new Thickness(10)
        };
        if (_server.IsRunning) _serverLog.Items.Insert(0, $"{DateTime.Now:HH:mm:ss}  {T("Servidor ativo", "Server active", "Servidor activo", "Serveur actif", "Server aktiv")} TCP {_lastTcpPort} / UDP {_lastUdpPort}");
        right.Children.Add(_serverLog);

        var reports = new StackPanel();
        reports.Children.Add(Txt("📊 " + T("Relatórios rápidos", "Quick reports", "Informes rápidos", "Rapports rapides", "Schnellberichte"), 24, FontWeights.Black));
        var uniqueReportAttempts = UniqueAttempts(_store.Attempts);
        reports.Children.Add(Txt($"{T("Tentativas registadas", "Registered attempts", "Intentos registrados", "Tentatives enregistrées", "Registrierte Versuche")}: {uniqueReportAttempts.Count}", 18, FontWeights.Bold));
        reports.Children.Add(Txt($"{T("Jogadores com pontuação", "Players with score", "Jugadores con puntuación", "Joueurs avec score", "Spieler mit Punkten")}: {_store.Scores.Select(s => s.Username).Distinct().Count()}", 18, FontWeights.Bold));
        var recentAttempts = uniqueReportAttempts.OrderByDescending(a => a.Date).Take(8).ToList();
        reports.Children.Add(Txt(T("Últimas respostas recebidas", "Latest received answers", "Últimas respuestas recibidas", "Dernières réponses reçues", "Letzte empfangene Antworten"), 20, FontWeights.Black));
        if (!recentAttempts.Any())
            reports.Children.Add(Txt(T("Ainda não há respostas dos alunos.", "No student answers yet.", "Aún no hay respuestas de alumnos.", "Pas encore de réponses des élèves.", "Noch keine Schülerantworten."), 14, null, "#9A94C7"));
        foreach (var a in recentAttempts)
            reports.Children.Add(Txt($"{a.Date:HH:mm} · {a.Username} · {T("Nível", "Level", "Nivel", "Niveau", "Level")} {a.Level} · {(a.Correct ? T("certa", "correct", "correcta", "correcte", "richtig") : T("errada", "wrong", "incorrecta", "fausse", "falsch"))}", 14, FontWeights.Bold, a.Correct ? "#86EFAC" : "#FCA5A5"));
        reports.Children.Add(Btn(T("Atualizar relatórios", "Refresh reports", "Actualizar informes", "Actualiser rapports", "Berichte aktualisieren"), (_, __) => ShowTeacher(), false));
        right.Children.Add(Card(reports, new Thickness(0, 18, 0, 0)));
        Grid.SetColumn(right, 1); grid.Children.Add(right);
        ViewHost.Children.Add(grid);
    }

}
