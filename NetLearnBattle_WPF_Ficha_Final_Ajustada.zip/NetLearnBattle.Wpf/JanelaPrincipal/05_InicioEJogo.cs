using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.NetworkInformation;
using System.Net.Sockets;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Media;
using System.Windows.Threading;
using NetLearnBattle.Wpf.Modelos;
using NetLearnBattle.Wpf.Servicos;

namespace NetLearnBattle.Wpf;

public partial class MainWindow : Window
{
    private void ShowHome()
    {
        Clear();
        if (_current is null) { ShowLogin(); return; }
        ViewHost.Children.Add(Txt($"{T("Bem-vindo", "Welcome", "Bienvenido", "Bienvenue", "Willkommen")}, {_current.Username} 👋", 38, FontWeights.Black));
        if (_current.Role == Role.Guest)
            ViewHost.Children.Add(Txt(T("Guest tem acesso limitado: apenas Ranking Top 5 e Regras do Jogo.", "Guest has limited access: only Top 5 Ranking and Game Rules.", "Guest tiene acceso limitado: solo Ranking Top 5 y Reglas.", "Guest a un accès limité : seulement Top 5 et règles.", "Guest hat eingeschränkten Zugriff: nur Top-5-Rangliste und Regeln."), 17, FontWeights.Bold, "#FDE68A"));
        else if (_current.Role == Role.Student)
            ViewHost.Children.Add(Txt(T("Aluno autenticado: podes jogar, ver histórico, score e estatísticas.", "Authenticated student: you can play, view history, score and statistics.", "Alumno autenticado: puedes jugar, ver historial, puntuación y estadísticas.", "Élève connecté : tu peux jouer, voir l'historique, le score et les statistiques.", "Angemeldeter Schüler: Du kannst spielen, Verlauf, Punkte und Statistiken sehen."), 17, null, "#9A94C7"));
        else
            ViewHost.Children.Add(Txt(T("Professor autenticado: inicia/parar servidor TCP/UDP e consulta relatórios.", "Authenticated teacher: start/stop TCP/UDP server and view reports.", "Profesor autenticado: inicia/para servidor TCP/UDP y consulta informes.", "Professeur connecté : démarrer/arrêter serveur TCP/UDP et voir rapports.", "Angemeldeter Lehrer: TCP/UDP-Server starten/stoppen und Berichte ansehen."), 17, null, "#9A94C7"));

        var wrap = new WrapPanel { Margin = new Thickness(0, 20, 0, 0) };
        void Tile(string title, string desc, string emoji, RoutedEventHandler click, bool primary=true)
        {
            // Cartão com grelha fixa: todos os botões ficam alinhados no fundo.
            var tileGrid = new Grid { Width = 250, Height = 216 };
            tileGrid.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });
            tileGrid.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });
            tileGrid.RowDefinitions.Add(new RowDefinition { Height = new GridLength(1, GridUnitType.Star) });
            tileGrid.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });

            var icon = Txt(emoji, 34, FontWeights.Bold);
            var heading = Txt(title, 22, FontWeights.Black);
            var description = Txt(desc, 14, null, "#9A94C7");
            description.TextWrapping = TextWrapping.Wrap;
            description.Margin = new Thickness(0, 6, 0, 10);
            var openButton = Btn(T("Abrir", "Open", "Abrir", "Ouvrir", "Öffnen"), click, true);
            openButton.Height = 46;
            openButton.HorizontalAlignment = HorizontalAlignment.Stretch;

            Grid.SetRow(icon, 0); Grid.SetRow(heading, 1); Grid.SetRow(description, 2); Grid.SetRow(openButton, 3);
            tileGrid.Children.Add(icon); tileGrid.Children.Add(heading); tileGrid.Children.Add(description); tileGrid.Children.Add(openButton);
            wrap.Children.Add(Card(tileGrid, new Thickness(0, 0, 18, 18)));
        }
        if (_current.Role == Role.Student)
        {
            Tile(T("Jogar", "Play", "Jugar", "Jouer", "Spielen"), T("Escolhe nível e responde a 10 perguntas.", "Choose a level and answer 10 questions.", "Elige nivel y responde 10 preguntas.", "Choisis un niveau et réponds à 10 questions.", "Wähle ein Level und beantworte 10 Fragen."), "🎮", Game_Click);
            Tile(T("Modo treino", "Training mode", "Modo entrenamiento", "Mode entraînement", "Trainingsmodus"), T("Repete perguntas falhadas sem afetar o ranking.", "Repeat failed questions without affecting the ranking.", "Repite preguntas falladas sin afectar el ranking.", "Répète les questions ratées sans modifier le classement.", "Wiederhole falsche Fragen ohne Rangliste."), "🧠", (_, __) => ShowTraining());
            Tile(T("Duelo 1v1 online", "Online 1v1 Duel", "Duelo 1v1 online", "Duel 1v1 en ligne", "Online-1v1-Duell"), T("Dois PCs ligados ao servidor competem em 5 rondas.", "Two PCs connected to the server compete in 5 rounds.", "Dos PCs conectados al servidor compiten en 5 rondas.", "Deux PC connectés au serveur s'affrontent en 5 manches.", "Zwei mit dem Server verbundene PCs spielen 5 Runden."), "⚔️", (_, __) => ShowOnlineDuelSetup(), false);
            Tile(T("Ranking 1v1", "1v1 Ranking", "Ranking 1v1", "Classement 1v1", "1v1-Rangliste"), T("Ranking online separado com ranks Bronze, Prata, Ouro, Diamante e Mestre.", "Separate online ranking with Bronze, Silver, Gold, Diamond and Master ranks.", "Ranking online separado con rangos Bronce, Plata, Oro, Diamante y Maestro.", "Classement en ligne séparé avec rangs Bronze, Argent, Or, Diamant et Maître.", "Separate Online-Rangliste mit Bronze, Silber, Gold, Diamant und Meister."), "💎", (_, __) => ShowDuelRanking(), false);
            Tile(T("Estatísticas", "Statistics", "Estadísticas", "Statistiques", "Statistiken"), T("Histórico, score e taxa de acerto.", "History, score and accuracy.", "Historial, puntuación y acierto.", "Historique, score et réussite.", "Verlauf, Punkte und Trefferquote."), "📊", Stats_Click);
            Tile(T("Configurações", "Settings", "Configuración", "Paramètres", "Einstellungen"), T("Idioma, tema, cores e texto.", "Language, theme, colors and text.", "Idioma, tema, colores y texto.", "Langue, thème, couleurs et texte.", "Sprache, Design, Farben und Text."), "⚙", Settings_Click, false);
        }
        if (_current.Role == Role.Teacher)
        {
            Tile(T("Servidor/Professor", "Server/Teacher", "Servidor/Profesor", "Serveur/Professeur", "Server/Lehrer"), T("Inicia TCP/UDP para os alunos ligarem.", "Start TCP/UDP for students to connect.", "Inicia TCP/UDP para que conecten los alumnos.", "Démarre TCP/UDP pour les élèves.", "TCP/UDP für Schüler starten."), "🖥️", Teacher_Click);
            Tile(T("Relatórios completos", "Full reports", "Informes completos", "Rapports complets", "Vollständige Berichte"), T("Vê ranking, respostas, alunos e estatísticas globais.", "View ranking, answers, students and global stats.", "Ver ranking, respuestas, alumnos y estadísticas globales.", "Voir classement, réponses, élèves et statistiques globales.", "Rangliste, Antworten, Schüler und globale Statistiken."), "📊", Stats_Click, false);
            Tile(T("Ranking 1v1", "1v1 Ranking", "Ranking 1v1", "Classement 1v1", "1v1-Rangliste"), T("Consulta os ranks online dos alunos.", "View students' online ranks.", "Consulta los rangos online de los alumnos.", "Consulte les rangs en ligne des élèves.", "Online-Ränge der Schüler ansehen."), "💎", (_, __) => ShowDuelRanking(), false);
            Tile(T("Configurações", "Settings", "Configuración", "Paramètres", "Einstellungen"), T("Idioma, tema, cores e texto.", "Language, theme, colors and text.", "Idioma, tema, colores y texto.", "Langue, thème, couleurs et texte.", "Sprache, Design, Farben und Text."), "⚙", Settings_Click, false);
        }
        Tile(T("Ranking Top 5", "Top 5 Ranking", "Ranking Top 5", "Top 5", "Top 5 Rangliste"), T("Acesso permitido a todos.", "Allowed for everyone.", "Permitido para todos.", "Autorisé pour tous.", "Für alle erlaubt."), "🏆", Ranking_Click, false);
        Tile(T("Regras", "Rules", "Reglas", "Règles", "Regeln"), T("Consulta permissões, níveis e pontuação.", "View permissions, levels and scoring.", "Consulta permisos, niveles y puntuación.", "Voir permissions, niveaux et score.", "Berechtigungen, Level und Punkte ansehen."), "📘", Rules_Click, false);
        ViewHost.Children.Add(wrap);
    }

    private void ShowGame()
    {
        if (_current?.Role != Role.Student) { MessageBox.Show(T("Só alunos autenticados podem jogar. Guest apenas vê Ranking Top 5 e Regras.", "Only authenticated students can play. Guest only sees Top 5 Ranking and Rules.", "Solo alumnos autenticados pueden jugar. Guest solo ve Ranking Top 5 y Reglas.", "Seuls les élèves connectés peuvent jouer. Guest voit seulement Top 5 et règles.", "Nur angemeldete Schüler können spielen. Guest sieht nur Top 5 und Regeln.")); ShowHome(); return; }
        if (!IsServerAvailableForClient()) { RequireServerForOnline(T("Jogar", "Play", "Jugar", "Jouer", "Spielen")); return; }
        Clear(); ViewHost.Children.Add(Txt(T("Escolher nível", "Choose level", "Elegir nivel", "Choisir niveau", "Level wählen"), 36, FontWeights.Black));
        var wrap = new WrapPanel { Margin = new Thickness(0, 18, 0, 0) };
        for (int i = 1; i <= 5; i++)
        {
            int level = i;
            var pts = QuestionGenerator.PointsForLevel(level);
            var sp = new StackPanel { Width = 225 };
            sp.Children.Add(Txt($"{T("Nível", "Level", "Nivel", "Niveau", "Level")} {i}", 24, FontWeights.Black));
            sp.Children.Add(Txt(LevelName(i), 14, null, "#9A94C7"));
            sp.Children.Add(Txt($"✅ +{pts.Correct} pts   ❌ {pts.Wrong} pts", 14, FontWeights.Bold, pts.Correct >= 40 ? "#FDE68A" : "#86EFAC"));
            sp.Children.Add(Txt(T("Perguntas aleatórias", "Random questions", "Preguntas aleatorias", "Questions aléatoires", "Zufällige Fragen"), 13, null, "#9A94C7"));
            sp.Children.Add(Btn(T("Começar 10 perguntas", "Start 10 questions", "Empezar 10 preguntas", "Commencer 10 questions", "10 Fragen starten"), (_, __) => StartLevel(level)));
            wrap.Children.Add(Card(sp, new Thickness(0, 0, 14, 14)));
        }
        ViewHost.Children.Add(wrap);
    }
    private void StartLevel(int level)
    {
        _sessionLevel = level;
        _sessionIndex = 0;
        _sessionScore = 0;
        _sessionQuestions = new Queue<Question>(_questions.GenerateSet(level, 10, _settings.Language));
        AskNext();
    }

    private void AskNext()
    {
        if (_current?.Role != Role.Student) { ShowHome(); return; }
        if (_sessionQuestions.Count == 0)
        {
            Clear();
            var done = new StackPanel();
            done.Children.Add(Txt("🏁 " + T("Sessão terminada", "Session finished", "Sesión terminada", "Session terminée", "Sitzung beendet"), 36, FontWeights.Black));
            done.Children.Add(Txt($"{T("Nível", "Level", "Nivel", "Niveau", "Level")} {_sessionLevel} · 10 {T("perguntas", "questions", "preguntas", "questions", "Fragen")}", 18, FontWeights.Bold, "#9A94C7"));
            done.Children.Add(Txt($"{T("Pontuação nesta sessão", "Score this session", "Puntuación de esta sesión", "Score de cette session", "Punkte dieser Sitzung")}: {(_sessionScore >= 0 ? "+" : "")}{_sessionScore} pts", 28, FontWeights.Black, _sessionScore >= 0 ? "#86EFAC" : "#FCA5A5"));
            done.Children.Add(Btn(T("Escolher outro nível", "Choose another level", "Elegir otro nivel", "Choisir un autre niveau", "Anderes Level wählen"), (_, __) => ShowGame()));
            done.Children.Add(Btn(T("Ver ranking", "View ranking", "Ver ranking", "Voir classement", "Rangliste ansehen"), (_, __) => ShowRanking(), false));
            ViewHost.Children.Add(Card(done));
            return;
        }

        Clear();
        _currentQuestion = _sessionQuestions.Dequeue();
        _answerLocked = false;
        _sessionIndex++;
        _questionStart = DateTime.Now;
        var sp = new StackPanel();
        sp.Children.Add(Txt($"{T("Nível", "Level", "Nivel", "Niveau", "Level")} {_sessionLevel} · {LevelName(_sessionLevel)}", 15, FontWeights.Bold, _settings.Accent));
        sp.Children.Add(Txt($"{T("Pergunta", "Question", "Pregunta", "Question", "Frage")} {_sessionIndex}/10 · ✅ +{_currentQuestion.PointsCorrect} pts · ❌ {_currentQuestion.PointsWrong} pts", 15, FontWeights.Bold, "#FDE68A"));
        sp.Children.Add(Txt(_currentQuestion.Text, 30, FontWeights.Black));
        for (int i = 0; i < _currentQuestion.Options.Count; i++)
        {
            int idx = i;
            sp.Children.Add(Btn($"{(char)('A' + i)}  {_currentQuestion.Options[i]}", (_, __) => Answer(idx), false));
        }
        ViewHost.Children.Add(Card(sp));
    }

    private async void Answer(int idx)
    {
        if (_answerLocked || _currentQuestion is null || _current is null) return;

        // Guardar a pergunta numa variável local evita crashes se o servidor for desligado
        // durante o envio da resposta. Nessa situação HandleServerLost() limpa _currentQuestion,
        // mas a interface de resultado ainda precisa dos dados da pergunta respondida.
        var question = _currentQuestion;
        var user = _current;

        if (idx < 0 || idx >= question.Options.Count) return;

        _answerLocked = true;
        var ok = idx == question.CorrectIndex;
        var secs = Math.Max(1, (int)(DateTime.Now - _questionStart).TotalSeconds);
        var pts = ok ? question.PointsCorrect : question.PointsWrong;
        _sessionScore += pts;

        var attemptId = Guid.NewGuid().ToString("N");
        var attempt = new Attempt { Id = attemptId, Username = user.Username, Level = question.Level, Question = question.Text, Answer = question.Options[idx], Correct = ok, DurationSeconds = secs, Date = DateTime.Now };
        var attempts = _store.Attempts;
        attempts.Add(attempt);
        _store.Attempts = attempts;

        var scores = _store.Scores;
        scores.Add(new ScoreEntry { Id = attemptId, Username = user.Username, Score = pts, Correct = ok ? 1 : 0, Total = 1, Date = attempt.Date });
        _store.Scores = scores;

        await SendAttemptToServerAsync(attempt, pts);

        // Se o servidor caiu, o próprio HandleServerLost() já mostrou a mensagem segura.
        // Não desenhar o resultado por cima dessa mensagem.
        if (!_connectionOk && !_server.IsRunning)
            return;

        Clear();
        var sp = new StackPanel();
        sp.Children.Add(Txt(ok ? "✅ " + T("Correto", "Correct", "Correcto", "Correct", "Richtig") : "❌ " + T("Errado", "Wrong", "Incorrecto", "Faux", "Falsch"), 34, FontWeights.Black, ok ? "#86EFAC" : "#FCA5A5"));
        sp.Children.Add(Txt($"{T("Pontuação desta pergunta", "Score for this question", "Puntuación de esta pregunta", "Points de cette question", "Punkte für diese Frage")}: {(pts > 0 ? "+" : "")}{pts} pts", 20, FontWeights.Black, pts > 0 ? "#86EFAC" : "#FCA5A5"));
        sp.Children.Add(Txt($"{T("Progresso", "Progress", "Progreso", "Progression", "Fortschritt")}: {_sessionIndex}/10 · {T("Total da sessão", "Session total", "Total de la sesión", "Total session", "Sitzung gesamt")}: {(_sessionScore >= 0 ? "+" : "")}{_sessionScore} pts", 16, FontWeights.Bold, "#FDE68A"));
        sp.Children.Add(Txt(question.Explanation, 17, null, "#9A94C7"));
        sp.Children.Add(Btn(_sessionQuestions.Count == 0 ? T("Terminar sessão", "Finish session", "Terminar sesión", "Finir session", "Sitzung beenden") : T("Próxima pergunta", "Next question", "Siguiente pregunta", "Question suivante", "Nächste Frage"), (_, __) => AskNext()));
        ViewHost.Children.Add(Card(sp));
    }


    private async Task<string?> SendServerCommandAsync(string line, int timeoutMs = 1800, bool closeOnFailure = true)
    {
        if (!_connectionOk) return null;
        try
        {
            if (_connectedProtocol == ProtocolMode.TCP)
            {
                using var tcp = new TcpClient();
                var connectTask = tcp.ConnectAsync(_connectedHost, _connectedPort);
                if (await Task.WhenAny(connectTask, Task.Delay(timeoutMs)) != connectTask)
                    throw new TimeoutException();
                await connectTask;

                using var stream = tcp.GetStream();
                using var writer = new StreamWriter(stream, Encoding.UTF8, leaveOpen: true) { AutoFlush = true };
                using var reader = new StreamReader(stream, Encoding.UTF8, leaveOpen: true);
                await writer.WriteLineAsync(line);
                var readTask = reader.ReadLineAsync();
                if (await Task.WhenAny(readTask, Task.Delay(timeoutMs)) != readTask)
                    throw new TimeoutException();
                return await readTask;
            }
            else
            {
                using var udp = new UdpClient();
                var data = Encoding.UTF8.GetBytes(line);
                await udp.SendAsync(data, data.Length, _connectedHost, _connectedPort);
                var receive = udp.ReceiveAsync();
                if (await Task.WhenAny(receive, Task.Delay(timeoutMs)) != receive)
                    throw new TimeoutException();
                return Encoding.UTF8.GetString(receive.Result.Buffer);
            }
        }
        catch
        {
            if (closeOnFailure && _connectionOk && !_server.IsRunning)
            {
                try
                {
                    if (Dispatcher.CheckAccess()) HandleServerLost();
                    else Dispatcher.BeginInvoke(new Action(HandleServerLost));
                }
                catch { }
            }
            return null;
        }
    }

    private static string PackPayload<T>(T value)
        => Convert.ToBase64String(Encoding.UTF8.GetBytes(JsonSerializer.Serialize(value)));

    private static T? UnpackPayload<T>(string response, string prefix)
    {
        if (!response.StartsWith(prefix + "\t", StringComparison.OrdinalIgnoreCase)) return default;
        return JsonSerializer.Deserialize<T>(Encoding.UTF8.GetString(Convert.FromBase64String(response[(prefix.Length + 1)..])));
    }

    private async Task SendAttemptToServerAsync(Attempt attempt, int points)
    {
        if (!_connectionOk) return;
        try
        {
            var dto = new NetworkAttemptDto
            {
                Id = attempt.Id,
                Username = attempt.Username,
                Level = attempt.Level,
                Question = attempt.Question,
                Answer = attempt.Answer,
                Correct = attempt.Correct,
                DurationSeconds = attempt.DurationSeconds,
                Score = points,
                Date = attempt.Date
            };
            await SendServerCommandAsync("SUBMIT\t" + PackPayload(dto));
        }
        catch
        {
            // A resposta fica guardada localmente mesmo se a rede falhar.
        }
    }

    private async Task<List<RankingDto>?> TryFetchRankingFromServerAsync()
    {
        var response = await SendServerCommandAsync("RANKING", 1800);
        return string.IsNullOrWhiteSpace(response) ? null : UnpackPayload<List<RankingDto>>(response, "RANKING");
    }
}
