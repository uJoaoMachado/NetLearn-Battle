using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.NetworkInformation;
using System.Net.Sockets;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Media;
using System.Windows.Threading;
using NetLearnBattle.Wpf.Modelos;
using NetLearnBattle.Wpf.Servicos;

namespace NetLearnBattle.Wpf;

public partial class MainWindow : Window
{
    private bool IsServerAvailableForClient() => _connectionOk || _server.IsRunning;

    private void RequireServerForOnline(string feature)
    {
        ShowServerRequiredNotice(feature);
    }

    private void ShowServerRequiredNotice(string feature)
    {
        Clear();
        ViewHost.Children.Add(Txt("🔌 " + T("Servidor necessário", "Server required", "Servidor necesario", "Serveur requis", "Server erforderlich"), 38, FontWeights.Black));
        var root = new StackPanel();
        root.Children.Add(Txt(T(
            $"Para usar {feature}, primeiro valida a ligação ao servidor do professor no ecrã inicial. Enquanto não houver servidor, ficam disponíveis apenas as opções offline.",
            $"To use {feature}, validate the teacher server connection on the start screen first. While there is no server, only offline options remain available.",
            $"Para usar {feature}, valida primero la conexión al servidor del profesor en la pantalla inicial. Mientras no haya servidor, solo quedan disponibles las opciones offline.",
            $"Pour utiliser {feature}, valide d'abord la connexion au serveur du professeur sur l'écran d'accueil. Sans serveur, seules les options hors ligne restent disponibles.",
            $"Um {feature} zu verwenden, prüfe zuerst die Verbindung zum Lehrer-Server auf dem Startbildschirm. Ohne Server bleiben nur Offline-Optionen verfügbar."), 18, FontWeights.Bold, "#FDE68A"));

        var grid = new UniformGrid { Columns = 3, Margin = new Thickness(0, 22, 0, 0) };
        grid.Children.Add(Card(new StackPanel { Children = { Txt("🧠 " + T("Modo treino", "Training mode", "Modo entrenamiento", "Mode entraînement", "Trainingsmodus"), 22, FontWeights.Black), Txt(T("Funciona offline e não altera o ranking.", "Works offline and does not change ranking.", "Funciona offline y no cambia el ranking.", "Fonctionne hors ligne et ne change pas le classement.", "Funktioniert offline und ändert die Rangliste nicht."), 14, null, "#9A94C7"), Btn(T("Abrir treino", "Open training", "Abrir entrenamiento", "Ouvrir entraînement", "Training öffnen"), (_, __) => ShowTraining()) } }, new Thickness(0,0,14,0)));
        grid.Children.Add(Card(new StackPanel { Children = { Txt("🏆 " + T("Ranking local", "Local ranking", "Ranking local", "Classement local", "Lokale Rangliste"), 22, FontWeights.Black), Txt(T("Consulta os dados guardados neste PC.", "View data saved on this PC.", "Consulta los datos guardados en este PC.", "Consulte les données enregistrées sur ce PC.", "Sieh Daten auf diesem PC an."), 14, null, "#9A94C7"), Btn(T("Abrir ranking", "Open ranking", "Abrir ranking", "Ouvrir classement", "Rangliste öffnen"), Ranking_Click) } }, new Thickness(0,0,14,0)));
        grid.Children.Add(Card(new StackPanel { Children = { Txt("📘 " + T("Regras", "Rules", "Reglas", "Règles", "Regeln"), 22, FontWeights.Black), Txt(T("Vê permissões, níveis e pontuação.", "View permissions, levels and scoring.", "Consulta permisos, niveles y puntuación.", "Voir permissions, niveaux et score.", "Berechtigungen, Level und Punkte ansehen."), 14, null, "#9A94C7"), Btn(T("Abrir regras", "Open rules", "Abrir reglas", "Ouvrir règles", "Regeln öffnen"), Rules_Click) } }));
        root.Children.Add(grid);
        root.Children.Add(Btn("🏠 " + T("Voltar ao início", "Back home", "Volver al inicio", "Retour accueil", "Zurück zum Start"), (_, __) => ShowHome(), false));
        ViewHost.Children.Add(Card(root));
    }

    public void ForceSafeServerLost()
    {
        _connectionOk = true;
        HandleServerLost();
    }

    private void HandleServerLost()
    {
        if (!_connectionOk && !_server.IsRunning) return;
        _connectionOk = false;
        _onlineDuelTimer?.Stop();
        _serverMonitorTimer?.Stop();
        _sessionQuestions.Clear();
        _currentQuestion = null;
        ApplySettings();
        Clear();
        ViewHost.Children.Add(Txt("⚠️ " + T("Ligação perdida", "Connection lost", "Conexión perdida", "Connexion perdue", "Verbindung verloren"), 38, FontWeights.Black, "#FDE68A"));
        var sp = new StackPanel();
        sp.Children.Add(Txt(T("O servidor do professor foi desligado ou deixou de responder. As atividades online foram fechadas e voltaste ao modo seguro.", "The teacher server was stopped or stopped responding. Online activities were closed and you returned to safe mode.", "El servidor del profesor se apagó o dejó de responder. Las actividades online se cerraron y volviste al modo seguro.", "Le serveur du professeur a été arrêté ou ne répond plus. Les activités en ligne sont fermées et tu reviens en mode sûr.", "Der Lehrer-Server wurde beendet oder antwortet nicht mehr. Online-Aktivitäten wurden geschlossen und du bist im sicheren Modus."), 18, FontWeights.Bold, "#FDE68A"));
        sp.Children.Add(Txt(T("Disponível sem servidor: Modo treino, Ranking local e Regras. Para voltar a jogar online, testa novamente a ligação no início.", "Available without server: Training mode, local Ranking and Rules. To play online again, test the connection again on Home.", "Disponible sin servidor: Modo entrenamiento, Ranking local y Reglas. Para volver a jugar online, prueba la conexión otra vez en Inicio.", "Disponible sans serveur : entraînement, classement local et règles. Pour rejouer en ligne, teste à nouveau la connexion à l'accueil.", "Ohne Server verfügbar: Training, lokale Rangliste und Regeln. Für Online-Spiel Verbindung auf Start erneut testen."), 15, null, "#9A94C7"));
        sp.Children.Add(Btn("🏠 " + T("Ir para o menu principal", "Go to main menu", "Ir al menú principal", "Aller au menu principal", "Zum Hauptmenü"), (_, __) => ShowHome()));
        ViewHost.Children.Add(Card(sp));
    }

    private void StartServerMonitor()
    {
        _serverMonitorTimer?.Stop();
        _serverMonitorTimer = new DispatcherTimer { Interval = TimeSpan.FromSeconds(2.5) };
        _serverMonitorTimer.Tick += async (_, __) =>
        {
            try
            {
                await CheckServerHealthAsync();
            }
            catch
            {
                HandleServerLost();
            }
        };
        _serverMonitorTimer.Start();
    }

    private async Task CheckServerHealthAsync()
    {
        try
        {
            if (!_connectionOk || _server.IsRunning) return;
            var response = await SendServerCommandAsync("PING", 1200, false);
            if (!string.Equals(response, "NETLEARN_OK", StringComparison.OrdinalIgnoreCase))
                HandleServerLost();
        }
        catch
        {
            HandleServerLost();
        }
    }

    private string RoleText(Role role) => role switch
    {
        Role.Student => T("Aluno", "Student", "Alumno", "Élève", "Schüler"),
        Role.Teacher => T("Professor", "Teacher", "Profesor", "Professeur", "Lehrer"),
        _ => "Guest"
    };

    private string LevelName(int i) => i switch
    {
        1 => T("IPv4 básico", "Basic IPv4", "IPv4 básico", "IPv4 de base", "IPv4 Grundlagen"),
        2 => T("Sub-redes IPv4", "IPv4 subnetting", "Subredes IPv4", "Sous-réseaux IPv4", "IPv4 Subnetting"),
        3 => T("Sumarização IPv4", "IPv4 summarization", "Sumarización IPv4", "Résumé IPv4", "IPv4 Zusammenfassung"),
        4 => "IPv6",
        _ => "ACLs"
    };

    private static bool IsValidHex(string? value)
    {
        if (string.IsNullOrWhiteSpace(value)) return false;
        value = value.Trim();
        if (!value.StartsWith("#")) return false;
        if (value.Length != 7 && value.Length != 9) return false;
        return value.Skip(1).All(c => char.IsDigit(c) || "abcdefABCDEF".Contains(c));
    }
    private static string SafeHex(string? value, string fallback) => IsValidHex(value) ? value!.Trim() : fallback;
    private static Brush SafeBrush(string? hex, string fallback = "#12103A")
    {
        try { return (Brush)new BrushConverter().ConvertFromString(SafeHex(hex, fallback))!; }
        catch { return (Brush)new BrushConverter().ConvertFromString(fallback)!; }
    }
    private static AppSettings SanitizeSettings(AppSettings s)
    {
        s.Background = SafeHex(s.Background, "#07061A");
        s.Card = SafeHex(s.Card, "#12103A");
        s.Button = SafeHex(s.Button, "#7C3AED");
        s.Accent = SafeHex(s.Accent, "#06B6D4");
        if (s.FontSize < 12 || s.FontSize > 24) s.FontSize = 15;
        return s;
    }
    private static string Blend(string a, string b, double amount)
    {
        try
        {
            var ca = (Color)ColorConverter.ConvertFromString(SafeHex(a, "#000000"));
            var cb = (Color)ColorConverter.ConvertFromString(SafeHex(b, "#FFFFFF"));
            byte r = (byte)(ca.R + (cb.R - ca.R) * amount);
            byte g = (byte)(ca.G + (cb.G - ca.G) * amount);
            byte bl = (byte)(ca.B + (cb.B - ca.B) * amount);
            return $"#{r:X2}{g:X2}{bl:X2}";
        }
        catch { return "#221C55"; }
    }
}
