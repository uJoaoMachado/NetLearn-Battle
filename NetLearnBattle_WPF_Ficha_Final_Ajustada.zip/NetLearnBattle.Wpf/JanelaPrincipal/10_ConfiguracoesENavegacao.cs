using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.NetworkInformation;
using System.Net.Sockets;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Media;
using System.Windows.Threading;
using NetLearnBattle.Wpf.Modelos;
using NetLearnBattle.Wpf.Servicos;

namespace NetLearnBattle.Wpf;

public partial class MainWindow : Window
{
    private void ShowSettings()
    {
        if (_current is null || _current.Role == Role.Guest) { MessageBox.Show(T("Configurações só disponíveis após login/registo.", "Settings are only available after login/register.", "Configuración solo disponible tras iniciar sesión/registro.", "Paramètres disponibles seulement après connexion/inscription.", "Einstellungen nur nach Anmeldung/Registrierung verfügbar.")); ShowHome(); return; }
        Clear(); ViewHost.Children.Add(Txt("⚙ " + T("Configurações", "Settings", "Configuración", "Paramètres", "Einstellungen"), 36, FontWeights.Black));
        var root = new StackPanel();
        var langItems = new Dictionary<AppLanguage,string> { [AppLanguage.PT]="Português", [AppLanguage.EN]="English", [AppLanguage.ES]="Español", [AppLanguage.FR]="Français", [AppLanguage.DE]="Deutsch", [AppLanguage.LT]="Lituano" };
        var lang = new ComboBox { Height = 42, Margin = new Thickness(0, 4, 0, 12), ItemsSource = langItems, DisplayMemberPath="Value", SelectedValuePath="Key", SelectedValue = _settings.Language };
        var size = new Slider { Minimum = 12, Maximum = 24, Value = _settings.FontSize, TickFrequency = 1, IsSnapToTickEnabled = true, Margin = new Thickness(0, 6, 0, 16) };
        var sizeLabel = Txt($"{T("Tamanho do texto", "Text size", "Tamaño del texto", "Taille du texte", "Textgröße")}: {_settings.FontSize:0}", 14, FontWeights.Bold, "#9A94C7");
        size.ValueChanged += (_, __) => sizeLabel.Text = $"{T("Tamanho do texto", "Text size", "Tamaño del texto", "Taille du texte", "Textgröße")}: {size.Value:0}";
        root.Children.Add(Txt(T("Idioma da aplicação", "Application language", "Idioma de la aplicación", "Langue de l'application", "App-Sprache"), 14, FontWeights.Bold, "#9A94C7")); root.Children.Add(lang); root.Children.Add(sizeLabel); root.Children.Add(size);
        root.Children.Add(Txt(T("Temas rápidos", "Quick themes", "Temas rápidos", "Thèmes rapides", "Schnelle Designs"), 22, FontWeights.Black));
        var themeWrap = new WrapPanel { Margin = new Thickness(0, 4, 0, 18) };
        foreach (var kv in _themes)
        {
            var name = kv.Key; var colors = kv.Value;
            var tile = new Button { Width = 180, Height = 92, Margin = new Thickness(0, 0, 12, 12), Background = SafeBrush(colors.Card), BorderBrush = SafeBrush(colors.Accent), BorderThickness = new Thickness(2), Cursor = System.Windows.Input.Cursors.Hand };
            tile.Content = new StackPanel { Children = { Txt(name, 15, FontWeights.Black), new Border { Height = 14, Background = SafeBrush(colors.Button), CornerRadius = new CornerRadius(7), Margin = new Thickness(0, 6, 0, 0) } } };
            tile.Click += (_, __) => { _settings.Background = colors.Bg; _settings.Card = colors.Card; _settings.Button = colors.Button; _settings.Accent = colors.Accent; _store.Settings = _settings; ApplySettings(); ShowSettings(); };
            themeWrap.Children.Add(tile);
        }
        root.Children.Add(themeWrap);
        root.Children.Add(Txt(T("Cores personalizadas", "Custom colors", "Colores personalizados", "Couleurs personnalisées", "Benutzerdefinierte Farben"), 22, FontWeights.Black));
        root.Children.Add(Txt(T("Usa o formato #RRGGBB. A pré-visualização avisa se o valor estiver inválido e não fecha o programa.", "Use #RRGGBB. Preview warns if a value is invalid and will not close the program.", "Usa #RRGGBB. La vista previa avisa si el valor es inválido y no cierra el programa.", "Utilise #RRGGBB. L'aperçu avertit si la valeur est invalide et ne ferme pas le programme.", "Verwende #RRGGBB. Die Vorschau warnt bei ungültigem Wert und beendet das Programm nicht."), 14, null, "#9A94C7"));
        var bg = Input(_settings.Background); var card = Input(_settings.Card); var btn = Input(_settings.Button); var accent = Input(_settings.Accent); var error = Txt("", 14, FontWeights.Bold, "#FCA5A5");
        AddColorField(root, T("Fundo", "Background", "Fondo", "Fond", "Hintergrund"), bg); AddColorField(root, T("Cartões", "Cards", "Tarjetas", "Cartes", "Karten"), card); AddColorField(root, T("Botões", "Buttons", "Botones", "Boutons", "Schaltflächen"), btn); AddColorField(root, T("Destaque", "Accent", "Destacado", "Accent", "Akzent"), accent);
        root.Children.Add(Btn(T("Guardar e aplicar tudo", "Save and apply all", "Guardar y aplicar todo", "Enregistrer et appliquer", "Speichern und anwenden"), (_, __) =>
        {
            var values = new[] { bg.Text, card.Text, btn.Text, accent.Text };
            if (values.Any(v => !IsValidHex(v))) { error.Text = T("Há cores inválidas. Usa #RRGGBB, exemplo #7C3AED.", "Invalid colors. Use #RRGGBB, example #7C3AED.", "Hay colores inválidos. Usa #RRGGBB, ejemplo #7C3AED.", "Couleurs invalides. Utilise #RRGGBB, exemple #7C3AED.", "Ungültige Farben. Nutze #RRGGBB, Beispiel #7C3AED."); return; }
            _settings.Language = (AppLanguage)lang.SelectedValue; _settings.Background = bg.Text.Trim(); _settings.Card = card.Text.Trim(); _settings.Button = btn.Text.Trim(); _settings.Accent = accent.Text.Trim(); _settings.FontSize = size.Value; _store.Settings = _settings; ApplySettings(); ShowSettings();
        }));
        root.Children.Add(Btn(T("Repor tema padrão", "Reset default theme", "Restablecer tema", "Réinitialiser thème", "Design zurücksetzen"), (_, __) => { _settings = new AppSettings(); _store.Settings = _settings; ApplySettings(); ShowSettings(); }, false)); root.Children.Add(error);
        ViewHost.Children.Add(Card(root));
    }

    private void AddColorField(StackPanel root, string label, TextBox box)
    {
        root.Children.Add(Txt(label + " (#RRGGBB)", 14, FontWeights.Bold, "#9A94C7"));
        var row = new DockPanel(); var swatch = new Border { Width = 42, Height = 42, CornerRadius = new CornerRadius(12), Background = SafeBrush(box.Text), Margin = new Thickness(0, 4, 10, 12) }; DockPanel.SetDock(swatch, Dock.Left); row.Children.Add(swatch); row.Children.Add(box);
        box.TextChanged += (_, __) => { swatch.Background = IsValidHex(box.Text) ? SafeBrush(box.Text) : SafeBrush("#EF4444"); };
        root.Children.Add(row); var presets = new WrapPanel { Margin = new Thickness(0, -6, 0, 8) };
        foreach (var c in new[] { "#07061A", "#12103A", "#7C3AED", "#06B6D4", "#2563EB", "#16A34A", "#F4F7FB", "#FFFFFF", "#111827", "#E11D48", "#F59E0B", "#EC4899" }) { var b = new Button { Width = 28, Height = 28, Background = SafeBrush(c), BorderBrush = Brushes.White, BorderThickness = new Thickness(1), Margin = new Thickness(0, 0, 6, 6), ToolTip = c }; b.Click += (_, __) => box.Text = c; presets.Children.Add(b); }
        root.Children.Add(presets);
    }

    private void Home_Click(object s, RoutedEventArgs e) => ShowHome();
    private void Game_Click(object s, RoutedEventArgs e) => ShowGame();
    private void Ranking_Click(object s, RoutedEventArgs e) => ShowRanking();
    private void DuelRanking_Click(object s, RoutedEventArgs e) => ShowDuelRanking();
    private void Teacher_Click(object s, RoutedEventArgs e) => ShowTeacher();
    private void Stats_Click(object s, RoutedEventArgs e) => ShowStats();
    private void Rules_Click(object s, RoutedEventArgs e) => ShowRules();
    private void Settings_Click(object s, RoutedEventArgs e) => ShowSettings();
    private void Logout_Click(object s, RoutedEventArgs e) { _current = null; _connectionOk = false; UserBadge.Text = T("Sem sessão", "No session", "Sin sesión", "Sans session", "Keine Sitzung"); ApplySettings(); ShowLogin(); }
}
