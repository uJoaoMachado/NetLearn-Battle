using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.NetworkInformation;
using System.Net.Sockets;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Media;
using System.Windows.Threading;
using NetLearnBattle.Wpf.Modelos;
using NetLearnBattle.Wpf.Servicos;

namespace NetLearnBattle.Wpf;

public partial class MainWindow : Window
{
    private TextBlock Txt(string text, double size = 16, FontWeight? weight = null, string color = "#EDE9FF") => new()
    {
        Text = text,
        FontSize = size,
        FontWeight = weight ?? FontWeights.Normal,
        Foreground = SafeBrush(color, "#EDE9FF"),
        TextWrapping = TextWrapping.Wrap,
        Margin = new Thickness(0, 0, 0, 8)
    };
    private Border Card(UIElement child, Thickness? margin = null) => new()
    {
        Child = child,
        Style = (Style)FindResource("Card"),
        Margin = margin ?? new Thickness(0, 0, 0, 18),
        Background = SafeBrush(_settings.Card, "#12103A"),
        BorderBrush = SafeBrush(Blend(_settings.Accent, _settings.Card, 0.35), "#337C3AED")
    };
    private Button Btn(string text, RoutedEventHandler click, bool primary = true)
    {
        var b = new Button
        {
            Content = text,
            Style = (Style)FindResource(primary ? "PrimaryButton" : "GhostButton"),
            Margin = new Thickness(0, 8, 0, 0),
            MinHeight = 46,
            BorderThickness = new Thickness(1),
            BorderBrush = SafeBrush(_settings.Accent, "#06B6D4")
        };
        b.Click += click;
        b.Background = primary ? SafeBrush(_settings.Button, "#7C3AED") : SafeBrush(Blend(_settings.Button, _settings.Card, 0.35), "#4C1D95");
        b.Foreground = Brushes.White;
        return b;
    }
    private TextBox Input(string value = "") => new() { Text = value, Margin = new Thickness(0, 4, 0, 12) };
    private void Clear() => ViewHost.Children.Clear();

    private void ApplySettings()
    {
        _settings = SanitizeSettings(_settings);
        Root.Background = SafeBrush(_settings.Background, "#07061A");
        Sidebar.Background = SafeBrush(Blend(_settings.Background, "#000000", 0.40), "#0D0B26");
        FontSize = _settings.FontSize;
        CurrentSessionLabel.Text = T("Sessão atual", "Current session", "Sesión actual", "Session actuelle", "Aktuelle Sitzung");
        BtnLogout.Content = T("Sair", "Log out", "Salir", "Se déconnecter", "Abmelden");
        BtnHome.Content = "🏠 " + T("Início", "Home", "Inicio", "Accueil", "Start");
        BtnGame.Content = "🎮 " + T("Jogar", "Play", "Jugar", "Jouer", "Spielen");
        BtnRanking.Content = "🏆 " + T("Ranking", "Ranking", "Ranking", "Classement", "Rangliste");
        BtnDuelRanking.Content = "💎 " + T("Ranking 1v1", "1v1 Ranking", "Ranking 1v1", "Classement 1v1", "1v1-Rangliste");
        BtnRules.Content = "📘 " + T("Regras", "Rules", "Reglas", "Règles", "Regeln");
        BtnStats.Content = "📊 " + T("Estatísticas", "Statistics", "Estadísticas", "Statistiques", "Statistiken");
        BtnTeacher.Content = "🧑‍🏫 " + T("Servidor/Professor", "Server/Teacher", "Servidor/Profesor", "Serveur/Professeur", "Server/Lehrer");
        BtnSettings.Content = "⚙ " + T("Configurações", "Settings", "Configuración", "Paramètres", "Einstellungen");
        ConnectionBadge.Text = _server.IsRunning
            ? T($"Servidor local ativo: TCP {_lastTcpPort} · UDP {_lastUdpPort}", $"Local server running: TCP {_lastTcpPort} · UDP {_lastUdpPort}", $"Servidor local activo: TCP {_lastTcpPort} · UDP {_lastUdpPort}", $"Serveur local actif : TCP {_lastTcpPort} · UDP {_lastUdpPort}", $"Lokaler Server aktiv: TCP {_lastTcpPort} · UDP {_lastUdpPort}")
            : (_connectionOk ? T($"Ligado: {_connectedProtocol} {_connectedHost}:{_connectedPort}", $"Connected: {_connectedProtocol} {_connectedHost}:{_connectedPort}", $"Conectado: {_connectedProtocol} {_connectedHost}:{_connectedPort}", $"Connecté : {_connectedProtocol} {_connectedHost}:{_connectedPort}", $"Verbunden: {_connectedProtocol} {_connectedHost}:{_connectedPort}") : T("Servidor: não ligado", "Server: not connected", "Servidor: no conectado", "Serveur : non connecté", "Server: nicht verbunden"));
        ConnectionBadge.Foreground = (_connectionOk || _server.IsRunning) ? SafeBrush("#86EFAC", "#86EFAC") : SafeBrush("#9A94C7", "#9A94C7");
        UpdateNavigationAccess();
    }

    private void UpdateNavigationAccess()
    {
        var role = _current?.Role ?? Role.Guest;
        var loggedIn = _current is not null && role != Role.Guest;
        BtnHome.IsEnabled = true;
        BtnRanking.IsEnabled = true;
        BtnDuelRanking.IsEnabled = loggedIn && (role == Role.Student || role == Role.Teacher);
        BtnRules.IsEnabled = true;
        BtnGame.IsEnabled = loggedIn && role == Role.Student;
        BtnStats.IsEnabled = loggedIn && (role == Role.Student || role == Role.Teacher);
        BtnTeacher.IsEnabled = loggedIn && role == Role.Teacher;
        BtnSettings.IsEnabled = loggedIn;
        foreach (var b in new[] { BtnGame, BtnDuelRanking, BtnStats, BtnTeacher, BtnSettings }) b.Opacity = b.IsEnabled ? 1 : 0.35;
    }
}
