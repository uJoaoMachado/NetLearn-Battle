using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.NetworkInformation;
using System.Net.Sockets;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Media;
using System.Windows.Threading;
using NetLearnBattle.Wpf.Modelos;
using NetLearnBattle.Wpf.Servicos;

namespace NetLearnBattle.Wpf;

public partial class MainWindow : Window
{
    private void ShowLogin()
    {
        Clear();
        _current = null;
        UserBadge.Text = T("Sem sessão", "No session", "Sin sesión", "Sans session", "Keine Sitzung");
        ApplySettings();

        var grid = new Grid();
        grid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
        grid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });

        var left = new StackPanel { Margin = new Thickness(0, 0, 28, 0) };
        left.Children.Add(Txt("NetLearn Battle", 46, FontWeights.Black));
        left.Children.Add(Txt(T("Jogo educativo de redes com IPv4, IPv6, ACLs, ranking e comunicação TCP/UDP.", "Educational networking game with IPv4, IPv6, ACLs, ranking and TCP/UDP communication.", "Juego educativo de redes con IPv4, IPv6, ACLs, ranking y comunicación TCP/UDP.", "Jeu éducatif de réseaux avec IPv4, IPv6, ACL, classement et communication TCP/UDP.", "Lernspiel zu Netzwerken mit IPv4, IPv6, ACLs, Rangliste und TCP/UDP-Kommunikation."), 18, FontWeights.SemiBold, "#9A94C7"));
        left.Children.Add(Card(new StackPanel { Children = { Txt("🎯 " + T("Regras da ficha", "Assignment rules", "Reglas de la ficha", "Règles du sujet", "Aufgabenregeln"), 22, FontWeights.Bold), Txt(T("Guest só vê Ranking Top 5 e Regras. Aluno autenticado joga e vê estatísticas. Professor inicia o servidor.", "Guest only sees Top 5 Ranking and Rules. Authenticated students play and see statistics. Teacher starts the server.", "Guest solo ve Ranking Top 5 y Reglas. El alumno autenticado juega y ve estadísticas. El profesor inicia el servidor.", "Guest voit seulement le Top 5 et les règles. L'élève connecté joue et voit les statistiques. Le professeur démarre le serveur.", "Guest sieht nur Top-5-Rangliste und Regeln. Angemeldete Schüler spielen und sehen Statistiken. Lehrer starten den Server."), 15, null, "#9A94C7") } }, new Thickness(0, 22, 0, 14)));
        left.Children.Add(Card(new StackPanel { Children = { Txt("🌐 " + T("Servidor obrigatório no modo rede", "Server required for network mode", "Servidor obligatorio en modo red", "Serveur requis en mode réseau", "Server für Netzwerkmodus erforderlich"), 22, FontWeights.Bold), Txt(T("Entra como professor para abrir o painel Servidor/Professor e iniciar TCP/UDP. No ecrã de entrada podes testar a ligação.", "Sign in as teacher to open Server/Teacher and start TCP/UDP. On this screen you can test the connection.", "Entra como profesor para abrir Servidor/Profesor e iniciar TCP/UDP. En esta pantalla puedes probar la conexión.", "Connecte-toi comme professeur pour ouvrir Serveur/Professeur et démarrer TCP/UDP. Tu peux tester la connexion ici.", "Melde dich als Lehrer an, um Server/Lehrer zu öffnen und TCP/UDP zu starten. Hier kannst du die Verbindung testen."), 15, null, "#9A94C7") } }));
        Grid.SetColumn(left, 0); grid.Children.Add(left);

        var form = new StackPanel();
        form.Children.Add(Txt(T("Entrar / Registar", "Sign in / Register", "Entrar / Registrar", "Connexion / Inscription", "Anmelden / Registrieren"), 32, FontWeights.Black));

        var host = Input(_connectedHost);
        var port = Input(_connectedPort.ToString());
        var protocol = new ComboBox { Height = 42, Margin = new Thickness(0, 4, 0, 12), ItemsSource = Enum.GetValues(typeof(ProtocolMode)), SelectedItem = _connectedProtocol };
        var connectionMsg = Txt(_connectionOk ? T("Ligação validada.", "Connection validated.", "Conexión validada.", "Connexion validée.", "Verbindung geprüft.") : T("Testa a ligação ao servidor do professor antes de jogar em rede.", "Test the teacher server connection before network play.", "Prueba la conexión al servidor del profesor antes de jugar en red.", "Teste la connexion au serveur du professeur avant le jeu réseau.", "Teste die Verbindung zum Lehrer-Server vor dem Netzwerkspiel."), 13, FontWeights.Bold, _connectionOk ? "#86EFAC" : "#9A94C7");
        form.Children.Add(Card(new StackPanel { Children = { Txt("🔌 " + T("Ligação ao servidor", "Server connection", "Conexión al servidor", "Connexion au serveur", "Serververbindung"), 20, FontWeights.Black), Txt("IP / Host", 13, FontWeights.Bold, "#9A94C7"), host, Txt(T("Porta", "Port", "Puerto", "Port", "Port"), 13, FontWeights.Bold, "#9A94C7"), port, Txt(T("Protocolo", "Protocol", "Protocolo", "Protocole", "Protokoll"), 13, FontWeights.Bold, "#9A94C7"), protocol, Btn(T("Testar ligação", "Test connection", "Probar conexión", "Tester la connexion", "Verbindung testen"), async (_, __) => await TestConnectionAsync(host.Text, port.Text, (ProtocolMode)protocol.SelectedItem, connectionMsg), false), connectionMsg } }, new Thickness(0, 8, 0, 18)));

        var username = Input("");
        var password = new PasswordBox { Margin = new Thickness(0, 4, 0, 12) };
        var msg = Txt("", 14, FontWeights.Bold, "#FCA5A5");
        form.Children.Add(Txt(T("Utilizador", "Username", "Usuario", "Utilisateur", "Benutzer"), 14, FontWeights.Bold, "#9A94C7")); form.Children.Add(username);
        form.Children.Add(Txt(T("Palavra-passe", "Password", "Contraseña", "Mot de passe", "Passwort"), 14, FontWeights.Bold, "#9A94C7")); form.Children.Add(password);
        form.Children.Add(Btn(T("Entrar", "Sign in", "Entrar", "Se connecter", "Anmelden"), (_, __) => DoLogin(username.Text, password.Password, msg)));
        form.Children.Add(Btn(T("Criar conta de aluno", "Create student account", "Crear cuenta de alumno", "Créer un compte élève", "Schülerkonto erstellen"), (_, __) => DoRegister(username.Text, password.Password, msg), false));
        form.Children.Add(Btn(T("Entrar como Guest", "Continue as Guest", "Entrar como invitado", "Continuer comme Guest", "Als Guest fortfahren"), (_, __) => { _current = new User { Username = "Guest", Role = Role.Guest }; UserBadge.Text = T("Guest · acesso limitado", "Guest · limited access", "Guest · acceso limitado", "Guest · accès limité", "Guest · eingeschränkter Zugriff"); ApplySettings(); ShowHome(); }, false));
        form.Children.Add(msg);
        Grid.SetColumn(form, 1); grid.Children.Add(Card(form));
        ViewHost.Children.Add(grid);
    }


    private List<string> GetUsableLocalIps()
    {
        try
        {
            return NetworkInterface.GetAllNetworkInterfaces()
                .Where(n => n.OperationalStatus == OperationalStatus.Up
                            && n.NetworkInterfaceType != NetworkInterfaceType.Loopback
                            && n.GetIPProperties().GatewayAddresses.Any())
                .SelectMany(n => n.GetIPProperties().UnicastAddresses)
                .Where(a => a.Address.AddressFamily == AddressFamily.InterNetwork)
                .Select(a => a.Address.ToString())
                .Where(ip => !ip.StartsWith("169.254.") && ip != "127.0.0.1")
                .Distinct()
                .OrderBy(ip => ip.StartsWith("192.168.") ? 0 : ip.StartsWith("10.") ? 1 : ip.StartsWith("172.") ? 2 : 3)
                .ToList();
        }
        catch { return new List<string>(); }
    }

    private string GetLocalIpAddress() => GetUsableLocalIps().FirstOrDefault() ?? "127.0.0.1";

    private static bool IsPortFree(int port, bool udp = false)
    {
        try
        {
            if (udp)
            {
                using var u = new UdpClient();
                u.Client.Bind(new IPEndPoint(IPAddress.Any, port));
                return true;
            }
            var listener = new TcpListener(IPAddress.Loopback, port);
            listener.Start();
            listener.Stop();
            return true;
        }
        catch { return false; }
    }

    private static (int Tcp, int Udp) FindAvailablePorts(int preferredTcp, int preferredUdp)
    {
        var tcp = preferredTcp;
        var udp = preferredUdp;
        for (int offset = 0; offset < 200; offset++)
        {
            var t = Math.Min(65535, preferredTcp + offset);
            var u = Math.Min(65535, preferredUdp + offset);
            if (IsPortFree(t, false) && IsPortFree(u, true))
                return (t, u);
        }
        return (tcp, udp);
    }

    private async Task TestConnectionAsync(string host, string portText, ProtocolMode mode, TextBlock status)
    {
        if (!int.TryParse(portText, out var port) || port <= 0 || port > 65535)
        { status.Text = T("Porta inválida.", "Invalid port.", "Puerto inválido.", "Port invalide.", "Ungültiger Port."); status.Foreground = SafeBrush("#FCA5A5"); return; }
        try
        {
            if (mode == ProtocolMode.TCP)
            {
                using var tcp = new TcpClient();
                var connectTask = tcp.ConnectAsync(host.Trim(), port);
                if (await Task.WhenAny(connectTask, Task.Delay(1800)) != connectTask) throw new TimeoutException();
                if (!tcp.Connected) throw new SocketException();
                using var stream = tcp.GetStream();
                using var writer = new StreamWriter(stream, Encoding.UTF8, leaveOpen: true) { AutoFlush = true };
                using var reader = new StreamReader(stream, Encoding.UTF8, leaveOpen: true);
                await writer.WriteLineAsync("PING");
                var responseTask = reader.ReadLineAsync();
                if (await Task.WhenAny(responseTask, Task.Delay(1800)) != responseTask) throw new TimeoutException();
            }
            else
            {
                using var udp = new UdpClient();
                var data = Encoding.UTF8.GetBytes("PING");
                await udp.SendAsync(data, data.Length, host.Trim(), port);
                var receive = udp.ReceiveAsync();
                if (await Task.WhenAny(receive, Task.Delay(1800)) != receive) throw new TimeoutException();
            }
            _connectedHost = host.Trim(); _connectedPort = port; _connectedProtocol = mode; _connectionOk = true; StartServerMonitor();
            status.Text = T("Ligação feita com sucesso.", "Connection successful.", "Conexión correcta.", "Connexion réussie.", "Verbindung erfolgreich.");
            status.Foreground = SafeBrush("#86EFAC");
        }
        catch
        {
            _connectionOk = false;
            status.Text = T("Não foi possível ligar. Confirma se o professor iniciou o servidor TCP/UDP.", "Could not connect. Check if the teacher started the TCP/UDP server.", "No fue posible conectar. Confirma si el profesor inició el servidor TCP/UDP.", "Connexion impossible. Vérifie que le professeur a démarré le serveur TCP/UDP.", "Verbindung nicht möglich. Prüfe, ob der Lehrer den TCP/UDP-Server gestartet hat.");
            status.Foreground = SafeBrush("#FCA5A5");
        }
        ApplySettings();
    }

    private void DoLogin(string name, string pass, TextBlock msg)
    {
        var u = _store.Users.FirstOrDefault(x => x.Username.Equals(name.Trim(), StringComparison.OrdinalIgnoreCase) && JsonStore.VerifyPassword(x, pass));
        if (u is null) { msg.Text = T("Dados inválidos.", "Invalid credentials.", "Datos inválidos.", "Identifiants invalides.", "Ungültige Daten."); return; }
        _store.UpgradeUserSalt(u, pass);
        _current = u; UserBadge.Text = $"{u.Username} · {RoleText(u.Role)}"; ApplySettings();
        if (u.Role == Role.Teacher) ShowTeacher(); else ShowHome();
    }

    private void DoRegister(string name, string pass, TextBlock msg)
    {
        name = name.Trim();
        if (string.IsNullOrWhiteSpace(name) || string.IsNullOrWhiteSpace(pass)) { msg.Text = T("Preenche utilizador e palavra-passe.", "Fill username and password.", "Completa usuario y contraseña.", "Remplis utilisateur et mot de passe.", "Benutzer und Passwort ausfüllen."); return; }
        var users = _store.Users;
        if (users.Any(x => x.Username.Equals(name, StringComparison.OrdinalIgnoreCase))) { msg.Text = T("Utilizador já existe.", "User already exists.", "Usuario ya existe.", "Utilisateur déjà existant.", "Benutzer existiert bereits."); return; }
        var salt = JsonStore.CreateSalt();
        var nu = new User { Username = name, Salt = salt, PasswordHash = JsonStore.Hash(pass, salt), Role = Role.Student };
        users.Add(nu); _store.Users = users; _current = nu; UserBadge.Text = $"{nu.Username} · {RoleText(nu.Role)}"; ApplySettings(); ShowHome();
    }
}
