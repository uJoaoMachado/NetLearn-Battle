using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.NetworkInformation;
using System.Net.Sockets;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Media;
using System.Windows.Threading;
using NetLearnBattle.Wpf.Modelos;
using NetLearnBattle.Wpf.Servicos;

namespace NetLearnBattle.Wpf;

public partial class MainWindow : Window
{
    private async void ShowRanking()
    {
        Clear();
        ViewHost.Children.Add(Txt("🏆 " + T("Ranking Top 5", "Top 5 Ranking", "Ranking Top 5", "Top 5", "Top 5 Rangliste"), 36, FontWeights.Black));
        ViewHost.Children.Add(Txt(T("Só aparecem os 5 melhores jogadores, como pedido na ficha. O pódio destaca os três primeiros e a tabela confirma o Top 5.", "Only the 5 best players are shown, as required. The podium highlights the top three and the table confirms the Top 5.", "Solo aparecen los 5 mejores jugadores, como se pide. El podio destaca los tres primeros y la tabla confirma el Top 5.", "Seuls les 5 meilleurs joueurs sont affichés. Le podium met en avant les trois premiers et le tableau confirme le Top 5.", "Es werden nur die 5 besten Spieler angezeigt. Das Podium hebt die ersten drei hervor und die Tabelle bestätigt die Top 5."), 16, null, "#9A94C7"));

        List<RankingDto>? remote = null;
        var isServerSource = _server.IsRunning;
        if (!isServerSource)
        {
            remote = await TryFetchRankingFromServerAsync();
            isServerSource = remote is not null;
        }

        var baseList = (_server.IsRunning ? null : remote) ?? UniqueScores(_store.Scores)
            .GroupBy(s => s.Username)
            .Select(g => new RankingDto { Username = g.Key, Score = g.Sum(x => x.Score), Total = g.Sum(x => x.Total), Correct = g.Sum(x => x.Correct) })
            .ToList();

        var list = baseList
            .OrderByDescending(x => x.Score)
            .ThenByDescending(x => x.Correct)
            .ThenBy(x => x.Username)
            .Take(5)
            .ToList();

        var root = new StackPanel { Margin = new Thickness(0, 12, 0, 0) };
        var sourceText = isServerSource
            ? T("Ranking atualizado pelo servidor no momento.", "Ranking updated live from the server.", "Ranking actualizado por el servidor en este momento.", "Classement actualisé par le serveur en direct.", "Rangliste aktuell vom Server aktualisiert.")
            : T("Ranking local deste computador.", "Local ranking from this computer.", "Ranking local de este ordenador.", "Classement local de cet ordinateur.", "Lokale Rangliste von diesem Computer.");
        root.Children.Add(Txt(sourceText, 14, FontWeights.Bold, isServerSource ? "#86EFAC" : "#FDE68A"));

        if (!list.Any())
        {
            var empty = new StackPanel();
            empty.Children.Add(Txt("📭", 44, FontWeights.Black));
            empty.Children.Add(Txt(T("Ainda não existem pontuações.", "No scores yet.", "Aún no hay puntuaciones.", "Pas encore de scores.", "Noch keine Punkte."), 22, FontWeights.Bold));
            empty.Children.Add(Txt(T("Joga uma sessão para aparecer aqui.", "Play a session to appear here.", "Juega una sesión para aparecer aquí.", "Joue une session pour apparaître ici.", "Spiele eine Runde, um hier zu erscheinen."), 15, null, "#9A94C7"));
            root.Children.Add(Card(empty));
            ViewHost.Children.Add(root);
            return;
        }

        var podium = new Grid { Margin = new Thickness(0, 16, 0, 18) };
        podium.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
        podium.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1.15, GridUnitType.Star) });
        podium.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });

        Border PodiumCard(RankingDto entry, int position, string medal, int minHeight, string color)
        {
            var accuracy = entry.Total == 0 ? 0 : (int)Math.Round(entry.Correct * 100.0 / entry.Total);
            var panel = new StackPanel { MinHeight = minHeight, VerticalAlignment = VerticalAlignment.Center };
            panel.Children.Add(Txt(medal, position == 1 ? 48 : 38, FontWeights.Black));
            panel.Children.Add(Txt($"#{position}", 16, FontWeights.Black, color));
            panel.Children.Add(Txt(entry.Username, position == 1 ? 26 : 21, FontWeights.Black));
            panel.Children.Add(Txt($"{entry.Score} pts", position == 1 ? 34 : 28, FontWeights.Black, _settings.Accent));
            panel.Children.Add(Txt($"{accuracy}% " + T("acerto", "accuracy", "acierto", "réussite", "Trefferquote"), 14, FontWeights.Bold, "#C4B5FD"));
            panel.Children.Add(Txt($"{entry.Correct}/{entry.Total} " + T("certas", "correct", "correctas", "correctes", "richtig"), 13, null, "#9A94C7"));
            return Card(panel, new Thickness(0, 0, 14, 0));
        }

        // Ordem visual de pódio: 2.º, 1.º, 3.º
        if (list.Count > 1) { var c = PodiumCard(list[1], 2, "🥈", 185, "#D1D5DB"); Grid.SetColumn(c, 0); podium.Children.Add(c); }
        if (list.Count > 0) { var c = PodiumCard(list[0], 1, "👑", 220, "#FDE68A"); Grid.SetColumn(c, list.Count > 1 ? 1 : 0); podium.Children.Add(c); }
        if (list.Count > 2) { var c = PodiumCard(list[2], 3, "🥉", 185, "#FDBA74"); Grid.SetColumn(c, 2); podium.Children.Add(c); }
        root.Children.Add(podium);

        var table = new StackPanel();
        table.Children.Add(Txt(T("Top 5 completo", "Full Top 5", "Top 5 completo", "Top 5 complet", "Vollständige Top 5"), 24, FontWeights.Black));
        int pos = 1;
        foreach (var entry in list)
        {
            var accuracy = entry.Total == 0 ? 0 : (int)Math.Round(entry.Correct * 100.0 / entry.Total);
            var row = new Grid { Margin = new Thickness(0, 8, 0, 0), MinHeight = 64 };
            row.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(70) });
            row.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
            row.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(130) });
            row.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(130) });
            row.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(120) });

            var rank = Txt(pos == 1 ? "👑 #1" : "#" + pos, 21, FontWeights.Black, pos == 1 ? "#FDE68A" : "#EDE9FF");
            rank.VerticalAlignment = VerticalAlignment.Center; Grid.SetColumn(rank, 0); row.Children.Add(rank);

            var nameBox = new StackPanel { VerticalAlignment = VerticalAlignment.Center };
            nameBox.Children.Add(Txt(entry.Username, 18, FontWeights.Bold));
            nameBox.Children.Add(Txt(T("Jogador", "Player", "Jugador", "Joueur", "Spieler"), 12, null, "#9A94C7"));
            Grid.SetColumn(nameBox, 1); row.Children.Add(nameBox);

            var score = Txt(entry.Score + " pts", 18, FontWeights.Black, _settings.Accent);
            score.VerticalAlignment = VerticalAlignment.Center; Grid.SetColumn(score, 2); row.Children.Add(score);

            var answered = Txt(entry.Total + " " + T("perguntas", "questions", "preguntas", "questions", "Fragen"), 16, FontWeights.Bold, "#C4B5FD");
            answered.VerticalAlignment = VerticalAlignment.Center; Grid.SetColumn(answered, 3); row.Children.Add(answered);

            var acc = Txt(accuracy + "%", 18, FontWeights.Black, accuracy >= 70 ? "#86EFAC" : accuracy >= 40 ? "#FDE68A" : "#FCA5A5");
            acc.VerticalAlignment = VerticalAlignment.Center; Grid.SetColumn(acc, 4); row.Children.Add(acc);

            table.Children.Add(Card(row, new Thickness(0, 0, 0, 10)));
            pos++;
        }
        root.Children.Add(Card(table));
        ViewHost.Children.Add(root);
    }

    private static List<Attempt> UniqueAttempts(IEnumerable<Attempt> source)
    {
        var list = source.ToList();
        if (list.Any(a => !string.IsNullOrWhiteSpace(a.Id)))
        {
            return list
                .GroupBy(a => string.IsNullOrWhiteSpace(a.Id) ? Guid.NewGuid().ToString("N") : a.Id)
                .Select(g => g.First())
                .OrderByDescending(a => a.Date)
                .ToList();
        }
        return list.OrderByDescending(a => a.Date).ToList();
    }

    private static List<ScoreEntry> UniqueScores(IEnumerable<ScoreEntry> source)
    {
        var list = source.ToList();
        if (list.Any(s => !string.IsNullOrWhiteSpace(s.Id)))
        {
            return list
                .GroupBy(s => string.IsNullOrWhiteSpace(s.Id) ? Guid.NewGuid().ToString("N") : s.Id)
                .Select(g => g.First())
                .ToList();
        }
        return list;
    }

    private Border StatCard(string title, string value, string sub, string emoji)
    {
        var sp = new StackPanel { Width = 230 };
        sp.Children.Add(Txt(emoji, 28, FontWeights.Black));
        sp.Children.Add(Txt(title, 14, FontWeights.Bold, "#9A94C7"));
        sp.Children.Add(Txt(value, 30, FontWeights.Black, _settings.Accent));
        sp.Children.Add(Txt(sub, 13, null, "#9A94C7"));
        return Card(sp, new Thickness(0,0,14,14));
    }

    private void ShowStats()
    {
        if (_current is null || _current.Role == Role.Guest) { MessageBox.Show(T("Estatísticas só para alunos ou professor autenticado.", "Statistics are only for authenticated students or teacher.", "Estadísticas solo para alumnos o profesor autenticado.", "Statistiques seulement pour élèves ou professeur connectés.", "Statistiken nur für angemeldete Schüler oder Lehrer.")); ShowHome(); return; }
        Clear();
        var isTeacher = _current.Role == Role.Teacher;
        ViewHost.Children.Add(Txt(isTeacher ? "📊 " + T("Relatórios globais", "Global reports", "Informes globales", "Rapports globaux", "Globale Berichte") : "📊 " + T("Minhas estatísticas", "My statistics", "Mis estadísticas", "Mes statistiques", "Meine Statistiken"), 36, FontWeights.Black));

        var attempts = UniqueAttempts(isTeacher
            ? _store.Attempts
            : _store.Attempts.Where(a => a.Username.Equals(_current.Username, StringComparison.OrdinalIgnoreCase)));
        var scoreRows = isTeacher ? _store.Scores : _store.Scores.Where(a => a.Username.Equals(_current.Username, StringComparison.OrdinalIgnoreCase)).ToList();
        var total = attempts.Count;
        var correct = attempts.Count(a => a.Correct);
        var wrong = total - correct;
        var score = scoreRows.Sum(a => a.Score);
        var players = _store.Scores.Select(s => s.Username).Distinct(StringComparer.OrdinalIgnoreCase).Count();
        var accuracy = total == 0 ? 0 : Math.Round(correct * 100.0 / total, 1);
        var avgTime = total == 0 ? 0 : Math.Round(attempts.Average(a => a.DurationSeconds), 1);
        var orderedTimes = attempts.Select(a => a.DurationSeconds).OrderBy(x => x).ToList();
        var medianTime = orderedTimes.Count == 0 ? 0 : Math.Round(orderedTimes.Count % 2 == 1 ? orderedTimes[orderedTimes.Count / 2] : (orderedTimes[orderedTimes.Count / 2 - 1] + orderedTimes[orderedTimes.Count / 2]) / 2.0, 1);
        var modeTime = orderedTimes.GroupBy(x => x).OrderByDescending(g => g.Count()).ThenBy(g => g.Key).FirstOrDefault()?.Key ?? 0;

        var wrap = new WrapPanel { Margin = new Thickness(0,18,0,0) };
        wrap.Children.Add(StatCard(T("Pontuação", "Score", "Puntuación", "Score", "Punkte"), score + " pts", isTeacher ? T("total global", "global total", "total global", "total global", "gesamt") : T("total pessoal", "personal total", "total personal", "total personnel", "persönlich"), "⭐"));
        wrap.Children.Add(StatCard(T("Acerto", "Accuracy", "Acierto", "Réussite", "Treffer"), accuracy + "%", $"{correct} {T("certas", "correct", "correctas", "correctes", "richtig")} / {wrong} {T("erradas", "wrong", "incorrectas", "fausses", "falsch")}", "🎯"));
        wrap.Children.Add(StatCard(T("Perguntas", "Questions", "Preguntas", "Questions", "Fragen"), total.ToString(), T("respondidas", "answered", "respondidas", "répondues", "beantwortet"), "🧩"));
        wrap.Children.Add(StatCard(T("Tempo médio", "Average time", "Tiempo medio", "Temps moyen", "Durchschnitt"), avgTime + "s", T("por resposta", "per answer", "por respuesta", "par réponse", "pro Antwort"), "⏱"));
        wrap.Children.Add(StatCard(T("Mediana", "Median", "Mediana", "Médiane", "Median"), medianTime + "s", T("tempo de resposta", "response time", "tiempo de respuesta", "temps de réponse", "Antwortzeit"), "📐"));
        wrap.Children.Add(StatCard(T("Moda", "Mode", "Moda", "Mode", "Modus"), modeTime + "s", T("tempo mais comum", "most common time", "tiempo más común", "temps le plus courant", "häufigste Zeit"), "📌"));
        if (isTeacher) wrap.Children.Add(StatCard(T("Jogadores", "Players", "Jugadores", "Joueurs", "Spieler"), players.ToString(), T("com pontuação", "with score", "con puntuación", "avec score", "mit Punkten"), "👥"));
        ViewHost.Children.Add(wrap);

        var levelPanel = new StackPanel();
        levelPanel.Children.Add(Txt(T("Desempenho por nível", "Performance by level", "Rendimiento por nivel", "Performance par niveau", "Leistung pro Level"), 24, FontWeights.Black));
        for (int i = 1; i <= 5; i++)
        {
            var levelAttempts = attempts.Where(a => a.Level == i).ToList();
            var lTotal = levelAttempts.Count;
            var lCorrect = levelAttempts.Count(a => a.Correct);
            var pct = lTotal == 0 ? 0 : (int)Math.Round(lCorrect * 100.0 / lTotal);
            levelPanel.Children.Add(Txt($"{T("Nível", "Level", "Nivel", "Niveau", "Level")} {i} · {LevelName(i)} — {pct}% ({lCorrect}/{lTotal})", 15, FontWeights.Bold, "#EDE9FF"));
            levelPanel.Children.Add(new ProgressBar { Minimum = 0, Maximum = 100, Value = pct, Height = 12, Margin = new Thickness(0,0,0,10), Foreground = SafeBrush(_settings.Accent), Background = SafeBrush(Blend(_settings.Card, "#000000", 0.25)) });
        }
        ViewHost.Children.Add(Card(levelPanel));

        var weakPanel = new StackPanel();
        weakPanel.Children.Add(Txt("🧠 " + T("Tópicos onde mais falha", "Weakest topics", "Temas con más fallos", "Sujets les plus faibles", "Schwächste Themen"), 24, FontWeights.Black));
        var weakTopics = attempts.Where(a => !a.Correct).GroupBy(a => a.Level).OrderByDescending(g => g.Count()).Select(g => $"{T("Nível", "Level", "Nivel", "Niveau", "Level")} {g.Key} · {LevelName(g.Key)} ({g.Count()})").Take(5).ToList();
        if (!weakTopics.Any()) weakPanel.Children.Add(Txt(T("Ainda não há falhas suficientes para analisar.", "There are not enough mistakes to analyse yet.", "Aún no hay fallos suficientes para analizar.", "Il n’y a pas encore assez d’erreurs à analyser.", "Es gibt noch nicht genug Fehler zur Analyse."), 15, null, "#9A94C7"));
        foreach (var topic in weakTopics) weakPanel.Children.Add(Txt("• " + topic, 15, FontWeights.Bold, "#EDE9FF"));
        ViewHost.Children.Add(Card(weakPanel));

        if (isTeacher)
        {
            var playersPanel = new StackPanel();
            playersPanel.Children.Add(Txt("👥 " + T("Estatísticas por jogador", "Stats by player", "Estadísticas por jugador", "Statistiques par joueur", "Statistiken pro Spieler"), 24, FontWeights.Black));
            playersPanel.Children.Add(Txt(T("Resumo individual para o professor analisar cada aluno separadamente.", "Individual summary so the teacher can analyse each student separately.", "Resumen individual para que el profesor analice cada alumno por separado.", "Résumé individuel pour analyser chaque élève séparément.", "Individuelle Übersicht, damit der Lehrer jeden Schüler einzeln analysieren kann."), 14, null, "#9A94C7"));

            var playerRows = _store.Scores
                .GroupBy(s => s.Username, StringComparer.OrdinalIgnoreCase)
                .Select(g =>
                {
                    var userAttempts = UniqueAttempts(_store.Attempts.Where(a => a.Username.Equals(g.Key, StringComparison.OrdinalIgnoreCase)));
                    var userTotal = userAttempts.Count;
                    var userCorrect = userAttempts.Count(a => a.Correct);
                    var userAccuracy = userTotal == 0 ? 0 : (int)Math.Round(userCorrect * 100.0 / userTotal);
                    var last = userAttempts.OrderByDescending(a => a.Date).FirstOrDefault()?.Date;
                    return new
                    {
                        Username = g.Key,
                        Score = g.Sum(x => x.Score),
                        Total = userTotal,
                        Correct = userCorrect,
                        Accuracy = userAccuracy,
                        Last = last
                    };
                })
                .OrderByDescending(x => x.Score)
                .ThenByDescending(x => x.Accuracy)
                .ThenBy(x => x.Username)
                .ToList();

            if (!playerRows.Any())
            {
                playersPanel.Children.Add(Txt(T("Ainda não existem jogadores com pontuação.", "There are no players with scores yet.", "Aún no hay jugadores con puntuación.", "Il n’y a pas encore de joueurs avec score.", "Es gibt noch keine Spieler mit Punkten."), 16, null, "#9A94C7"));
            }
            else
            {
                foreach (var pRow in playerRows)
                {
                    var row = new Grid { MinHeight = 74, Margin = new Thickness(0, 8, 0, 0) };
                    row.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
                    row.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(120) });
                    row.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(140) });
                    row.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(120) });

                    var name = new StackPanel { VerticalAlignment = VerticalAlignment.Center };
                    name.Children.Add(Txt("👤 " + pRow.Username, 18, FontWeights.Black));
                    name.Children.Add(Txt(pRow.Last.HasValue ? T("Última resposta: ", "Last answer: ", "Última respuesta: ", "Dernière réponse : ", "Letzte Antwort: ") + pRow.Last.Value.ToString("g") : T("Sem respostas registadas", "No answers recorded", "Sin respuestas registradas", "Aucune réponse enregistrée", "Keine Antworten gespeichert"), 12, null, "#9A94C7"));
                    Grid.SetColumn(name, 0); row.Children.Add(name);

                    var scoreTxt = Txt(pRow.Score + " pts", 18, FontWeights.Black, _settings.Accent);
                    scoreTxt.VerticalAlignment = VerticalAlignment.Center; Grid.SetColumn(scoreTxt, 1); row.Children.Add(scoreTxt);

                    var answeredTxt = Txt($"{pRow.Correct}/{pRow.Total} " + T("certas", "correct", "correctas", "correctes", "richtig"), 16, FontWeights.Bold, "#C4B5FD");
                    answeredTxt.VerticalAlignment = VerticalAlignment.Center; Grid.SetColumn(answeredTxt, 2); row.Children.Add(answeredTxt);

                    var accTxt = Txt(pRow.Accuracy + "%", 18, FontWeights.Black, pRow.Accuracy >= 70 ? "#86EFAC" : pRow.Accuracy >= 40 ? "#FDE68A" : "#FCA5A5");
                    accTxt.VerticalAlignment = VerticalAlignment.Center; Grid.SetColumn(accTxt, 3); row.Children.Add(accTxt);

                    playersPanel.Children.Add(Card(row, new Thickness(0, 0, 0, 10)));
                }
            }

            ViewHost.Children.Add(Card(playersPanel));

            var duelPanel = new StackPanel();
            duelPanel.Children.Add(Txt("💎 " + T("Ranking 1v1 dos alunos", "Students' 1v1 ranking", "Ranking 1v1 de alumnos", "Classement 1v1 des élèves", "1v1-Rangliste der Schüler"), 24, FontWeights.Black));
            duelPanel.Children.Add(Txt(T("Ranks online separados: Bronze, Prata, Ouro, Diamante e Mestre.", "Separate online ranks: Bronze, Silver, Gold, Diamond and Master.", "Rangos online separados: Bronce, Plata, Oro, Diamante y Maestro.", "Rangs en ligne séparés : Bronze, Argent, Or, Diamant et Maître.", "Separate Online-Ränge: Bronze, Silber, Gold, Diamant und Meister."), 14, null, "#9A94C7"));
            var duelRows = _store.DuelRanks.OrderByDescending(x => x.Points).ThenByDescending(x => x.Wins).ThenBy(x => x.Username).ToList();
            if (!duelRows.Any())
            {
                duelPanel.Children.Add(Txt(T("Ainda não existem duelos 1v1 concluídos.", "No completed 1v1 duels yet.", "Aún no hay duelos 1v1 completados.", "Aucun duel 1v1 terminé pour l'instant.", "Noch keine abgeschlossenen 1v1-Duelle."), 16, null, "#9A94C7"));
            }
            else
            {
                int dpos = 1;
                foreach (var dr in duelRows.Take(10))
                {
                    var rankName = string.IsNullOrWhiteSpace(dr.Rank) ? (dr.Points >= 800 ? "Mestre" : dr.Points >= 500 ? "Diamante" : dr.Points >= 250 ? "Ouro" : dr.Points >= 100 ? "Prata" : "Bronze") : dr.Rank;
                    var row = new Grid { MinHeight = 68, Margin = new Thickness(0, 8, 0, 0) };
                    row.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(70) });
                    row.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
                    row.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(150) });
                    row.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(190) });
                    var posTxt = Txt("#" + dpos, 20, FontWeights.Black, dpos == 1 ? "#FDE68A" : "#EDE9FF");
                    var nameTxt = Txt("👤 " + dr.Username, 18, FontWeights.Black);
                    var ptsTxt = Txt(dr.Points + " pts", 18, FontWeights.Black, "#86EFAC");
                    var rankTxt = Txt(RankIcon(rankName) + " " + rankName + $" · {dr.Wins}V/{dr.Losses}D/{dr.Draws}E", 16, FontWeights.Bold, "#C4B5FD");
                    Grid.SetColumn(posTxt,0); Grid.SetColumn(nameTxt,1); Grid.SetColumn(ptsTxt,2); Grid.SetColumn(rankTxt,3);
                    row.Children.Add(posTxt); row.Children.Add(nameTxt); row.Children.Add(ptsTxt); row.Children.Add(rankTxt);
                    duelPanel.Children.Add(Card(row, new Thickness(0,0,0,8)));
                    dpos++;
                }
            }
            ViewHost.Children.Add(Card(duelPanel));
        }

        var recent = new StackPanel();
        recent.Children.Add(Txt(isTeacher ? T("Últimas respostas dos alunos", "Latest student answers", "Últimas respuestas de alumnos", "Dernières réponses des élèves", "Letzte Schülerantworten") : T("Histórico recente", "Recent history", "Histórico reciente", "Historique récent", "Aktueller Verlauf"), 24, FontWeights.Black));
        if (!attempts.Any()) recent.Children.Add(Txt(T("Ainda não existem respostas.", "No answers yet.", "Aún no hay respuestas.", "Pas encore de réponses.", "Noch keine Antworten."), 16, null, "#9A94C7"));
        foreach (var a in attempts.Take(18))
        {
            recent.Children.Add(Txt($"{a.Date:g} · {a.Username} · {T("Nível", "Level", "Nivel", "Niveau", "Level")} {a.Level} · {(a.Correct ? T("correto", "correct", "correcto", "correct", "richtig") : T("errado", "wrong", "incorrecto", "faux", "falsch"))} · {a.DurationSeconds}s", 15, FontWeights.Bold, a.Correct ? "#86EFAC" : "#FCA5A5"));
            recent.Children.Add(Txt(a.Question, 13, null, "#9A94C7"));
        }
        ViewHost.Children.Add(Card(recent));
    }
}
