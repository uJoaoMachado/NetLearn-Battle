using System.IO;
using System.Security.Cryptography;
using System.Text;
using System.Text.Json;
using NetLearnBattle.Wpf.Modelos;

namespace NetLearnBattle.Wpf.Servicos;

public sealed class JsonStore
{
    private readonly string _dataDir = Path.Combine(AppContext.BaseDirectory, "Data");
    private readonly JsonSerializerOptions _json = new() { WriteIndented = true };
    public JsonStore()
    {
        Directory.CreateDirectory(_dataDir);
        var professorSalt = CreateSalt();
        Ensure("users.json", new List<User> { new() { Username="professor", Salt = professorSalt, PasswordHash = Hash("professor", professorSalt), Role=Role.Teacher }});
        Ensure("scores.json", new List<ScoreEntry>());
        Ensure("attempts.json", new List<Attempt>());
        Ensure("acls.json", new List<ACL>
        {
            new()
            {
                Name = "ACL Web",
                Description = "Exemplo para perguntas de nível 5",
                Rules = new List<ACLRule>
                {
                    new() { Order = 1, Action = "permit", Protocol = "tcp", SourceIp = "any", SourcePort = "any", DestinationIp = "192.168.1.10", DestinationPort = "80" },
                    new() { Order = 2, Action = "deny", Protocol = "ip", SourceIp = "any", SourcePort = "any", DestinationIp = "any", DestinationPort = "any" }
                }
            }
        });
        Ensure("appsettings.json", new AppSettings());
        Ensure("duel_ranks.json", new List<DuelRankDto>());
    }
    private string PathOf(string file) => Path.Combine(_dataDir, file);
    private void Ensure<T>(string f, T data){ if(!File.Exists(PathOf(f))) File.WriteAllText(PathOf(f), JsonSerializer.Serialize(data,_json)); }
    public T Read<T>(string file, T fallback){ try { return JsonSerializer.Deserialize<T>(File.ReadAllText(PathOf(file))) ?? fallback; } catch { return fallback; } }
    public void Write<T>(string file, T data) => File.WriteAllText(PathOf(file), JsonSerializer.Serialize(data,_json));
    public List<User> Users { get => Read("users.json", new List<User>()); set => Write("users.json", value); }
    public List<ScoreEntry> Scores { get => Read("scores.json", new List<ScoreEntry>()); set => Write("scores.json", value); }
    public List<Attempt> Attempts { get => Read("attempts.json", new List<Attempt>()); set => Write("attempts.json", value); }
    public AppSettings Settings { get => Read("appsettings.json", new AppSettings()); set => Write("appsettings.json", value); }
    public List<ACL> Acls { get => Read("acls.json", new List<ACL>()); set => Write("acls.json", value); }
    public List<DuelRankDto> DuelRanks { get => Read("duel_ranks.json", new List<DuelRankDto>()); set => Write("duel_ranks.json", value); }
    public static string CreateSalt()
    {
        var bytes = RandomNumberGenerator.GetBytes(16);
        return Convert.ToHexString(bytes);
    }

    public static string Hash(string text, string salt)
    {
        using var sha = SHA256.Create();
        return Convert.ToHexString(sha.ComputeHash(Encoding.UTF8.GetBytes((salt ?? string.Empty) + ":" + text)));
    }

    // Compatibilidade com utilizadores antigos criados antes do salt individual.
    public static string HashLegacy(string text)
    {
        using var sha = SHA256.Create();
        return Convert.ToHexString(sha.ComputeHash(Encoding.UTF8.GetBytes("netlearn-salt:" + text)));
    }

    public static bool VerifyPassword(User user, string password)
    {
        if (user is null) return false;
        if (!string.IsNullOrWhiteSpace(user.Salt))
            return user.PasswordHash == Hash(password, user.Salt);
        return user.PasswordHash == HashLegacy(password);
    }

    public void UpgradeUserSalt(User user, string password)
    {
        if (user is null || !string.IsNullOrWhiteSpace(user.Salt)) return;
        var users = Users;
        var saved = users.FirstOrDefault(x => x.Username.Equals(user.Username, StringComparison.OrdinalIgnoreCase));
        if (saved is null) return;
        saved.Salt = CreateSalt();
        saved.PasswordHash = Hash(password, saved.Salt);
        Users = users;
        user.Salt = saved.Salt;
        user.PasswordHash = saved.PasswordHash;
    }
}
