using System.IO;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Text.Json;
using NetLearnBattle.Wpf.Modelos;

namespace NetLearnBattle.Wpf.Servicos;

public sealed class LocalServer
{
    private sealed class DuelRoom
    {
        public string Id { get; set; } = Guid.NewGuid().ToString("N")[..8];
        public int Level { get; set; } = 1;
        public int Round { get; set; } = 1;
        public string Player1 { get; set; } = "";
        public string Player2 { get; set; } = "";
        public int Score1 { get; set; }
        public int Score2 { get; set; }
        public Question Question { get; set; } = new();
        public Queue<Question> Questions { get; set; } = new();
        public int? Answer1 { get; set; }
        public int? Answer2 { get; set; }
        public string LastResult { get; set; } = "";
        public bool Finished { get; set; }
    }

    private TcpListener? _tcp;
    private UdpClient? _udp;
    private CancellationTokenSource? _cts;
    private readonly JsonStore _store = new();
    private readonly QuestionGenerator _questionGenerator = new();
    private readonly JsonSerializerOptions _json = new() { WriteIndented = true };
    private readonly object _duelLock = new();
    private readonly Dictionary<int, DuelRoom> _waitingDuelsByLevel = new();
    private readonly Dictionary<string, DuelRoom> _duels = new();

    public bool IsRunning => _cts is not null;
    public event Action<string>? Log;
    public event Action? DataChanged;

    public void Start(int tcpPort, int udpPort)
    {
        if (IsRunning) return;

        // Garante que não ficam sockets antigos da própria app presos entre arranques.
        try { _tcp?.Stop(); } catch { }
        try { _udp?.Close(); } catch { }
        _tcp = null;
        _udp = null;

        try
        {
            _cts = new CancellationTokenSource();

            _tcp = new TcpListener(IPAddress.Any, tcpPort);
            _tcp.Server.SetSocketOption(SocketOptionLevel.Socket, SocketOptionName.ReuseAddress, true);
            _tcp.Start();

            _udp = new UdpClient();
            _udp.Client.SetSocketOption(SocketOptionLevel.Socket, SocketOptionName.ReuseAddress, true);
            _udp.Client.Bind(new IPEndPoint(IPAddress.Any, udpPort));

            Log?.Invoke($"Servidor iniciado | TCP {tcpPort} | UDP {udpPort}");
            _ = Task.Run(() => TcpLoop(_cts.Token));
            _ = Task.Run(() => UdpLoop(_cts.Token));
        }
        catch
        {
            try { _tcp?.Stop(); } catch { }
            try { _udp?.Close(); } catch { }
            _tcp = null;
            _udp = null;
            _cts?.Cancel();
            _cts = null;
            throw;
        }
    }

    public void Stop()
    {
        _cts?.Cancel();
        _cts = null;
        try { _tcp?.Stop(); } catch { }
        try { _udp?.Close(); } catch { }
        lock (_duelLock)
        {
            _waitingDuelsByLevel.Clear();
            _duels.Clear();
        }
        Log?.Invoke("Servidor parado.");
    }

    private async Task TcpLoop(CancellationToken ct)
    {
        while (!ct.IsCancellationRequested && _tcp is not null)
        {
            try
            {
                var client = await _tcp.AcceptTcpClientAsync(ct);
                _ = Task.Run(async () =>
                {
                    using var c = client;
                    using var s = c.GetStream();
                    using var reader = new StreamReader(s, Encoding.UTF8, leaveOpen: true);
                    using var writer = new StreamWriter(s, Encoding.UTF8, leaveOpen: true) { AutoFlush = true };
                    var line = await reader.ReadLineAsync(ct) ?? "PING";
                    var response = HandleMessage(line, c.Client.RemoteEndPoint?.ToString() ?? "TCP");
                    await writer.WriteLineAsync(response.AsMemory(), ct);
                }, ct);
            }
            catch { if (!ct.IsCancellationRequested) Log?.Invoke("Erro TCP controlado."); }
        }
    }

    private async Task UdpLoop(CancellationToken ct)
    {
        while (!ct.IsCancellationRequested && _udp is not null)
        {
            try
            {
                var res = await _udp.ReceiveAsync(ct);
                var line = Encoding.UTF8.GetString(res.Buffer);
                var response = HandleMessage(line, res.RemoteEndPoint.ToString());
                var data = Encoding.UTF8.GetBytes(response);
                await _udp.SendAsync(data, res.RemoteEndPoint, ct);
            }
            catch { if (!ct.IsCancellationRequested) Log?.Invoke("Erro UDP controlado."); }
        }
    }

    private string Pack<T>(string prefix, T value)
        => prefix + "\t" + Convert.ToBase64String(Encoding.UTF8.GetBytes(JsonSerializer.Serialize(value, _json)));

    private static T? Unpack<T>(string payload)
        => JsonSerializer.Deserialize<T>(Encoding.UTF8.GetString(Convert.FromBase64String(payload)));

    private string HandleMessage(string raw, string endpoint)
    {
        try
        {
            var line = (raw ?? string.Empty).Trim();
            if (string.IsNullOrWhiteSpace(line) || line.Equals("PING", StringComparison.OrdinalIgnoreCase))
            {
                Log?.Invoke($"Teste de ligação recebido de {endpoint}.");
                return "NETLEARN_OK";
            }

            if (line.StartsWith("SUBMIT\t", StringComparison.OrdinalIgnoreCase))
                return HandleSubmit(line[7..]);

            // Nomes de mensagens previstos na ficha: aceites como alias para manter compatibilidade.
            if (line.StartsWith("ANSWER_SUBMIT\t", StringComparison.OrdinalIgnoreCase))
                return HandleSubmit(line[14..]);

            if (line.StartsWith("AUTH_REQUEST", StringComparison.OrdinalIgnoreCase))
                return "AUTH_RESPONSE\tOK";

            if (line.Equals("QUESTION_PUSH", StringComparison.OrdinalIgnoreCase))
                return Pack("QUESTION_PUSH", _questionGenerator.Next(1));

            if (line.Equals("RANKING", StringComparison.OrdinalIgnoreCase) || line.Equals("RANKING_REQUEST", StringComparison.OrdinalIgnoreCase))
            {
                var ranking = _store.Scores
                    .GroupBy(s => s.Username)
                    .Select(g => new RankingDto { Username = g.Key, Score = g.Sum(x => x.Score), Total = g.Sum(x => x.Total), Correct = g.Sum(x => x.Correct) })
                    .OrderByDescending(x => x.Score)
                    .ThenByDescending(x => x.Correct)
                    .ThenBy(x => x.Username)
                    .Take(5)
                    .ToList();
                Log?.Invoke($"Ranking Top 5 enviado para {endpoint}.");
                return Pack("RANKING", ranking);
            }

            if (line.Equals("STATS_REQUEST", StringComparison.OrdinalIgnoreCase))
            {
                var attempts = _store.Attempts;
                var stats = new SessionClassStatistics
                {
                    SessionId = "current",
                    ProfessorId = "professor",
                    TotalStudents = attempts.Select(a => a.Username).Distinct(StringComparer.OrdinalIgnoreCase).Count(),
                    ActiveStudents = attempts.Select(a => a.Username).Distinct(StringComparer.OrdinalIgnoreCase).Count(),
                    TotalQuestions = attempts.Count,
                    CorrectAnswers = attempts.Count(a => a.Correct),
                    AverageScore = attempts.Count == 0 ? 0 : Math.Round(attempts.Average(a => a.Points), 1),
                    GeneratedAt = DateTime.Now,
                    SourceAttempts = attempts,
                    SourceScores = _store.Scores
                };
                return Pack("STATS_RESPONSE", stats);
            }

            if (line.Equals("SCORE_UPDATE", StringComparison.OrdinalIgnoreCase))
                return "SCORE_UPDATE\tOK";

            if (line.Equals("DUEL_RANKING", StringComparison.OrdinalIgnoreCase))
            {
                var ranks = _store.DuelRanks
                    .OrderByDescending(x => x.Points)
                    .ThenByDescending(x => x.Wins)
                    .ThenBy(x => x.Username)
                    .Select(x => { x.Rank = RankName(x.Points); return x; })
                    .ToList();
                Log?.Invoke($"Ranking 1v1 online enviado para {endpoint}.");
                return Pack("DUEL_RANKING", ranks);
            }

            if (line.StartsWith("DUEL_JOIN\t", StringComparison.OrdinalIgnoreCase))
                return Pack("DUEL", HandleDuelJoin(Unpack<DuelJoinDto>(line[10..])));

            if (line.StartsWith("DUEL_POLL\t", StringComparison.OrdinalIgnoreCase))
                return Pack("DUEL", HandleDuelPoll(Encoding.UTF8.GetString(Convert.FromBase64String(line[10..]))));

            if (line.StartsWith("DUEL_CANCEL\t", StringComparison.OrdinalIgnoreCase))
                return Pack("DUEL", HandleDuelCancel(Encoding.UTF8.GetString(Convert.FromBase64String(line[12..]))));

            if (line.StartsWith("DUEL_ANSWER\t", StringComparison.OrdinalIgnoreCase))
                return Pack("DUEL", HandleDuelAnswer(Unpack<DuelAnswerDto>(line[12..])));

            return "ERROR Unknown command";
        }
        catch (Exception ex)
        {
            Log?.Invoke("Erro ao processar mensagem: " + ex.Message);
            return "ERROR " + ex.Message;
        }
    }

    private string HandleSubmit(string payload)
    {
        var dto = Unpack<NetworkAttemptDto>(payload);
        if (dto is null || string.IsNullOrWhiteSpace(dto.Username)) return "ERROR Invalid submit";

        var attempts = _store.Attempts;
        var duplicateAttempt = !string.IsNullOrWhiteSpace(dto.Id) && attempts.Any(a => string.Equals(a.Id, dto.Id, StringComparison.OrdinalIgnoreCase));

        if (!duplicateAttempt)
        {
            attempts.Add(new Attempt
            {
                Id = string.IsNullOrWhiteSpace(dto.Id) ? Guid.NewGuid().ToString("N") : dto.Id,
                Username = dto.Username,
                Level = dto.Level,
                Question = dto.Question,
                Answer = dto.Answer,
                Correct = dto.Correct,
                DurationSeconds = dto.DurationSeconds,
                Date = dto.Date
            });
            _store.Attempts = attempts;
        }

        var scores = _store.Scores;
        var duplicateScore = !string.IsNullOrWhiteSpace(dto.Id) && scores.Any(s => string.Equals(s.Id, dto.Id, StringComparison.OrdinalIgnoreCase));

        if (!duplicateScore)
        {
            scores.Add(new ScoreEntry
            {
                Id = string.IsNullOrWhiteSpace(dto.Id) ? Guid.NewGuid().ToString("N") : dto.Id,
                Username = dto.Username,
                Score = dto.Score,
                Correct = dto.Correct ? 1 : 0,
                Total = 1,
                Date = dto.Date
            });
            _store.Scores = scores;
        }

        Log?.Invoke($"Resposta recebida: {dto.Username} | Nível {dto.Level} | {(dto.Correct ? "certa" : "errada")} | {dto.Score} pts");
        DataChanged?.Invoke();
        return "OK SUBMITTED";
    }

    private DuelStateDto HandleDuelJoin(DuelJoinDto? dto)
    {
        if (dto is null || string.IsNullOrWhiteSpace(dto.Username)) return new DuelStateDto { Status = "ERROR", LastResult = "Utilizador inválido." };
        lock (_duelLock)
        {
            var username = dto.Username.Trim();
            var level = Math.Clamp(dto.Level, 1, 5);

            // Remove duelos antigos/terminados deste jogador para ele poder voltar a jogar sem ficar preso no resultado anterior.
            foreach (var old in _duels.Where(x => x.Value.Finished && IsPlayer(x.Value, username)).Select(x => x.Key).ToList())
                _duels.Remove(old);

            foreach (var key in _waitingDuelsByLevel.Where(x => x.Value.Player1.Equals(username, StringComparison.OrdinalIgnoreCase)).Select(x => x.Key).ToList())
                _waitingDuelsByLevel.Remove(key);

            var existing = _duels.Values.FirstOrDefault(d => !d.Finished && IsPlayer(d, username));
            if (existing is not null) return ToDto(existing);

            if (!_waitingDuelsByLevel.TryGetValue(level, out var waiting) || waiting.Player1.Equals(username, StringComparison.OrdinalIgnoreCase))
            {
                var createdQuestions = new Queue<Question>(_questionGenerator.GenerateSet(level, 5));
                var created = new DuelRoom { Player1 = username, Level = level, Questions = createdQuestions, Question = createdQuestions.Dequeue() };
                _waitingDuelsByLevel[level] = created;
                Log?.Invoke($"Duelo online: {username} entrou na fila do nível {level}.");
                return ToDto(created, "WAIT");
            }

            var room = waiting;
            _waitingDuelsByLevel.Remove(level);
            room.Player2 = username;
            if (room.Questions.Count == 0) room.Questions = new Queue<Question>(_questionGenerator.GenerateSet(room.Level, 5));
            if (string.IsNullOrWhiteSpace(room.Question.Text) && room.Questions.Count > 0) room.Question = room.Questions.Dequeue();
            _duels[room.Id] = room;
            Log?.Invoke($"Duelo online iniciado: {room.Player1} vs {room.Player2} | Nível {room.Level}");
            return ToDto(room, "PLAY");
        }
    }

    private static bool IsPlayer(DuelRoom room, string username)
        => room.Player1.Equals(username, StringComparison.OrdinalIgnoreCase) || room.Player2.Equals(username, StringComparison.OrdinalIgnoreCase);

    private DuelStateDto HandleDuelPoll(string username)
    {
        lock (_duelLock)
        {
            var active = _duels.Values.FirstOrDefault(d => !d.Finished && IsPlayer(d, username));
            if (active is not null) return ToDto(active);

            var finished = _duels.Values.FirstOrDefault(d => d.Finished && IsPlayer(d, username));
            if (finished is not null) return ToDto(finished, "FINISHED");

            var waiting = _waitingDuelsByLevel.Values.FirstOrDefault(d => d.Player1.Equals(username, StringComparison.OrdinalIgnoreCase));
            if (waiting is not null) return ToDto(waiting, "WAIT");

            return new DuelStateDto { Status = "WAIT", LastResult = "À espera de outro jogador do mesmo nível." };
        }
    }

    private DuelStateDto HandleDuelCancel(string username)
    {
        lock (_duelLock)
        {
            username = (username ?? string.Empty).Trim();
            foreach (var key in _waitingDuelsByLevel.Where(x => x.Value.Player1.Equals(username, StringComparison.OrdinalIgnoreCase)).Select(x => x.Key).ToList())
                _waitingDuelsByLevel.Remove(key);

            foreach (var key in _duels.Where(x => !x.Value.Finished && IsPlayer(x.Value, username)).Select(x => x.Key).ToList())
                _duels.Remove(key);

            Log?.Invoke($"Duelo online: {username} cancelou a fila/partida.");
            return new DuelStateDto { Status = "CANCELLED", LastResult = "Fila cancelada." };
        }
    }

    private DuelStateDto HandleDuelAnswer(DuelAnswerDto? dto)
    {
        if (dto is null) return new DuelStateDto { Status = "ERROR", LastResult = "Resposta inválida." };
        lock (_duelLock)
        {
            if (!_duels.TryGetValue(dto.RoomId, out var room)) return new DuelStateDto { Status = "ERROR", LastResult = "Duelo não encontrado." };
            if (room.Finished) return ToDto(room, "FINISHED");

            if (room.Player1.Equals(dto.Username, StringComparison.OrdinalIgnoreCase)) room.Answer1 ??= dto.SelectedIndex;
            if (room.Player2.Equals(dto.Username, StringComparison.OrdinalIgnoreCase)) room.Answer2 ??= dto.SelectedIndex;

            if (room.Answer1.HasValue && room.Answer2.HasValue)
            {
                var pts = QuestionGenerator.PointsForLevel(room.Level).Correct;
                var p1Ok = room.Answer1.Value == room.Question.CorrectIndex;
                var p2Ok = room.Answer2.Value == room.Question.CorrectIndex;
                if (p1Ok) room.Score1 += pts;
                if (p2Ok) room.Score2 += pts;
                room.LastResult = $"Ronda {room.Round}: {room.Player1} {(p1Ok ? "+" + pts : "+0")} · {room.Player2} {(p2Ok ? "+" + pts : "+0")} · Resposta: {room.Question.Options[room.Question.CorrectIndex]}";
                room.Round++;
                room.Answer1 = null;
                room.Answer2 = null;
                if (room.Round > 5)
                {
                    room.Finished = true;
                    UpdateDuelRanks(room.Player1, room.Player2, room.Score1, room.Score2);
                    Log?.Invoke($"Duelo terminado: {room.Player1} {room.Score1} - {room.Score2} {room.Player2}");
                    DataChanged?.Invoke();
                }
                else
                {
                    room.Question = room.Questions.Count > 0 ? room.Questions.Dequeue() : _questionGenerator.Next(room.Level);
                }
            }
            return ToDto(room);
        }
    }

    private static string RankName(int points) => points switch
    {
        >= 800 => "Mestre",
        >= 500 => "Diamante",
        >= 250 => "Ouro",
        >= 100 => "Prata",
        _ => "Bronze"
    };

    private static int WinPointsFor(int currentPoints) => currentPoints switch
    {
        >= 800 => 6,
        >= 500 => 10,
        >= 250 => 15,
        >= 100 => 20,
        _ => 25
    };

    private static int DrawPointsFor(int currentPoints) => Math.Max(4, WinPointsFor(currentPoints) / 2);
    private static int LossPointsFor(int currentPoints) => currentPoints >= 500 ? 1 : currentPoints >= 250 ? 2 : 4;

    private void UpdateDuelRanks(string p1, string p2, int s1, int s2)
    {
        var ranks = _store.DuelRanks;
        DuelRankDto Get(string username)
        {
            var r = ranks.FirstOrDefault(x => x.Username.Equals(username, StringComparison.OrdinalIgnoreCase));
            if (r is null)
            {
                r = new DuelRankDto { Username = username, Points = 0, Rank = "Bronze" };
                ranks.Add(r);
            }
            return r;
        }

        var r1 = Get(p1);
        var r2 = Get(p2);
        r1.Matches++; r2.Matches++;

        if (s1 == s2)
        {
            r1.Draws++; r2.Draws++;
            r1.Points += DrawPointsFor(r1.Points);
            r2.Points += DrawPointsFor(r2.Points);
        }
        else if (s1 > s2)
        {
            r1.Wins++; r2.Losses++;
            r1.Points += WinPointsFor(r1.Points);
            r2.Points += LossPointsFor(r2.Points);
        }
        else
        {
            r2.Wins++; r1.Losses++;
            r2.Points += WinPointsFor(r2.Points);
            r1.Points += LossPointsFor(r1.Points);
        }

        r1.Rank = RankName(r1.Points);
        r2.Rank = RankName(r2.Points);
        _store.DuelRanks = ranks;
    }

    private static DuelStateDto ToDto(DuelRoom room, string? forcedStatus = null) => new()
    {
        Status = forcedStatus ?? (room.Finished ? "FINISHED" : string.IsNullOrWhiteSpace(room.Player2) ? "WAIT" : (room.Answer1.HasValue || room.Answer2.HasValue ? "WAIT_ANSWER" : "PLAY")),
        RoomId = room.Id,
        Level = room.Level,
        Round = Math.Min(room.Round, 5),
        Player1 = room.Player1,
        Player2 = room.Player2,
        Score1 = room.Score1,
        Score2 = room.Score2,
        Question = room.Question.Text,
        Options = room.Question.Options,
        CorrectIndex = room.Question.CorrectIndex,
        LastResult = room.LastResult
    };
}
