using NetLearnBattle.Wpf.Modelos;

namespace NetLearnBattle.Wpf.Servicos;

public sealed class QuestionGenerator
{
    private readonly Random _r = new();

    public Question Next(int level, AppLanguage language = AppLanguage.PT)
    {
        var list = level switch
        {
            1 => Level1(language),
            2 => Level2(language),
            3 => Level3(language),
            4 => Level4(language),
            _ => Level5(language)
        };
        return list[_r.Next(list.Count)];
    }

    public List<Question> GenerateSet(int level, int count = 10, AppLanguage language = AppLanguage.PT)
    {
        // Gera uma sessão sem perguntas repetidas. Como algumas perguntas são dinâmicas,
        // tentamos várias vezes até ter textos diferentes no mesmo jogo/duelo/treino.
        var result = new List<Question>();
        var seen = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
        var attempts = 0;

        while (result.Count < count && attempts < count * 80)
        {
            attempts++;
            var q = Next(level, language);
            var key = q.Text.Trim();
            if (seen.Add(key))
                result.Add(q);
        }

        // Segurança: se algum nível for alterado no futuro e tiver poucas perguntas,
        // completa sem bloquear a app.
        while (result.Count < count)
            result.Add(Next(level, language));

        return result.OrderBy(_ => _r.Next()).ToList();
    }

    public static (int Correct, int Wrong) PointsForLevel(int level) => level switch
    {
        1 => (10, -5),
        2 => (20, -10),
        3 => (30, -15),
        4 => (40, -20),
        _ => (50, -25)
    };

    private static string L(AppLanguage lang, string pt, string en, string es, string fr, string de, string lt = "") => lang switch
    {
        AppLanguage.EN => en,
        AppLanguage.ES => es,
        AppLanguage.FR => fr,
        AppLanguage.DE => de,
        AppLanguage.LT => string.IsNullOrWhiteSpace(lt) ? LtQuestion(pt) : lt,
        _ => pt
    };

    private static string LtQuestion(string pt)
    {
        var exact = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase)
        {
            ["Sim"] = "Taip",
            ["Não"] = "Ne",
            ["Depende da porta"] = "Priklauso nuo prievado",
            ["Qual é a máscara decimal de /24?"] = "Kokia yra /24 dešimtainė kaukė?",
            ["A máscara /24 é 255.255.255.0."] = "/24 kaukė yra 255.255.255.0.",
            ["Numa ACL, a ordem das regras importa?"] = "Ar ACL taisyklių tvarka svarbi?",
            ["Sim, a primeira correspondência aplica-se"] = "Taip, taikoma pirma atitinkanti taisyklė",
            ["Não, todas são somadas"] = "Ne, visos taisyklės sujungiamos",
            ["Só em UDP"] = "Tik UDP",
            ["Só em IPv6"] = "Tik IPv6",
            ["As ACLs são avaliadas por ordem até encontrar uma regra compatível."] = "ACL vertinamos eilės tvarka, kol randama tinkama taisyklė.",
            ["Permite tudo"] = "Leidžia viską",
            ["Bloqueia ICMP"] = "Blokuoja ICMP"
        };
        if (exact.TryGetValue(pt, out var val)) return val;

        var t = pt;
        t = t.Replace("Qual é o Network ID de", "Koks yra tinklo ID adresui");
        t = t.Replace("Qual é o Broadcast de", "Koks yra transliacijos adresas adresui");
        t = t.Replace("Dois endereços", "Ar du adresai");
        t = t.Replace("estão no mesmo segmento?", "yra tame pačiame segmente?");
        t = t.Replace("No endereço", "Adrese");
        t = t.Replace("qual é a rede?", "koks yra tinklas?");
        t = t.Replace("Para uma rede", "Tinklui");
        t = t.Replace("quantos endereços existem por sub-rede?", "kiek adresų yra kiekviename potinklyje?");
        t = t.Replace("Qual é o incremento de bloco numa sub-rede", "Koks yra bloko žingsnis potinklyje");
        t = t.Replace("pertence a que sub-rede?", "kuriam potinkliui priklauso?");
        t = t.Replace("Quantas sub-redes", "Kiek potinklių");
        t = t.Replace("cabem dentro de uma rede /24?", "telpa /24 tinkle?");
        t = t.Replace("Qual prefixo sumariza", "Koks prefiksas apibendrina");
        t = t.Replace("redes /24 consecutivas?", "nuoseklius /24 tinklus?");
        t = t.Replace("Qual é o Network ID IPv6", "Koks yra IPv6 tinklo ID");
        t = t.Replace("Qual é o Broadcast IPv6", "Koks yra IPv6 broadcast adresas");
        t = t.Replace("IPv6 não usa broadcast.", "IPv6 nenaudoja broadcast.");
        t = t.Replace("Quantas sub-redes", "Kiek potinklių");
        t = t.Replace("Qual regra permite", "Kuri taisyklė leidžia");
        t = t.Replace("de qualquer origem para qualquer destino?", "iš bet kurio šaltinio į bet kurį tikslą?");
        t = t.Replace("Dada a regra", "Duota taisyklė");
        t = t.Replace("o que acontece?", "kas įvyksta?");
        t = t.Replace("Permite", "Leidžia");
        t = t.Replace("Bloqueia", "Blokuoja");
        t = t.Replace("Em /24, os três primeiros octetos identificam a rede.", "/24 atveju pirmi trys oktetai nurodo tinklą.");
        t = t.Replace("Em /16, os dois primeiros octetos são da rede e o broadcast termina em 255.255.", "/16 atveju pirmi du oktetai priklauso tinklui, o broadcast baigiasi 255.255.");
        t = t.Replace("Em /8, apenas o primeiro octeto identifica a rede.", "/8 atveju tik pirmas oktetas nurodo tinklą.");
        t = t.Replace("Com /24, ambos pertencem à rede", "Su /24 abu priklauso tinklui");
        t = t.Replace("deixa", "palieka");
        t = t.Replace("bits para endereços", "bitus adresams");
        t = t.Replace("O incremento no último octeto é", "Paskutinio okteto žingsnis yra");
        t = t.Replace("Com blocos de", "Su blokais po");
        t = t.Replace("o endereço fica na sub-rede terminada em", "adresas yra potinklyje, kuris baigiasi");
        t = t.Replace("A diferença", "Skirtumas");
        t = t.Replace("dá", "duoda");
        t = t.Replace("bits", "bitus");
        t = t.Replace("A regra nega tráfego", "Taisyklė draudžia srautą");
        t = t.Replace("com porta", "su prievadu");
        t = t.Replace("usa normalmente porta", "paprastai naudoja prievadą");
        return t;
    }

    private List<Question> Level1(AppLanguage lang)
    {
        int a = _r.Next(1, 220);
        int b = _r.Next(1, 240);
        int c = _r.Next(10, 240);
        int oct2 = _r.Next(0, 250);
        return new()
        {
            Make(L(lang, $"Qual é o Network ID de 192.168.{a}.{c}/24?", $"What is the Network ID of 192.168.{a}.{c}/24?", $"¿Cuál es el Network ID de 192.168.{a}.{c}/24?", $"Quel est le Network ID de 192.168.{a}.{c}/24 ?", $"Was ist die Network ID von 192.168.{a}.{c}/24?"),
                new[] {$"192.168.{a}.0", $"192.168.{a}.255", "192.168.0.0", $"192.168.{c}.0"}, 0, 1,
                L(lang, "Em /24, os três primeiros octetos identificam a rede.", "In /24, the first three octets identify the network.", "En /24, los tres primeros octetos identifican la red.", "En /24, les trois premiers octets identifient le réseau.", "Bei /24 identifizieren die ersten drei Oktette das Netzwerk.")),
            Make(L(lang, $"Qual é o Broadcast de 10.{a}.{b}.{c}/16?", $"What is the Broadcast of 10.{a}.{b}.{c}/16?", $"¿Cuál es el Broadcast de 10.{a}.{b}.{c}/16?", $"Quel est le Broadcast de 10.{a}.{b}.{c}/16 ?", $"Was ist die Broadcast-Adresse von 10.{a}.{b}.{c}/16?"),
                new[] {$"10.{a}.255.255", $"10.{a}.{b}.255", "10.255.255.255", $"10.{a}.0.0"}, 0, 1,
                L(lang, "Em /16, os dois primeiros octetos são da rede e o broadcast termina em 255.255.", "In /16, the first two octets are the network and broadcast ends in 255.255.", "En /16, los dos primeros octetos son la red y el broadcast termina en 255.255.", "En /16, les deux premiers octets sont le réseau et le broadcast finit par 255.255.", "Bei /16 gehören die ersten zwei Oktette zum Netzwerk und Broadcast endet mit 255.255.")),
            Make(L(lang, $"Dois endereços 172.16.{a}.10/24 e 172.16.{a}.200/24 estão no mesmo segmento?", $"Are 172.16.{a}.10/24 and 172.16.{a}.200/24 in the same segment?", $"¿172.16.{a}.10/24 y 172.16.{a}.200/24 están en el mismo segmento?", $"172.16.{a}.10/24 et 172.16.{a}.200/24 sont-ils dans le même segment ?", $"Sind 172.16.{a}.10/24 und 172.16.{a}.200/24 im selben Segment?"),
                new[] {L(lang,"Sim","Yes","Sí","Oui","Ja"), L(lang,"Não","No","No","Non","Nein"), "IPv6", L(lang,"Depende da porta","Depends on the port","Depende del puerto","Cela dépend du port","Hängt vom Port ab")}, 0, 1,
                L(lang, $"Com /24, ambos pertencem à rede 172.16.{a}.0.", $"With /24, both belong to network 172.16.{a}.0.", $"Con /24, ambos pertenecen a la red 172.16.{a}.0.", $"Avec /24, les deux appartiennent au réseau 172.16.{a}.0.", $"Mit /24 gehören beide zum Netzwerk 172.16.{a}.0.")),
            Make(L(lang, "Qual é a máscara decimal de /24?", "What is the dotted mask of /24?", "¿Cuál es la máscara decimal de /24?", "Quel est le masque décimal de /24 ?", "Wie lautet die Dezimalmaske von /24?"),
                new[] {"255.0.0.0", "255.255.0.0", "255.255.255.0", "255.255.255.255"}, 2, 1,
                L(lang, "A máscara /24 é 255.255.255.0.", "The /24 mask is 255.255.255.0.", "La máscara /24 es 255.255.255.0.", "Le masque /24 est 255.255.255.0.", "Die /24-Maske ist 255.255.255.0.")),
            Make(L(lang, $"No endereço 10.{oct2}.{a}.{b}/8, qual é a rede?", $"In address 10.{oct2}.{a}.{b}/8, what is the network?", $"En la dirección 10.{oct2}.{a}.{b}/8, ¿cuál es la red?", $"Dans l'adresse 10.{oct2}.{a}.{b}/8, quel est le réseau ?", $"Welche Netzwerkadresse hat 10.{oct2}.{a}.{b}/8?"),
                new[] {"10.0.0.0", $"10.{oct2}.0.0", $"10.{oct2}.{a}.0", $"10.{oct2}.{a}.{b}"}, 0, 1,
                L(lang, "Em /8, apenas o primeiro octeto identifica a rede.", "In /8, only the first octet identifies the network.", "En /8, solo el primer octeto identifica la red.", "En /8, seul le premier octet identifie le réseau.", "Bei /8 identifiziert nur das erste Oktett das Netzwerk."))
        };
    }

    private List<Question> Level2(AppLanguage lang)
    {
        int prefix = new[] {25, 26, 27, 28, 29, 30}[_r.Next(6)];
        int addresses = 1 << (32 - prefix);
        int block = addresses;
        int network = (_r.Next(0, 256 / block) * block);
        int host = Math.Min(254, network + _r.Next(1, Math.Max(2, block - 1)));
        int subnetsFrom24 = 1 << (prefix - 24);
        return new()
        {
            Make(L(lang,$"Para uma rede /{prefix}, quantos endereços existem por sub-rede?",$"For a /{prefix} network, how many addresses exist per subnet?",$"Para una red /{prefix}, ¿cuántas direcciones hay por subred?",$"Pour un réseau /{prefix}, combien d'adresses y a-t-il par sous-réseau ?",$"Wie viele Adressen gibt es pro /{prefix}-Subnetz?"),
                new[]{(addresses/2).ToString(), addresses.ToString(), (addresses*2).ToString(), "256"}, 1, 2,
                L(lang,$"/{prefix} deixa {32-prefix} bits para endereços: 2^{32-prefix} = {addresses}.",$"/{prefix} leaves {32-prefix} host bits: 2^{32-prefix} = {addresses}.",$"/{prefix} deja {32-prefix} bits: 2^{32-prefix} = {addresses}.",$"/{prefix} laisse {32-prefix} bits : 2^{32-prefix} = {addresses}.",$"/{prefix} lässt {32-prefix} Bits: 2^{32-prefix} = {addresses}.")),
            Make(L(lang,$"Qual é o incremento de bloco numa sub-rede /{prefix}?",$"What is the block increment in a /{prefix} subnet?",$"¿Cuál es el incremento de bloque en una subred /{prefix}?",$"Quel est l'incrément de bloc dans un sous-réseau /{prefix} ?",$"Was ist die Blockgröße in einem /{prefix}-Subnetz?"),
                new[]{Math.Max(1,block/2).ToString(), Math.Max(1,block/4).ToString(), block.ToString(), Math.Min(256,block*2).ToString()}, 2, 2,
                L(lang,$"O incremento no último octeto é {block}.",$"The last-octet increment is {block}.",$"El incremento en el último octeto es {block}.",$"L'incrément dans le dernier octet est {block}.",$"Die Schrittweite im letzten Oktett ist {block}.")),
            Make(L(lang,$"192.168.{_r.Next(0,20)}.{host}/{prefix} pertence a que sub-rede?",$"192.168.x.{host}/{prefix} belongs to which subnet?",$"192.168.x.{host}/{prefix} pertenece a qué subred?",$"192.168.x.{host}/{prefix} appartient à quel sous-réseau ?",$"Zu welchem Subnetz gehört 192.168.x.{host}/{prefix}?"),
                new[]{$"...{Math.Max(0,network-block)}", $"...{network}", $"...{Math.Min(255,network+block)}", "...255"}, 1, 2,
                L(lang,$"Com blocos de {block}, o endereço fica na sub-rede terminada em .{network}.",$"With blocks of {block}, the address is in the subnet ending .{network}.",$"Con bloques de {block}, la dirección queda en la subred .{network}.",$"Avec des blocs de {block}, l'adresse est dans le sous-réseau .{network}.",$"Bei Blöcken von {block} liegt die Adresse im Subnetz .{network}.")),
            Make(L(lang,$"Quantas sub-redes /{prefix} cabem dentro de uma rede /24?",$"How many /{prefix} subnets fit inside a /24 network?",$"¿Cuántas subredes /{prefix} caben dentro de una red /24?",$"Combien de sous-réseaux /{prefix} tiennent dans un réseau /24 ?",$"Wie viele /{prefix}-Subnetze passen in ein /24-Netz?"),
                new[]{Math.Max(1,subnetsFrom24/2).ToString(), subnetsFrom24.ToString(), (subnetsFrom24*2).ToString(), "256"}, 1, 2,
                L(lang,$"A diferença {prefix}-24 dá {prefix-24} bits: 2^{prefix-24} = {subnetsFrom24}.",$"The difference {prefix}-24 gives {prefix-24} bits: 2^{prefix-24} = {subnetsFrom24}.",$"La diferencia {prefix}-24 da {prefix-24} bits: 2^{prefix-24} = {subnetsFrom24}.",$"La différence {prefix}-24 donne {prefix-24} bits : 2^{prefix-24} = {subnetsFrom24}.",$"Die Differenz {prefix}-24 ergibt {prefix-24} Bits: 2^{prefix-24} = {subnetsFrom24}."))
        };
    }

    private List<Question> Level3(AppLanguage lang)
    {
        int networks = new[] {2, 4, 8, 16}[_r.Next(4)];
        int prefix = 24 - (int)Math.Log2(networks);
        int start = (_r.Next(0, Math.Max(1, 256 / networks)) * networks);
        return new()
        {
            Make(L(lang,$"Qual prefixo sumariza {networks} redes /24 consecutivas?",$"Which prefix summarizes {networks} consecutive /24 networks?",$"¿Qué prefijo resume {networks} redes /24 consecutivas?",$"Quel préfixe résume {networks} réseaux /24 consécutifs ?",$"Welches Präfix fasst {networks} aufeinanderfolgende /24-Netze zusammen?"),
                new[]{$"/{prefix}",$"/{prefix+1}",$"/{Math.Min(30,prefix+2)}","/24"}, 0, 3,
                L(lang,$"{networks} redes /24 agregam num /{prefix}.",$"{networks} /24 networks aggregate into /{prefix}.",$"{networks} redes /24 se agregan en /{prefix}.",$"{networks} réseaux /24 s'agrègent en /{prefix}.",$"{networks} /24-Netze werden zu /{prefix} zusammengefasst.")),
            Make(L(lang,$"Que sumarização cobre 10.0.{start}.0/24 até 10.0.{start+networks-1}.0/24?",$"Which summary covers 10.0.{start}.0/24 through 10.0.{start+networks-1}.0/24?",$"¿Qué sumarización cubre de 10.0.{start}.0/24 a 10.0.{start+networks-1}.0/24?",$"Quel résumé couvre 10.0.{start}.0/24 jusqu'à 10.0.{start+networks-1}.0/24 ?",$"Welche Zusammenfassung deckt 10.0.{start}.0/24 bis 10.0.{start+networks-1}.0/24 ab?"),
                new[]{$"10.0.{start}.0/{prefix}",$"10.0.{start}.0/{prefix+1}",$"10.0.{start+networks-1}.0/24",$"10.0.0.0/{Math.Max(16,prefix-1)}"}, 0, 3,
                L(lang,$"Essas {networks} redes formam 10.0.{start}.0/{prefix}.",$"Those {networks} networks form 10.0.{start}.0/{prefix}.",$"Esas {networks} redes forman 10.0.{start}.0/{prefix}.",$"Ces {networks} réseaux forment 10.0.{start}.0/{prefix}.",$"Diese {networks} Netze bilden 10.0.{start}.0/{prefix}.")),
            Make(L(lang,$"Uma super-rede /{prefix} contém quantas redes /24?",$"A /{prefix} supernet contains how many /24 networks?",$"¿Una superred /{prefix} contiene cuántas redes /24?",$"Un super-réseau /{prefix} contient combien de réseaux /24 ?",$"Wie viele /24-Netze enthält ein /{prefix}-Supernetz?"),
                new[]{Math.Max(1,networks/2).ToString(), networks.ToString(), (networks*2).ToString(), "1"}, 1, 3,
                L(lang,$"A diferença 24 - {prefix} = {24-prefix} bits, logo 2^{24-prefix} = {networks}.",$"The difference 24 - {prefix} = {24-prefix} bits, so 2^{24-prefix} = {networks}.",$"La diferencia 24 - {prefix} = {24-prefix} bits, entonces 2^{24-prefix} = {networks}.",$"La différence 24 - {prefix} = {24-prefix} bits, donc 2^{24-prefix} = {networks}.",$"Die Differenz 24 - {prefix} = {24-prefix} Bits, also 2^{24-prefix} = {networks}."))
        };
    }

    private List<Question> Level4(AppLanguage lang)
    {
        string prefix = new[] {"2001:db8:10::/64", "2001:db8:20::/64", "fd00:1234::/64", "2001:db8:abcd::/64"}[_r.Next(4)];
        int subnetBits = new[] {1, 2, 4, 8}[_r.Next(4)];
        int subnetCount = 1 << subnetBits;
        return new()
        {
            Make(L(lang,"Em IPv6, qual é o tamanho normal do prefixo de uma LAN?","In IPv6, what is the normal LAN prefix size?","En IPv6, ¿cuál es el tamaño normal del prefijo de una LAN?","En IPv6, quelle est la taille normale du préfixe d'un LAN ?","Was ist bei IPv6 die normale Präfixlänge eines LANs?","Koks yra įprastas IPv6 LAN prefikso dydis?"),
                new[]{"/32","/48","/64","/128"}, 2, 4,
                L(lang,"Em IPv6, uma LAN usa tipicamente /64.","In IPv6, a LAN typically uses /64.","En IPv6, una LAN usa normalmente /64.","En IPv6, un LAN utilise généralement /64.","Bei IPv6 verwendet ein LAN typischerweise /64.","IPv6 LAN paprastai naudoja /64.")),
            Make(L(lang,"Qual é o Network ID IPv6 de 2001:db8:10:20::1234/64?","What is the IPv6 Network ID of 2001:db8:10:20::1234/64?","¿Cuál es el Network ID IPv6 de 2001:db8:10:20::1234/64?","Quel est le Network ID IPv6 de 2001:db8:10:20::1234/64 ?","Was ist die IPv6 Network ID von 2001:db8:10:20::1234/64?","Koks yra 2001:db8:10:20::1234/64 IPv6 tinklo ID?"),
                new[]{"2001:db8:10:20::","2001:db8:10::","2001:db8:10:20::1234","2001:db8::"}, 0, 4,
                L(lang,"Com /64, os primeiros 64 bits identificam a rede: 2001:db8:10:20::.","With /64, the first 64 bits identify the network: 2001:db8:10:20::.","Con /64, los primeros 64 bits identifican la red: 2001:db8:10:20::.","Avec /64, les 64 premiers bits identifient le réseau : 2001:db8:10:20::.","Bei /64 identifizieren die ersten 64 Bits das Netzwerk: 2001:db8:10:20::.","Naudojant /64, pirmi 64 bitai nurodo tinklą: 2001:db8:10:20::.")),
            Make(L(lang,"Em IPv6, qual é o endereço de broadcast de 2001:db8::/64?","In IPv6, what is the broadcast address of 2001:db8::/64?","En IPv6, ¿cuál es la dirección broadcast de 2001:db8::/64?","En IPv6, quelle est l'adresse broadcast de 2001:db8::/64 ?","Was ist bei IPv6 die Broadcast-Adresse von 2001:db8::/64?","Koks yra 2001:db8::/64 IPv6 broadcast adresas?"),
                new[]{L(lang,"Não existe broadcast em IPv6","There is no broadcast in IPv6","No existe broadcast en IPv6","Il n'existe pas de broadcast en IPv6","Es gibt keinen Broadcast in IPv6","IPv6 neturi broadcast"), "ffff::ffff", "2001:db8::ffff", "ff02::1"}, 0, 4,
                L(lang,"IPv6 não usa broadcast; usa multicast quando precisa de comunicação para vários nós.","IPv6 does not use broadcast; it uses multicast when communication to multiple nodes is needed.","IPv6 no usa broadcast; usa multicast cuando necesita comunicarse con varios nodos.","IPv6 n'utilise pas le broadcast ; il utilise le multicast pour plusieurs nœuds.","IPv6 verwendet keinen Broadcast, sondern Multicast für mehrere Knoten.","IPv6 nenaudoja broadcast; keliems mazgams pasiekti naudojamas multicast.")),
            Make(L(lang,"2001:db8:10:20::1/64 e 2001:db8:10:20::abcd/64 estão no mesmo segmento?","Are 2001:db8:10:20::1/64 and 2001:db8:10:20::abcd/64 in the same segment?","¿2001:db8:10:20::1/64 y 2001:db8:10:20::abcd/64 están en el mismo segmento?","2001:db8:10:20::1/64 et 2001:db8:10:20::abcd/64 sont-ils dans le même segment ?","Sind 2001:db8:10:20::1/64 und 2001:db8:10:20::abcd/64 im selben Segment?","Ar 2001:db8:10:20::1/64 ir 2001:db8:10:20::abcd/64 yra tame pačiame segmente?"),
                new[]{L(lang,"Sim","Yes","Sí","Oui","Ja","Taip"), L(lang,"Não","No","No","Non","Nein","Ne"), L(lang,"Só se for TCP","Only if TCP","Solo si es TCP","Seulement en TCP","Nur bei TCP","Tik jei TCP"), L(lang,"Depende da porta","Depends on port","Depende del puerto","Dépend du port","Hängt vom Port ab","Priklauso nuo prievado")}, 0, 4,
                L(lang,"Os dois endereços partilham os mesmos primeiros 64 bits.","Both addresses share the same first 64 bits.","Ambas direcciones comparten los primeros 64 bits.","Les deux adresses partagent les 64 premiers bits.","Beide Adressen teilen dieselben ersten 64 Bits.","Abu adresai turi tuos pačius pirmus 64 bitus.")),
            Make(L(lang,$"Se uma rede /64 for dividida em /{64+subnetBits}, quantas sub-redes obténs?",$"If a /64 network is divided into /{64+subnetBits}, how many subnets do you get?",$"Si una red /64 se divide en /{64+subnetBits}, ¿cuántas subredes obtienes?",$"Si un réseau /64 est divisé en /{64+subnetBits}, combien de sous-réseaux obtient-on ?",$"Wenn ein /64-Netz in /{64+subnetBits} geteilt wird, wie viele Subnetze entstehen?",$"Jei /64 tinklas padalijamas į /{64+subnetBits}, kiek potinklių gaunama?"),
                new[]{Math.Max(1,subnetCount/2).ToString(), subnetCount.ToString(), (subnetCount*2).ToString(), "64"}, 1, 4,
                L(lang,$"Foram usados {subnetBits} bits adicionais: 2^{subnetBits} = {subnetCount} sub-redes.",$"{subnetBits} extra bits were used: 2^{subnetBits} = {subnetCount} subnets.",$"Se usaron {subnetBits} bits extra: 2^{subnetBits} = {subnetCount} subredes.",$"{subnetBits} bits supplémentaires sont utilisés : 2^{subnetBits} = {subnetCount} sous-réseaux.",$"Es wurden {subnetBits} zusätzliche Bits genutzt: 2^{subnetBits} = {subnetCount} Subnetze.",$"Panaudoti {subnetBits} papildomi bitai: 2^{subnetBits} = {subnetCount} potinklių."))
        };
    }

    private List<Question> Level5(AppLanguage lang)
    {
        int port = new[] {22, 53, 80, 443}[_r.Next(4)];
        string service = port switch { 22 => "SSH", 53 => "DNS", 80 => "HTTP", _ => "HTTPS" };
        string proto = port == 53 ? "udp" : "tcp";
        return new()
        {
            Make(L(lang,$"Numa ACL, a regra 'deny {proto} any any eq {port}' faz o quê?",$"In an ACL, what does the rule 'deny {proto} any any eq {port}' do?",$"En una ACL, ¿qué hace la regla 'deny {proto} any any eq {port}'?",$"Dans une ACL, que fait la règle 'deny {proto} any any eq {port}' ?",$"Was macht in einer ACL die Regel 'deny {proto} any any eq {port}'?",$"Ką ACL taisyklė 'deny {proto} any any eq {port}' daro?"),
                new[]{L(lang,$"Permite {service}",$"Allows {service}",$"Permite {service}",$"Autorise {service}",$"Erlaubt {service}",$"Leidžia {service}"), L(lang,$"Bloqueia {service}",$"Blocks {service}",$"Bloquea {service}",$"Bloque {service}",$"Blockiert {service}",$"Blokuoja {service}"), L(lang,"Bloqueia ICMP","Blocks ICMP","Bloquea ICMP","Bloque ICMP","Blockiert ICMP","Blokuoja ICMP"), L(lang,"Permite tudo","Allows all","Permite todo","Autorise tout","Erlaubt alles","Leidžia viską")}, 1, 5,
                L(lang,$"A regra nega tráfego {proto.ToUpper()} com porta {port}.",$"The rule denies {proto.ToUpper()} traffic on port {port}.",$"La regla deniega tráfico {proto.ToUpper()} en el puerto {port}.",$"La règle refuse le trafic {proto.ToUpper()} sur le port {port}.",$"Die Regel verweigert {proto.ToUpper()}-Verkehr auf Port {port}.",$"Taisyklė draudžia {proto.ToUpper()} srautą per {port} prievadą.")),
            Make(L(lang,$"Qual regra permite {service} de qualquer origem para qualquer destino?",$"Which rule allows {service} from any source to any destination?",$"¿Qué regla permite {service} desde cualquier origen a cualquier destino?",$"Quelle règle autorise {service} de toute origine vers toute destination ?",$"Welche Regel erlaubt {service} von jeder Quelle zu jedem Ziel?",$"Kuri taisyklė leidžia {service} iš bet kurio šaltinio į bet kurį tikslą?"),
                new[]{$"permit {proto} any any eq {port}",$"deny {proto} any any eq {port}",$"permit icmp any any",$"permit tcp any any eq {Math.Max(1,port+1)}"}, 0, 5,
                L(lang,$"{service} usa normalmente porta {port}.",$"{service} normally uses port {port}.",$"{service} normalmente usa puerto {port}.",$"{service} utilise normalement le port {port}.",$"{service} verwendet normalerweise Port {port}.",$"{service} paprastai naudoja {port} prievadą.")),
            Make(L(lang,"Numa ACL, a ordem das regras importa?","In an ACL, does rule order matter?","En una ACL, ¿importa el orden de las reglas?","Dans une ACL, l'ordre des règles est-il important ?","Ist die Reihenfolge der Regeln in einer ACL wichtig?","Ar ACL taisyklių tvarka svarbi?"),
                new[]{L(lang,"Sim, a primeira correspondência aplica-se","Yes, the first match applies","Sí, se aplica la primera coincidencia","Oui, la première correspondance s'applique","Ja, die erste Übereinstimmung gilt","Taip, taikoma pirma atitinkanti taisyklė"), L(lang,"Não, todas são somadas","No, all are combined","No, todas se suman","Non, elles sont toutes additionnées","Nein, alle werden kombiniert","Ne, visos taisyklės sujungiamos"), L(lang,"Só em UDP","Only in UDP","Solo en UDP","Seulement en UDP","Nur bei UDP","Tik UDP"), L(lang,"Só em IPv6","Only in IPv6","Solo en IPv6","Seulement en IPv6","Nur bei IPv6","Tik IPv6")}, 0, 5,
                L(lang,"As ACLs são avaliadas por ordem até encontrar uma regra compatível.","ACLs are evaluated in order until a matching rule is found.","Las ACL se evalúan en orden hasta encontrar una regla compatible.","Les ACL sont évaluées dans l'ordre jusqu'à trouver une règle compatible.","ACLs werden der Reihe nach ausgewertet, bis eine passende Regel gefunden wird.","ACL vertinamos eilės tvarka, kol randama tinkama taisyklė.")),
            Make(L(lang,"ACL: 1) deny tcp any any eq 80  2) permit ip any any. Um pacote TCP para porta 80 é permitido?","ACL: 1) deny tcp any any eq 80  2) permit ip any any. Is a TCP packet to port 80 allowed?","ACL: 1) deny tcp any any eq 80  2) permit ip any any. ¿Un paquete TCP al puerto 80 es permitido?","ACL : 1) deny tcp any any eq 80  2) permit ip any any. Un paquet TCP vers le port 80 est-il autorisé ?","ACL: 1) deny tcp any any eq 80  2) permit ip any any. Wird ein TCP-Paket zu Port 80 erlaubt?","ACL: 1) deny tcp any any eq 80  2) permit ip any any. Ar TCP paketas į 80 prievadą leidžiamas?"),
                new[]{L(lang,"Não, a primeira regra nega","No, the first rule denies it","No, la primera regla lo niega","Non, la première règle le refuse","Nein, die erste Regel verweigert es","Ne, pirma taisyklė draudžia"), L(lang,"Sim, a segunda regra permite","Yes, the second rule allows it","Sí, la segunda regla lo permite","Oui, la deuxième règle l'autorise","Ja, die zweite Regel erlaubt es","Taip, antra taisyklė leidžia"), L(lang,"Depende do IP de origem","Depends on source IP","Depende de la IP origen","Dépend de l'IP source","Hängt von der Quell-IP ab","Priklauso nuo šaltinio IP"), L(lang,"Só em UDP","Only in UDP","Solo en UDP","Seulement en UDP","Nur UDP","Tik UDP")}, 0, 5,
                L(lang,"A primeira regra compatível termina a avaliação, por isso o deny é aplicado.","The first matching rule stops evaluation, so the deny is applied.","La primera regla compatible termina la evaluación, por eso se aplica deny.","La première règle compatible arrête l'évaluation, donc deny est appliqué.","Die erste passende Regel beendet die Auswertung, daher gilt deny.","Pirma atitinkanti taisyklė sustabdo vertinimą, todėl taikomas deny.")),
            Make(L(lang,"Uma ACL tem a regra incompleta 'permit tcp any'. O que falta escolher?","An ACL has the incomplete rule 'permit tcp any'. What is missing?","Una ACL tiene la regla incompleta 'permit tcp any'. ¿Qué falta?","Une ACL contient la règle incomplète 'permit tcp any'. Que manque-t-il ?","Eine ACL hat die unvollständige Regel 'permit tcp any'. Was fehlt?","ACL turi nebaigtą taisyklę 'permit tcp any'. Ko trūksta?"),
                new[]{L(lang,"Destino e porta/condição","Destination and port/condition","Destino y puerto/condición","Destination et port/condition","Ziel und Port/Bedingung","Tikslas ir prievadas/sąlyga"), L(lang,"Apenas a ação","Only the action","Solo la acción","Seulement l'action","Nur die Aktion","Tik veiksmas"), L(lang,"Apenas o protocolo","Only the protocol","Solo el protocolo","Seulement le protocole","Nur das Protokoll","Tik protokolas"), L(lang,"Nada, está completa","Nothing, it is complete","Nada, está completa","Rien, elle est complète","Nichts, sie ist vollständig","Nieko, ji pilna")}, 0, 5,
                L(lang,"Depois da origem ainda é necessário indicar destino e, se aplicável, a porta ou condição.","After the source, destination and, when applicable, port/condition are still needed.","Después del origen falta indicar destino y, si aplica, puerto/condición.","Après l'origine, il faut encore indiquer destination et port/condition si applicable.","Nach der Quelle fehlen noch Ziel und ggf. Port/Bedingung.","Po šaltinio dar reikia nurodyti tikslą ir, jei reikia, prievadą/sąlygą.")),
            Make(L(lang,"Para permitir acesso da Internet a um servidor web 192.168.1.10, que regra é mais adequada?","To allow Internet access to web server 192.168.1.10, which rule is best?","Para permitir acceso desde Internet a un servidor web 192.168.1.10, ¿qué regla es mejor?","Pour autoriser Internet vers le serveur web 192.168.1.10, quelle règle convient le mieux ?","Welche Regel erlaubt Internetzugriff auf Webserver 192.168.1.10 am besten?","Kuri taisyklė tinkamiausia leisti interneto prieigą prie web serverio 192.168.1.10?"),
                new[]{"permit tcp any 192.168.1.10 eq 80","deny tcp any 192.168.1.10 eq 80","permit udp any 192.168.1.10 eq 53","permit tcp any any eq 22"}, 0, 5,
                L(lang,"HTTP usa TCP/80 e a regra deve apontar para o IP do servidor.","HTTP uses TCP/80 and the rule must target the server IP.","HTTP usa TCP/80 y la regla debe apuntar al IP del servidor.","HTTP utilise TCP/80 et la règle doit cibler l'IP du serveur.","HTTP nutzt TCP/80 und die Regel muss die Server-IP als Ziel haben.","HTTP naudoja TCP/80, o taisyklė turi būti nukreipta į serverio IP."))
        };
    }

    private static Question Make(string text, IEnumerable<string> options, int correct, int level, string explanation)
    {
        var pts = PointsForLevel(level);
        var original = options.ToList();
        var correctText = original[correct];
        var shuffled = original.OrderBy(_ => Random.Shared.Next()).ToList();
        return new Question
        {
            Text = text,
            Options = shuffled,
            CorrectIndex = shuffled.IndexOf(correctText),
            Level = level,
            PointsCorrect = pts.Correct,
            PointsWrong = pts.Wrong,
            Explanation = explanation
        };
    }
}
