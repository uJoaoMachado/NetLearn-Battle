# Mudanças feitas nesta versão

- O projeto passou para WPF para permitir uma interface mais moderna.
- A janela antiga/desformatada foi substituída por layout com menu lateral, cartões e scroll.
- As configurações passaram a aplicar cores à aplicação de forma mais consistente.
- A área do professor foi redesenhada com painel visual e log de servidor.
- Foi mantida a persistência obrigatória em JSON.
