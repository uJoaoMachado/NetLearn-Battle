# Correção servidor e lituano

- O arranque do servidor agora limpa sockets antigos da própria app antes de iniciar.
- Se as portas escolhidas estiverem ocupadas, a app tenta automaticamente as próximas portas livres e atualiza os campos TCP/UDP.
- A mensagem de erro foi melhorada para explicar quando há outra janela antiga aberta ou porta ocupada.
- O idioma Lituano foi expandido para a interface, menus, ranking, professor, treino, servidor e mensagens principais.
