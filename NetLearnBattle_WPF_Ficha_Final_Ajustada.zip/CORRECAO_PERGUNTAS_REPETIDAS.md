# Correção — perguntas repetidas

Alterações aplicadas:

- O gerador de perguntas agora tenta criar conjuntos sem textos repetidos na mesma sessão.
- O modo normal, treino e duelo 1v1 recebem perguntas embaralhadas.
- O duelo 1v1 online agora prepara uma fila própria de 5 perguntas por partida.
- Cada nova ronda do 1v1 consome a próxima pergunta dessa fila, evitando repetir sempre a mesma.
- As opções de resposta continuam a ser embaralhadas.

