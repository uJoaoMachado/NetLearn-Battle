# Mapeamento do Diagrama de Classes

Esta versão foi ajustada para ficar mais próxima do diagrama de classes enviado.

## Modelos principais

Na pasta `NetLearnBattle.Wpf/Modelos` existem agora classes alinhadas com o diagrama:

- `User`, `Student`, `Professor`, `Visitor`
- `Score` e `ScoreEntry`
- `GameSession`
- `QuestionQueue`
- `Question`
- `AttemptStack`
- `Attempt`
- `Ranking`
- `Statistics`
- `SessionClassStatistics`
- `ACL`, `ACLRule`, `Packet`

## Estrutura mantida simples

A aplicação continuou funcional com a estrutura anterior:

- `JanelaPrincipal/` contém a lógica da interface dividida por áreas.
- `Servicos/` contém persistência JSON, servidor local e geração de perguntas.
- `Modelos/` contém as entidades usadas pela app e entidades do diagrama.
- `Temas/` contém o estilo visual WPF.

## Nota importante

A classe `User` ficou concreta em vez de abstrata para não partir a persistência em `users.json` e o login existente. Foram adicionadas as classes `Student`, `Professor` e `Visitor` para representar a especialização do diagrama sem tornar o projeto demasiado complexo.
