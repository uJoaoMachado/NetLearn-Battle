# Melhorias aplicadas

- Adicionado botão lateral **Ranking 1v1**.
- Ranking 1v1 disponível no menu esquerdo para aluno e professor autenticados.
- Professor passa a ver também o ranking 1v1 dos alunos dentro das estatísticas/relatórios.
- Modo treino deixa de usar pop-ups para feedback.
- Treino passa a mostrar feedback dentro da própria interface, tal como o modo normal.
- Mantidas permissões: Guest continua limitado a ranking normal e regras.
