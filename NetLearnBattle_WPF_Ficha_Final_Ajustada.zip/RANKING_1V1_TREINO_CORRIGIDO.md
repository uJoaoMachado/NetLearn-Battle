# Correções aplicadas

- Adicionado ranking separado para o modo 1v1 online.
- Ranking 1v1 usa ranks: Bronze, Prata, Ouro, Diamante e Mestre.
- Pontuação dinâmica: quanto maior o rank atual, menos pontos o jogador ganha por vitória.
- O ranking 1v1 é guardado em `duel_ranks.json` no servidor.
- Adicionado botão próprio `Ranking 1v1` no menu do aluno e do professor.
- Depois de terminar um duelo, existe botão para abrir diretamente o ranking 1v1.
- Corrigido o modo treino: as perguntas falhadas já não criam opções artificiais sem sentido; agora o treino gera perguntas válidas e aleatórias dos níveis onde o aluno falhou.
- As respostas continuam baralhadas/shuffle.
