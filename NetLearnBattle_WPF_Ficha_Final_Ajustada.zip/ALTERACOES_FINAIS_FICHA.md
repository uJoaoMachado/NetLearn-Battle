# Alterações finais alinhadas com a ficha

Foram aplicadas apenas alterações nos pontos que faltavam na auditoria:

- Autenticação com SHA-256 + salt individual por utilizador.
- Compatibilidade com contas antigas sem salt: ao fazer login, a conta é migrada para salt individual.
- `acls.json` passou a guardar exemplos estruturados de ACLs.
- Nível 5 de ACLs reforçado com perguntas sobre:
  - primeira regra que faz match;
  - ordem das regras;
  - regra incompleta;
  - criação de regra para permitir acesso a servidor web;
  - permitir/negar pacotes.
- Nível 4 de IPv6 reforçado com:
  - Network ID;
  - inexistência de broadcast em IPv6;
  - verificação de mesmo segmento;
  - cálculo de sub-redes.
- Estatísticas melhoradas com:
  - média;
  - mediana;
  - moda;
  - acerto por nível;
  - evolução simples de score;
  - tópicos onde mais falha.
- Servidor passou a aceitar aliases de protocolo com nomes da ficha:
  - `AUTH_REQUEST` / `AUTH_RESPONSE`;
  - `QUESTION_PUSH`;
  - `ANSWER_SUBMIT`;
  - `SCORE_UPDATE`;
  - `RANKING_REQUEST` / `RANKING_RESPONSE`;
  - `STATS_REQUEST` / `STATS_RESPONSE`.

A lógica principal e a interface existente foram preservadas.
