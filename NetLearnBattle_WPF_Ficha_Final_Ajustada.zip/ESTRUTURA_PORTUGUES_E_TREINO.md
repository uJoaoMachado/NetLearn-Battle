# Alterações desta versão

## Estrutura em português

A estrutura principal do projeto foi reorganizada para ficar mais parecida com projetos escolares em C# com nomes simples em português, sem alterar a lógica principal da aplicação:

- `Modelos/Dominio.cs` — modelos/dados principais da aplicação.
- `Servicos/ArmazemJson.cs` — leitura e escrita dos ficheiros JSON.
- `Servicos/GeradorPerguntas.cs` — geração de perguntas e respostas aleatórias.
- `Servicos/ServidorLocal.cs` — servidor TCP/UDP e comunicação online.
- `Temas/TemaModerno.xaml` — estilos visuais da aplicação.

Os nomes das classes foram mantidos para não partir referências internas nem arriscar erros de compilação.

## Modo treino

O modo treino mantém o funcionamento anterior, mas agora mostra uma explicação maior depois de cada resposta. A explicação inclui:

- se o aluno acertou ou errou;
- a regra da matéria relacionada com o nível da pergunta;
- a resposta correta da pergunta;
- a explicação específica que já existia.

Isto ajuda o aluno a perceber o raciocínio em vez de apenas saber se acertou ou falhou.
