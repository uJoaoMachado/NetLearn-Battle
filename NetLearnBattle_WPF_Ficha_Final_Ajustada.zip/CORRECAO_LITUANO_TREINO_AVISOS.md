# Correção aplicada

- Removidos campos internos antigos que causavam avisos no Visual Studio.
- Corrigido o idioma Lituano para aparecer como **Lituano** e traduzir também perguntas/respostas/explicações quando possível.
- O modo treino passou a mostrar uma secção **Mini explicação** depois da resposta, dentro da própria interface.
- Mantida a lógica existente do projeto sem alterar os modos que já estavam funcionais.
