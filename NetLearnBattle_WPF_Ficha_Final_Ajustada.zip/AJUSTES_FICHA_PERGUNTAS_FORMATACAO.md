# Ajustes aplicados

- Texto do painel Servidor/Professor reduzido para tamanho normal.
- Mantido botão de ligar/desligar servidor TCP/UDP, portas e IPs visíveis.
- Perguntas agora são escolhidas aleatoriamente dentro de cada nível.
- Cada nível mostra a pontuação exata da ficha:
  - Nível 1: correto +10, errado -5
  - Nível 2: correto +20, errado -10
  - Nível 3: correto +30, errado -15
  - Nível 4: correto +40, errado -20
  - Nível 5: correto +50, errado -25
- Ecrã de pergunta mostra quanto vale antes de responder.
- Resultado mostra quantos pontos foram ganhos ou perdidos.
- Regras atualizadas com níveis, pontuação e indicação de perguntas aleatórias.
- Janela WPF abre maximizada e com layout mais adaptável para ocupar melhor o ecrã do PC.
