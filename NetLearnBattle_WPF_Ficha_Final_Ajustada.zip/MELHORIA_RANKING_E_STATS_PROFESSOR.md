# Melhoria de ranking e estatísticas do professor

Alterações aplicadas:

- Ranking continua obrigatório como Top 5.
- Pódio visual melhorado com destaque para 1.º, 2.º e 3.º lugar.
- Tabela Top 5 com pontuação, perguntas respondidas e percentagem de acerto.
- Estatísticas do professor agora mostram resumo player a player:
  - nome do aluno;
  - pontuação total;
  - respostas certas/total;
  - percentagem de acerto;
  - última resposta registada.

As restantes funcionalidades foram mantidas.
