# Melhorias aplicadas

- Modo treino melhorado e disponível offline.
- O modo treino permite treinar por nível ou rever perguntas falhadas.
- Jogar modo normal exige ligação validada ao servidor do professor.
- Duelo 1v1 passou a ser online: dois PCs ligados ao mesmo servidor entram numa fila e jogam 5 rondas.
- Servidor guarda e sincroniza o estado do duelo 1v1.
- Ranking continua Top 5.
- Sem servidor, ficam apenas opções offline/consulta como treino, ranking local e regras.
