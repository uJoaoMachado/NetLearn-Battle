# Correção UniformGrid

Adicionada a diretiva `using System.Windows.Controls.Primitives;` para corrigir o erro CS0246 do `UniformGrid` no ecrã de ranking.
