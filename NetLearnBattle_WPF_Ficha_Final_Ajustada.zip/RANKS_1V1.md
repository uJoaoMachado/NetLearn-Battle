# Ranking online 1v1
O ranking competitivo é guardado pelo servidor, por utilizador, após cada duelo concluído.

- Bronze: 0–99 pontos
- Prata: 100–249 pontos
- Ouro: 250–499 pontos
- Diamante: 500+ pontos

Vitória: +25 pontos; derrota: +8 pontos; empate: +15 pontos.
