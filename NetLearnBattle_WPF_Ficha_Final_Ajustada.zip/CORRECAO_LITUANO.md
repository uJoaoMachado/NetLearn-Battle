# Correção do idioma Lituano
- O seletor agora apresenta “Lituano”.
- Foi corrigido o fallback que mostrava textos em inglês quando não existia tradução específica.
- Perguntas e interface passam a usar o texto base em português enquanto a tradução lituana específica não estiver definida, evitando a mistura indevida com inglês.
