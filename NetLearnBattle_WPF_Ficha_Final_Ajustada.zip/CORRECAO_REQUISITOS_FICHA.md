# Correção de requisitos da ficha

Foram ajustadas as permissões para bater com a ficha do projeto:

## Perfis

### Guest / não autenticado
- Pode ver Ranking Top 5.
- Pode ver Regras do jogo.
- Não pode jogar.
- Não pode ver estatísticas pessoais.
- Não pode aceder às configurações.
- Não pode aceder ao painel do professor.

### Aluno autenticado
- Pode jogar.
- Pode escolher nível.
- Pode responder perguntas.
- Pode ver feedback imediato.
- Pode ver score, histórico e estatísticas pessoais.
- Pode ver ranking.
- Pode personalizar a interface.

### Professor autenticado
- Pode aceder ao painel do professor.
- Pode iniciar/parar servidor TCP/UDP.
- Pode ver atividade/relatórios gerais.
- Não entra como aluno automaticamente.

## Ficheiros alterados

- `NetLearnBattle.Wpf/MainWindow.xaml`
- `NetLearnBattle.Wpf/MainWindow.xaml.cs`
- `README.md`
