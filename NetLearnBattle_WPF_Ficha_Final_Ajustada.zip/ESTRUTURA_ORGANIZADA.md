# Estrutura organizada

Esta versão divide o código principal em ficheiros mais pequenos e fáceis de estudar.

## Pastas principais

- `Modelos/`: classes de dados simples, uma por ficheiro.
- `Servicos/`: lógica de JSON, perguntas e servidor local.
- `Temas/`: estilos visuais WPF.
- `JanelaPrincipal/`: partes da janela principal separadas por responsabilidade.

## Ficheiros da janela principal

- `MainWindow.xaml.cs`: só campos principais e arranque da janela.
- `01_Traducoes.cs`: idiomas e textos.
- `02_EstadoServidor.cs`: estado da ligação/servidor.
- `03_ComponentesInterface.cs`: botões, cartões e componentes visuais.
- `04_LoginELigacao.cs`: login, registo e ligação ao servidor.
- `05_InicioEJogo.cs`: menu inicial e jogo normal.
- `06_RankingEEstatisticas.cs`: rankings e estatísticas.
- `07_RegrasEProfessor.cs`: regras e painel do professor.
- `08_ModoTreino.cs`: treino e explicações.
- `09_DueloOnline.cs`: duelo 1v1 online.
- `10_ConfiguracoesENavegacao.cs`: configurações e botões de navegação.

A classe continua a chamar-se `MainWindow` para não partir o XAML nem o funcionamento.
