# Correção — desligar servidor sem crash

- Reposto comportamento seguro quando o servidor é desligado.
- A app deixa de fechar quando uma ligação TCP/UDP cai.
- O utilizador volta ao modo seguro com mensagem dentro da interface.
- Foram adicionados timeouts e tratamento de exceções no monitor do servidor e no duelo 1v1.
