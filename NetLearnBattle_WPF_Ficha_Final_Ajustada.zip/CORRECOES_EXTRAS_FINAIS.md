# Correções extras finais

- Removidas instruções visíveis com a conta do professor.
- Guest mantém acesso limitado: Ranking Top 5 e Regras.
- Professor tem relatórios globais, ranking, respostas recebidas e painel de servidor.
- IP do servidor agora mostra IP recomendado e outros IPs de rede detectados, evitando escolher IP aleatório sem contexto.
- Estatísticas redesenhadas com cartões, barras por nível e histórico visual.
- Adicionado Modo Treino com perguntas falhadas, sem afetar ranking.
- Adicionado mini-jogo Duelo 1v1 local e interativo para dois jogadores.
- Botões uniformizados com as cores do tema ativo.
- Respostas das perguntas são embaralhadas a cada geração, para a resposta certa não ficar sempre na mesma posição.
