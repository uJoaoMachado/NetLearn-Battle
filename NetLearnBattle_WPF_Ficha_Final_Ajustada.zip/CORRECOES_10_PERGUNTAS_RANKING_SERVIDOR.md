# Correções aplicadas

- Removido o botão de acesso direto ao professor no ecrã inicial.
- O professor só entra por login com a conta fornecida (`conta fornecida pelo docente`, ou outra conta de professor existente em `users.json`).
- Cada nível inicia agora uma sessão de 10 perguntas aleatórias.
- Ao acertar ou errar, o jogo mostra feedback e passa para a próxima pergunta.
- A pontuação da pergunta e o progresso `1/10 ... 10/10` aparecem durante o jogo.
- As respostas dos alunos são enviadas ao servidor do professor quando a ligação TCP/UDP está validada.
- O servidor guarda respostas e pontuações recebidas em JSON.
- O professor vê as últimas respostas recebidas no painel Servidor/Professor.
- O ranking pode ser pedido ao servidor pelos alunos ligados.
- O botão do servidor passou a ter texto normal: “Ligar servidor TCP/UDP”.

## Fluxo em rede

1. O professor faz login.
2. Abre `Servidor/Professor`.
3. Clica em `Ligar servidor TCP/UDP`.
4. O aluno abre a app noutro PC, coloca o IP do professor e a porta TCP/UDP.
5. O aluno clica em `Testar ligação`.
6. O aluno faz login/registo e joga.
7. As respostas aparecem no painel do professor e contam para o ranking do servidor.
