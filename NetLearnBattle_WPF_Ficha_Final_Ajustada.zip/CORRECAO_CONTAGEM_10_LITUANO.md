# Correção contagem 10/10 + idioma lituano

Alterações aplicadas:

- Corrigida a contagem das perguntas respondidas quando jogadores diferentes usam o servidor.
- Cada resposta agora tem um identificador único (`Id`) enviado para o servidor.
- O servidor deixa de juntar respostas válidas por engano quando duas respostas são parecidas ou acontecem no mesmo segundo.
- As estatísticas passam a contar cada pergunta real respondida, evitando casos 10 -> 9.
- Adicionado idioma Lituano (`Lietuvių`) à lista de idiomas.

Nota: dados antigos sem identificador continuam a ser lidos, mas a contagem nova passa a usar os IDs.
