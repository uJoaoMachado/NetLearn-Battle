# Correção Ranking Top 5 e execução

- Ranking mantém obrigatoriamente apenas os 5 melhores utilizadores.
- Quando os dados vêm do servidor, também são ordenados e limitados a Top 5.
- Pastas bin/obj removidas para evitar erro do Visual Studio com executável antigo.
- Para executar: abrir a solução, Limpar Solução, Recompilar Solução e iniciar.
