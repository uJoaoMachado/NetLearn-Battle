# Correção estado do servidor

- Ao ligar o servidor local, a aplicação passa a marcar a ligação como ativa automaticamente.
- Os modos online deixam de mostrar "servidor não ligado" quando o professor acabou de iniciar o servidor.
- Os comandos internos passam a conseguir comunicar com o próprio servidor local em `127.0.0.1`.
- Ao desligar o servidor, o estado volta corretamente para desligado e o monitor é parado.
