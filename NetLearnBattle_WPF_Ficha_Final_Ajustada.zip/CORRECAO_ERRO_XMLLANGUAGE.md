# Correção do erro CS1061 XmlLanguage

Foi corrigido o erro de compilação que aparecia em `MainWindow.xaml.cs` na linha do idioma.

## Causa
O enum interno chamava-se `Language`, o que podia entrar em conflito com tipos do WPF relacionados com `XmlLanguage`.

## Correção aplicada
- `Language` foi renomeado para `AppLanguage`.
- As referências em `MainWindow.xaml.cs` e `Models/Domain.cs` foram atualizadas.

Depois desta alteração, os erros:
- `XmlLanguage não contém uma definição para EN`
- `XmlLanguage não contém uma definição para ES`

ficam resolvidos.
