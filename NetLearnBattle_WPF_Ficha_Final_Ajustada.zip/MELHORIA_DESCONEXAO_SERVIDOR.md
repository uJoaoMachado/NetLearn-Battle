# Melhoria: desconexão do servidor e bloqueio de modos online

Alterações aplicadas:

- O aviso "sem servidor" deixou de ser uma caixa antiga do Windows e passou a ser um painel integrado na interface moderna da aplicação.
- Quando o servidor do professor deixa de responder, a aplicação:
  - para o duelo online;
  - limpa a sessão de jogo online ativa;
  - marca a ligação como desligada;
  - volta para um modo seguro;
  - bloqueia novamente os modos que precisam de servidor.
- Foi adicionado um monitor automático da ligação após o aluno validar o servidor.
- As opções offline continuam disponíveis: Modo treino, Ranking local e Regras.
