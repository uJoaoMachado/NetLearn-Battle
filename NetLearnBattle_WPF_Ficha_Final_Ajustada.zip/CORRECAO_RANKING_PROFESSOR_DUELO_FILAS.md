# Correções aplicadas

- O Ranking Top 5 no modo professor deixa de aparecer como "local" quando o servidor está ligado; passa a indicar que está atualizado pelo servidor no momento.
- O duelo 1v1 deixou de usar uma única fila global.
- Agora existe uma fila separada por nível: nível 1 joga com nível 1, nível 2 com nível 2, etc.
- Corrigido o bug em que, depois de terminar um duelo, o jogador podia ficar preso numa fila/estado antigo.
- Ao iniciar novo duelo, duelos terminados antigos desse jogador são limpos para permitir jogar novamente.
