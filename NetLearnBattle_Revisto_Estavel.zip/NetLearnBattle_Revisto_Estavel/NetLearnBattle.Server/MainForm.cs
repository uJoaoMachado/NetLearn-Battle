using NetLearnBattle.Shared;
using System.Net;
using System.Net.Sockets;
using System.Text;

namespace NetLearnBattle.Server;

public class MainForm : Form
{
    private readonly DataStore _store = new();
    private readonly Dictionary<string, Queue<Question>> _queues = new();
    private readonly Dictionary<string, Stack<Attempt>> _stacks = new();
    private readonly Dictionary<string, string> _tokens = new();
    private TcpListener? _listener;
    private CancellationTokenSource? _cts;

    private readonly TabControl _tabs = new() { Dock = DockStyle.Fill };
    private readonly TextBox _log = new();
    private readonly Button _start = new();
    private readonly Button _stop = new();
    private readonly NumericUpDown _port = new();
    private readonly ListBox _ranking = new();
    private readonly TextBox _teacherStats = new();
    private readonly ListBox _aclList = new();
    private readonly TextBox _aclName = new();
    private readonly TextBox _aclRules = new();

    public MainForm()
    {
        Text = "NetLearn Battle - Servidor Professor";
        Width = 1120; Height = 720; MinimumSize = new Size(980, 620);
        Font = new Font("Segoe UI", 10);
        BackColor = Color.FromArgb(15, 23, 42); ForeColor = Color.White;
        Controls.Add(_tabs);
        BuildDashboard();
        BuildStats();
        BuildAclManager();
        _start.Click += async (_, _) => await StartServer();
        _stop.Click += (_, _) => StopServer();
        RefreshRanking(); RefreshTeacherStats(); RefreshAcls();
    }

    private void BuildDashboard()
    {
        var page = Page("Servidor");
        Header(page, "Servidor / Professor", "Sessão TCP, logs, ranking e controlo da aula");
        AddLabel(page, "Porta", 32, 112); Box(_port, 32, 140, 110); _port.Minimum = 1024; _port.Maximum = 65000; _port.Value = 5000;
        _start.Text = "Iniciar sessão"; Button(_start, 160, 136, 150, Color.FromArgb(34, 197, 94));
        _stop.Text = "Parar"; Button(_stop, 325, 136, 100, Color.FromArgb(239, 68, 68)); _stop.Enabled = false;
        AddLabel(page, "Log de comunicação", 32, 190); TextArea(_log, 32, 220, 650, 390);
        AddLabel(page, "Ranking Top 5", 720, 112); _ranking.SetBounds(720, 140, 330, 470); ListStyle(_ranking);
        page.Controls.AddRange(new Control[] { _port, _start, _stop, _log, _ranking });
        _tabs.TabPages.Add(page);
    }

    private void BuildStats()
    {
        var page = Page("Estatísticas");
        Header(page, "Relatório da turma", "Totais, quartis, ranking e taxa de acerto por nível");
        var refresh = new Button { Text = "Atualizar relatório" }; Button(refresh, 32, 120, 170, Color.FromArgb(14, 165, 233));
        refresh.Click += (_, _) => RefreshTeacherStats();
        TextArea(_teacherStats, 32, 175, 1010, 430);
        page.Controls.AddRange(new Control[] { refresh, _teacherStats });
        _tabs.TabPages.Add(page);
    }

    private void BuildAclManager()
    {
        var page = Page("ACLs");
        Header(page, "Gestão de ACLs", "CRUD simples em acls.json. Uma regra por linha: action;protocol;source;destination;port;description");
        _aclList.SetBounds(32, 128, 290, 420); ListStyle(_aclList); _aclList.SelectedIndexChanged += (_, _) => LoadSelectedAcl();
        AddLabel(page, "Nome da ACL", 350, 128); Box(_aclName, 350, 155, 250);
        AddLabel(page, "Regras", 350, 200); TextArea(_aclRules, 350, 230, 680, 250);
        var save = new Button { Text = "Guardar / Atualizar" }; Button(save, 350, 500, 170, Color.FromArgb(34, 197, 94));
        var del = new Button { Text = "Remover" }; Button(del, 535, 500, 120, Color.FromArgb(239, 68, 68));
        var reload = new Button { Text = "Recarregar" }; Button(reload, 670, 500, 120, Color.FromArgb(168, 85, 247));
        save.Click += (_, _) => SaveAclFromUi(); del.Click += (_, _) => DeleteAclFromUi(); reload.Click += (_, _) => RefreshAcls();
        page.Controls.AddRange(new Control[] { _aclList, _aclName, _aclRules, save, del, reload });
        _tabs.TabPages.Add(page);
    }

    private TabPage Page(string text) => new() { Text = text, BackColor = Color.FromArgb(15, 23, 42), ForeColor = Color.White, Padding = new Padding(16) };
    private static void Header(Control p, string title, string subtitle)
    {
        p.Controls.Add(new Label { Text = title, Left = 32, Top = 18, Width = 940, Height = 64, Font = new Font("Segoe UI", 28, FontStyle.Bold), ForeColor = Color.FromArgb(96, 165, 250) });
        p.Controls.Add(new Label { Text = subtitle, Left = 36, Top = 88, Width = 920, Height = 28, ForeColor = Color.Gainsboro });
    }
    private static void AddLabel(Control p, string text, int x, int y) => p.Controls.Add(new Label { Text = text, Left = x, Top = y, AutoSize = true, ForeColor = Color.Gainsboro });
    private static void Box(Control c, int x, int y, int w) { c.SetBounds(x, y, w, 32); c.BackColor = Color.FromArgb(30, 41, 59); c.ForeColor = Color.White; }
    private static void TextArea(TextBox t, int x, int y, int w, int h) { t.SetBounds(x, y, w, h); t.Multiline = true; t.ScrollBars = ScrollBars.Vertical; t.ReadOnly = false; t.BackColor = Color.FromArgb(30, 41, 59); t.ForeColor = Color.White; t.BorderStyle = BorderStyle.FixedSingle; }
    private static void ListStyle(ListBox l) { l.BackColor = Color.FromArgb(30, 41, 59); l.ForeColor = Color.White; l.BorderStyle = BorderStyle.FixedSingle; }
    private static void Button(Button b, int x, int y, int w, Color color) { b.SetBounds(x, y, w, 40); b.BackColor = color; b.ForeColor = Color.White; b.FlatStyle = FlatStyle.Flat; b.FlatAppearance.BorderSize = 0; b.Font = new Font("Segoe UI", 10, FontStyle.Bold); b.Cursor = Cursors.Hand; }

    private void Log(string text)
    {
        if (InvokeRequired) { BeginInvoke(() => Log(text)); return; }
        _log.AppendText($"[{DateTime.Now:HH:mm:ss}] {text}{Environment.NewLine}");
    }

    private void RefreshRanking()
    {
        if (InvokeRequired) { BeginInvoke(RefreshRanking); return; }
        _ranking.Items.Clear(); int i = 1;
        foreach (var s in _store.Top5()) _ranking.Items.Add($"#{i++} {s.Username} - {s.TotalScore} pts");
    }

    private void RefreshTeacherStats()
    {
        if (InvokeRequired) { BeginInvoke(RefreshTeacherStats); return; }
        _teacherStats.Clear();
        foreach (var kv in _store.TeacherStats()) _teacherStats.AppendText($"{kv.Key}: {kv.Value}{Environment.NewLine}");
    }

    private void RefreshAcls()
    {
        _aclList.Items.Clear();
        foreach (var acl in _store.GetAcls()) _aclList.Items.Add(acl.Name);
    }

    private void LoadSelectedAcl()
    {
        if (_aclList.SelectedItem == null) return;
        var acl = _store.GetAcls().FirstOrDefault(a => a.Name == _aclList.SelectedItem.ToString());
        if (acl == null) return;
        _aclName.Text = acl.Name;
        _aclRules.Text = string.Join(Environment.NewLine, acl.Rules.Select(r => $"{r.Action};{r.Protocol};{r.Source};{r.Destination};{r.Port};{r.Description}"));
    }

    private void SaveAclFromUi()
    {
        var rules = new List<AceRule>();
        foreach (var line in _aclRules.Lines.Where(l => !string.IsNullOrWhiteSpace(l)))
        {
            var p = line.Split(';');
            if (p.Length < 5) continue;
            int? port = int.TryParse(p[4], out var n) ? n : null;
            rules.Add(new AceRule(p[0].Trim(), p[1].Trim(), p[2].Trim(), p[3].Trim(), port, p.Length > 5 ? p[5].Trim() : ""));
        }
        if (_store.UpsertAcl(new AclSet(_aclName.Text.Trim(), rules))) { RefreshAcls(); Log($"ACL guardada: {_aclName.Text}"); }
        else MessageBox.Show("ACL inválida. Verifica nome e regras.");
    }

    private void DeleteAclFromUi()
    {
        if (_aclList.SelectedItem == null) return;
        if (_store.DeleteAcl(_aclList.SelectedItem.ToString() ?? "")) { RefreshAcls(); _aclName.Clear(); _aclRules.Clear(); Log("ACL removida."); }
    }

    private async Task StartServer()
    {
        _cts = new CancellationTokenSource();
        _listener = new TcpListener(IPAddress.Any, (int)_port.Value);
        _listener.Start();
        _start.Enabled = false; _stop.Enabled = true;
        Log($"Servidor iniciado na porta {_port.Value}.");
        _ = Task.Run(() => AcceptLoop(_cts.Token));
        await Task.CompletedTask;
    }

    private void StopServer()
    {
        _cts?.Cancel(); _listener?.Stop(); _start.Enabled = true; _stop.Enabled = false;
        Log("Servidor parado.");
    }

    private async Task AcceptLoop(CancellationToken ct)
    {
        while (!ct.IsCancellationRequested)
        {
            try { var client = await _listener!.AcceptTcpClientAsync(ct); Log("Cliente ligado."); _ = Task.Run(() => HandleClient(client, ct)); }
            catch when (ct.IsCancellationRequested) { }
            catch (Exception ex) { Log("Erro accept: " + ex.Message); }
        }
    }

    private async Task HandleClient(TcpClient client, CancellationToken ct)
    {
        using var c = client; c.ReceiveTimeout = 30000; c.SendTimeout = 30000;
        using var stream = c.GetStream();
        using var reader = new StreamReader(stream, Encoding.UTF8);
        using var writer = new StreamWriter(stream, Encoding.UTF8) { AutoFlush = true };
        string user = "";
        try
        {
            while (!ct.IsCancellationRequested && c.Connected)
            {
                var req = await Protocol.ReceiveAsync(reader);
                if (req == null) break;
                var res = HandleMessage(req, ref user);
                await Protocol.SendAsync(writer, res);
                RefreshRanking(); RefreshTeacherStats();
            }
        }
        catch (IOException) { Log("Cliente desligado/timeout."); }
        catch (Exception ex) { Log("Erro cliente: " + ex.Message); }
    }

    private NetMessage HandleMessage(NetMessage req, ref string currentUser)
    {
        if (req.Type == "INVALID_JSON") return Fail("JSON malformado.");
        switch (req.Type)
        {
            case "REGISTER_REQUEST":
                if (string.IsNullOrWhiteSpace(req.Username) || string.IsNullOrWhiteSpace(req.Password)) return Fail("Dados inválidos.");
                bool created = _store.Register(req.Username.Trim(), req.Password);
                Log(created ? $"Registo: {req.Username}" : $"Registo recusado: {req.Username}");
                return new NetMessage { Type = "REGISTER_RESPONSE", Success = created, Message = created ? "Conta criada." : "Utilizador já existe ou dados inválidos." };
            case "AUTH_REQUEST":
                bool ok = req.Username != null && req.Password != null && _store.ValidateLogin(req.Username, req.Password);
                if (!ok) return new NetMessage { Type = "AUTH_RESPONSE", Success = false, Message = "Login inválido." };
                string token = Guid.NewGuid().ToString("N"); _tokens[token] = req.Username!; currentUser = req.Username!; Log($"Login: {currentUser}");
                return new NetMessage { Type = "AUTH_RESPONSE", Success = true, Token = token, Username = currentUser, Message = "Autenticado." };
            case "QUESTION_REQUEST":
                if (!Auth(req, out var username)) return Fail("Sessão inválida.");
                string key = username + ":" + req.Level;
                if (!_queues.ContainsKey(key) || _queues[key].Count == 0) _queues[key] = QuestionGenerator.BuildQueue(req.Level, 10, _store.GetAcls());
                if (!_stacks.ContainsKey(username)) _stacks[username] = new Stack<Attempt>();
                return new NetMessage { Type = "QUESTION_PUSH", Success = true, Question = _queues[key].Dequeue() };
            case "TRAINING_REQUEST":
                if (!Auth(req, out var trUser)) return Fail("Sessão inválida.");
                var failed = _store.FailedAttempts(trUser).FirstOrDefault();
                return failed == null ? Fail("Ainda não existem erros para treinar.") : new NetMessage { Type = "QUESTION_PUSH", Success = true, Question = QuestionGenerator.TrainingFromAttempt(failed) };
            case "ANSWER_SUBMIT":
                if (!Auth(req, out var u)) return Fail("Sessão inválida.");
                var q = req.Question; if (q == null) return Fail("Pergunta inválida.");
                bool correct = req.AnswerIndex == q.CorrectIndex;
                int pts = QuestionGenerator.PointsFor(q.Level, correct);
                var attempt = new Attempt(u, q.Id, q.Level, q.Type, q.Text, q.Options.ElementAtOrDefault(req.AnswerIndex) ?? "", q.CorrectAnswer, correct, req.DurationSeconds, pts, DateTime.Now);
                if (!_stacks.ContainsKey(u)) _stacks[u] = new Stack<Attempt>(); _stacks[u].Push(attempt);
                int score = _store.AddAttempt(attempt);
                Log($"{u} respondeu N{q.Level}: {(correct ? "certo" : "errado")} ({pts:+#;-#;0})");
                return new NetMessage { Type = "ANSWER_RESULT", Success = true, IsCorrect = correct, Points = pts, Score = score, Message = correct ? "Resposta correta!" : $"Errado. Resposta certa: {q.CorrectAnswer}" };
            case "RANKING_REQUEST": return new NetMessage { Type = "RANKING_RESPONSE", Success = true, Ranking = _store.Top5() };
            case "STATS_REQUEST": if (!Auth(req, out var su)) return Fail("Sessão inválida."); return new NetMessage { Type = "STATS_RESPONSE", Success = true, Stats = _store.StudentStats(su) };
            case "TEACHER_STATS_REQUEST": return new NetMessage { Type = "TEACHER_STATS_RESPONSE", Success = true, Stats = _store.TeacherStats() };
            case "ACL_LIST_REQUEST": return new NetMessage { Type = "ACL_LIST_RESPONSE", Success = true, Acls = _store.GetAcls() };
        }
        return Fail("Tipo de mensagem desconhecido.");
    }

    private bool Auth(NetMessage msg, out string username)
    {
        username = "";
        return msg.Token != null && _tokens.TryGetValue(msg.Token, out username!);
    }
    private static NetMessage Fail(string text) => new() { Type = "ERROR", Success = false, Message = text };
}
