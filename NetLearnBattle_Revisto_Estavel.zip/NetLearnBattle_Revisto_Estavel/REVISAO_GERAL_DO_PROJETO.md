# Revisão geral do projeto NetLearn Battle

Esta versão foi revista mantendo a base funcional do projeto: Server, Client e Shared.

## Corrigido / melhorado

- Mantida a comunicação TCP entre cliente e servidor.
- Mantido o protocolo JSON com mensagens de autenticação, perguntas, respostas, ranking e estatísticas.
- Mantidos os ficheiros JSON: `users.json`, `scores.json`, `attempts.json` e `acls.json`.
- Mantidas as estruturas de dados obrigatórias: `Queue<Question>` para perguntas e `Stack<Attempt>` para histórico de respostas.
- Corrigido problema visual em que alguns botões podiam usar fundo transparente e causar erros/contraste incorreto em certos temas.
- Corrigido comportamento dos modos de interface para reaplicar o tema ativo ao trocar entre Antigo, Moderno e Futurista.
- Ajustado espaçamento dos cabeçalhos e cartões para reduzir texto cortado/desformatado.
- Aumentado espaço da pergunta para evitar sobreposição nas perguntas mais longas.
- Melhorada a robustez da leitura dos JSON: se um ficheiro estiver corrompido, é criada uma cópia `.broken_...` e o ficheiro é reiniciado para evitar crash.
- Corrigida a geração de escolhas múltiplas para garantir que a resposta certa nunca fica fora das opções.
- Mantidas as línguas existentes: PT, EN, ES, FR, DE, IT e PT-BR.

## Ainda recomendado testar no Visual Studio

Como este ambiente não tem SDK .NET instalado, não foi possível compilar aqui. No Visual Studio faz:

1. `Compilar > Limpar Solução`
2. `Compilar > Recompilar Solução`
3. Arrancar `NetLearnBattle.Server` e `NetLearnBattle.Client` como múltiplos projetos de inicialização.

Se aparecerem erros, envia print da Lista de Erros.
