# Checklist da ficha — NetLearn Battle

| Requisito | Estado |
|---|---|
| Host/professor cria servidor TCP | Feito |
| Cliente/aluno liga por IP/porta | Feito |
| Comunicação em JSON | Feito |
| Login e registo | Feito |
| Password com hash + salt | Feito |
| `users.json` | Feito |
| `scores.json` | Feito |
| `attempts.json` | Feito |
| `acls.json` | Feito |
| Ranking Top 5 | Feito |
| Regras do jogo/fluxo de jogo | Base implementada |
| Nível 1 IPv4 | Feito |
| Nível 2 sub-redes IPv4 | Feito |
| Nível 3 super-redes IPv4 | Feito |
| Nível 4 IPv6 | Feito |
| Nível 5 ACLs | Feito, com margem para enriquecer |
| Perguntas em Queue | Feito |
| Respostas em Stack | Feito |
| Relatório do aluno | Feito |
| Relatório do professor | Feito |
| Modo treino | Feito |
| Geração IPv4 realista | Feito |
| Robustez de rede | Feito básico |
| CRUD de ACLs | Feito |
| Árvore/trie IPv4 | Feito |
| Interface gráfica | Feito |
| Temas e cor personalizada | Feito |
| Multi-idioma | Feito |

## Observação
A implementação cobre a estrutura principal do enunciado. A parte que ainda pode ser mais aprofundada é o nível 5 de ACLs, porque a ficha sugere vários tipos de exercícios possíveis. A base já usa `acls.json` e permite gestão pelo professor, mas podem ser criadas mais perguntas específicas de ordenação, regra em falta e geração completa de ACL.
