using NetLearnBattle.Shared;
using System.Drawing.Drawing2D;
using System.Net.Sockets;
using System.Text;

namespace NetLearnBattle.Client;

public class MainForm : Form
{
    private TcpClient? _client;
    private StreamReader? _reader;
    private StreamWriter? _writer;
    private string? _token;
    private Question? _current;
    private DateTime _questionStart;

    private string _lang = "pt";
    private UiMode _mode = UiMode.Modern;
    private Color _accent = Color.FromArgb(80, 130, 255);
    private Color _bg = Color.FromArgb(10, 16, 34);
    private Color _surface = Color.FromArgb(18, 27, 51);
    private Color _surface2 = Color.FromArgb(25, 37, 68);
    private Color _fg = Color.White;
    private Color _muted = Color.FromArgb(180, 190, 210);

    private readonly Panel _root = new() { Dock = DockStyle.Fill };
    private readonly Panel _sidebar = new();
    private readonly Panel _content = new();
    private readonly Label _brand = new();
    private readonly Label _brandSub = new();
    private readonly Dictionary<string, Button> _nav = new();
    private readonly Dictionary<string, Panel> _pages = new();
    private string _currentPage = "game";

    private readonly Label _pageTitle = new();
    private readonly Label _pageSubtitle = new();
    private readonly TextBox _host = new() { Text = "127.0.0.1" };
    private readonly NumericUpDown _port = new() { Minimum = 1024, Maximum = 65000, Value = 5000 };
    private readonly TextBox _user = new();
    private readonly TextBox _pass = new() { UseSystemPasswordChar = true };
    private readonly ComboBox _level = new();
    private readonly Label _status = new();
    private readonly Label _question = new();
    private readonly RadioButton[] _answers = new RadioButton[4];
    private readonly Button _connect = new();
    private readonly Button _login = new();
    private readonly Button _register = new();
    private readonly Button _next = new();
    private readonly Button _training = new();
    private readonly Button _submit = new();
    private readonly ListBox _ranking = new();
    private readonly TextBox _stats = new();
    private readonly ComboBox _language = new();
    private readonly ComboBox _theme = new();
    private readonly ComboBox _interfaceMode = new();
    private readonly Button _customColor = new();
    private readonly Label _modePreview = new();
    private readonly List<Control> _styledControls = new();
    private readonly List<Panel> _cards = new();

    private readonly Dictionary<string, Dictionary<string, string>> T = new()
    {
        ["pt"] = new(){["app"]="NetLearn Battle",["sub"]="Jogo educativo de Redes • IPv4 • IPv6 • ACLs",["connect"]="Ligar",["login"]="Login",["register"]="Registar",["host"]="Servidor",["user"]="Utilizador",["pass"]="Password",["game"]="Jogar",["ranking"]="Ranking",["stats"]="Estatísticas",["settings"]="Definições",["newq"]="Nova pergunta",["training"]="Modo treino",["submit"]="Submeter",["level"]="Nível",["theme"]="Tema",["language"]="Idioma",["custom"]="Escolher cor",["interface"]="Interface",["ready"]="Liga-te ao servidor para começar.",["needconnect"]="Primeiro liga ao servidor.",["needlogin"]="Primeiro faz login.",["ask"]="Escolhe um nível e pede uma pergunta.",["received"]="Pergunta recebida. Escolhe uma opção.",["select"]="Seleciona uma resposta.",["ranktitle"]="Ranking Top 5",["statstitle"]="Estatísticas pessoais",["visualnote"]="Escolhe o idioma, o tipo de interface, um tema base ou uma cor personalizada. A aplicação calcula automaticamente o contraste para evitar texto ilegível.",["update"]="Atualizar",["connTitle"]="Ligação e conta",["gameTitle"]="Arena de perguntas",["sideGame"]="Jogar",["sideRank"]="Ranking",["sideStats"]="Estatísticas",["sideSettings"]="Definições"},
        ["en"] = new(){["app"]="NetLearn Battle",["sub"]="Networking learning game • IPv4 • IPv6 • ACLs",["connect"]="Connect",["login"]="Login",["register"]="Register",["host"]="Server",["user"]="Username",["pass"]="Password",["game"]="Play",["ranking"]="Ranking",["stats"]="Statistics",["settings"]="Settings",["newq"]="New question",["training"]="Training mode",["submit"]="Submit",["level"]="Level",["theme"]="Theme",["language"]="Language",["custom"]="Pick color",["interface"]="Interface",["ready"]="Connect to the server to start.",["needconnect"]="Connect to the server first.",["needlogin"]="Login first.",["ask"]="Choose a level and request a question.",["received"]="Question received. Choose an option.",["select"]="Select an answer.",["ranktitle"]="Top 5 ranking",["statstitle"]="Personal statistics",["visualnote"]="Choose language, interface mode, a base theme, or a custom color. Contrast is calculated automatically to prevent unreadable text.",["update"]="Refresh",["connTitle"]="Connection and account",["gameTitle"]="Question arena",["sideGame"]="Play",["sideRank"]="Ranking",["sideStats"]="Statistics",["sideSettings"]="Settings"},
        ["es"] = new(){["app"]="NetLearn Battle",["sub"]="Juego educativo de redes • IPv4 • IPv6 • ACLs",["connect"]="Conectar",["login"]="Iniciar sesión",["register"]="Registrar",["host"]="Servidor",["user"]="Usuario",["pass"]="Contraseña",["game"]="Jugar",["ranking"]="Ranking",["stats"]="Estadísticas",["settings"]="Ajustes",["newq"]="Nueva pregunta",["training"]="Modo entrenamiento",["submit"]="Enviar",["level"]="Nivel",["theme"]="Tema",["language"]="Idioma",["custom"]="Elegir color",["interface"]="Interfaz",["ready"]="Conéctate al servidor para empezar.",["needconnect"]="Primero conecta al servidor.",["needlogin"]="Primero inicia sesión.",["ask"]="Elige un nivel y pide una pregunta.",["received"]="Pregunta recibida. Elige una opción.",["select"]="Selecciona una respuesta.",["ranktitle"]="Ranking Top 5",["statstitle"]="Estadísticas personales",["visualnote"]="Elige idioma, modo de interfaz, tema base o color personalizado. El contraste se calcula automáticamente.",["update"]="Actualizar",["connTitle"]="Conexión y cuenta",["gameTitle"]="Arena de preguntas",["sideGame"]="Jugar",["sideRank"]="Ranking",["sideStats"]="Estadísticas",["sideSettings"]="Ajustes"},
        ["fr"] = new(){["app"]="NetLearn Battle",["sub"]="Jeu éducatif réseaux • IPv4 • IPv6 • ACLs",["connect"]="Connexion",["login"]="Login",["register"]="Créer compte",["host"]="Serveur",["user"]="Utilisateur",["pass"]="Mot de passe",["game"]="Jouer",["ranking"]="Classement",["stats"]="Statistiques",["settings"]="Paramètres",["newq"]="Nouvelle question",["training"]="Mode entraînement",["submit"]="Valider",["level"]="Niveau",["theme"]="Thème",["language"]="Langue",["custom"]="Choisir couleur",["interface"]="Interface",["ready"]="Connecte-toi au serveur pour commencer.",["needconnect"]="Connecte-toi d'abord au serveur.",["needlogin"]="Connecte-toi d'abord.",["ask"]="Choisis un niveau et demande une question.",["received"]="Question reçue. Choisis une option.",["select"]="Sélectionne une réponse.",["ranktitle"]="Top 5",["statstitle"]="Statistiques personnelles",["visualnote"]="Choisis la langue, le mode d'interface, un thème ou une couleur. Le contraste est calculé automatiquement.",["update"]="Actualiser",["connTitle"]="Connexion et compte",["gameTitle"]="Arène de questions",["sideGame"]="Jouer",["sideRank"]="Classement",["sideStats"]="Statistiques",["sideSettings"]="Paramètres"},
        ["de"] = new(){["app"]="NetLearn Battle",["sub"]="Lernspiel für Netzwerke • IPv4 • IPv6 • ACLs",["connect"]="Verbinden",["login"]="Login",["register"]="Registrieren",["host"]="Server",["user"]="Benutzer",["pass"]="Passwort",["game"]="Spielen",["ranking"]="Rangliste",["stats"]="Statistik",["settings"]="Einstellungen",["newq"]="Neue Frage",["training"]="Training",["submit"]="Senden",["level"]="Level",["theme"]="Design",["language"]="Sprache",["custom"]="Farbe wählen",["interface"]="Oberfläche",["ready"]="Verbinde dich mit dem Server.",["needconnect"]="Zuerst mit dem Server verbinden.",["needlogin"]="Zuerst anmelden.",["ask"]="Wähle ein Level und fordere eine Frage an.",["received"]="Frage empfangen. Wähle eine Option.",["select"]="Wähle eine Antwort.",["ranktitle"]="Top-5-Rangliste",["statstitle"]="Persönliche Statistik",["visualnote"]="Wähle Sprache, Oberfläche, Design oder Farbe. Der Kontrast wird automatisch berechnet.",["update"]="Aktualisieren",["connTitle"]="Verbindung und Konto",["gameTitle"]="Fragen-Arena",["sideGame"]="Spielen",["sideRank"]="Rangliste",["sideStats"]="Statistik",["sideSettings"]="Einstellungen"},
        ["it"] = new(){["app"]="NetLearn Battle",["sub"]="Gioco educativo sulle reti • IPv4 • IPv6 • ACL",["connect"]="Connetti",["login"]="Login",["register"]="Registrati",["host"]="Server",["user"]="Utente",["pass"]="Password",["game"]="Gioca",["ranking"]="Classifica",["stats"]="Statistiche",["settings"]="Impostazioni",["newq"]="Nuova domanda",["training"]="Allenamento",["submit"]="Invia",["level"]="Livello",["theme"]="Tema",["language"]="Lingua",["custom"]="Scegli colore",["interface"]="Interfaccia",["ready"]="Connettiti al server per iniziare.",["needconnect"]="Prima connettiti al server.",["needlogin"]="Prima effettua il login.",["ask"]="Scegli un livello e richiedi una domanda.",["received"]="Domanda ricevuta. Scegli un'opzione.",["select"]="Seleziona una risposta.",["ranktitle"]="Top 5",["statstitle"]="Statistiche personali",["visualnote"]="Scegli lingua, modalità interfaccia, tema o colore. Il contrasto viene calcolato automaticamente.",["update"]="Aggiorna",["connTitle"]="Connessione e account",["gameTitle"]="Arena domande",["sideGame"]="Gioca",["sideRank"]="Classifica",["sideStats"]="Statistiche",["sideSettings"]="Impostazioni"},
        ["br"] = new(){["app"]="NetLearn Battle",["sub"]="Jogo educativo de Redes • IPv4 • IPv6 • ACLs",["connect"]="Conectar",["login"]="Login",["register"]="Cadastrar",["host"]="Servidor",["user"]="Usuário",["pass"]="Senha",["game"]="Jogar",["ranking"]="Ranking",["stats"]="Estatísticas",["settings"]="Configurações",["newq"]="Nova pergunta",["training"]="Modo treino",["submit"]="Enviar",["level"]="Nível",["theme"]="Tema",["language"]="Idioma",["custom"]="Escolher cor",["interface"]="Interface",["ready"]="Conecte-se ao servidor para começar.",["needconnect"]="Primeiro conecte-se ao servidor.",["needlogin"]="Primeiro faça login.",["ask"]="Escolha um nível e peça uma pergunta.",["received"]="Pergunta recebida. Escolha uma opção.",["select"]="Selecione uma resposta.",["ranktitle"]="Ranking Top 5",["statstitle"]="Estatísticas pessoais",["visualnote"]="Escolha idioma, interface, tema ou cor personalizada. O contraste é calculado automaticamente.",["update"]="Atualizar",["connTitle"]="Ligação e conta",["gameTitle"]="Arena de perguntas",["sideGame"]="Jogar",["sideRank"]="Ranking",["sideStats"]="Estatísticas",["sideSettings"]="Configurações"}
    };

    public MainForm()
    {
        Text = "NetLearn Battle";
        Width = 1280;
        Height = 800;
        MinimumSize = new Size(1080, 700);
        StartPosition = FormStartPosition.CenterScreen;
        Font = new Font("Segoe UI", 10);
        DoubleBuffered = true;

        Controls.Add(_root);
        BuildShell();
        BuildGamePage();
        BuildRankingPage();
        BuildStatsPage();
        BuildSettingsPage();

        _connect.Click += async (_, _) => await Connect();
        _login.Click += async (_, _) => await Login();
        _register.Click += async (_, _) => await Register();
        _next.Click += async (_, _) => await NextQuestion(false);
        _training.Click += async (_, _) => await NextQuestion(true);
        _submit.Click += async (_, _) => await SubmitAnswer();
        _language.SelectedIndexChanged += (_, _) => { var codes = new[] { "pt", "en", "es", "fr", "de", "it", "br" }; _lang = codes[Math.Max(0, _language.SelectedIndex)]; ApplyLanguage(); };
        _interfaceMode.SelectedIndexChanged += (_, _) => { _mode = (UiMode)Math.Max(0, _interfaceMode.SelectedIndex); ApplyTheme(_theme.SelectedItem?.ToString() ?? "Aurora"); };
        _theme.SelectedIndexChanged += (_, _) => ApplyTheme(_theme.SelectedItem?.ToString() ?? "Aurora");
        _customColor.Click += (_, _) => { using var dlg = new ColorDialog { Color = _accent, FullOpen = true }; if (dlg.ShowDialog() == DialogResult.OK) ApplyCustomColor(dlg.Color); };

        _language.SelectedIndex = 0;
        _interfaceMode.SelectedIndex = 1;
        _theme.SelectedIndex = 0;
        ShowPage("game");
        ApplyLanguage();
        ToggleGame(false);
        Status(Tr("ready"));
    }

    private void BuildShell()
    {
        _root.BackColor = _bg;
        _sidebar.Dock = DockStyle.Left;
        _sidebar.Width = 250;
        _sidebar.Padding = new Padding(18);
        _content.Dock = DockStyle.Fill;
        _content.Padding = new Padding(28);

        _brand.Text = "NetLearn";
        _brand.Font = new Font("Segoe UI", 24, FontStyle.Bold);
        _brand.SetBounds(22, 28, 200, 42);
        _brandSub.Text = "Battle Arena";
        _brandSub.SetBounds(25, 72, 200, 24);
        _brandSub.Font = new Font("Segoe UI", 10, FontStyle.Bold);
        _sidebar.Controls.AddRange(new Control[] { _brand, _brandSub });

        AddNav("game", "▶  Jogar", 125);
        AddNav("ranking", "★  Ranking", 178);
        AddNav("stats", "▣  Estatísticas", 231);
        AddNav("settings", "⚙  Definições", 284);

        _root.Controls.AddRange(new Control[] { _content, _sidebar });
    }

    private void AddNav(string key, string text, int top)
    {
        var b = new Button { Text = text, Tag = key, Left = 18, Top = top, Width = 210, Height = 44, TextAlign = ContentAlignment.MiddleLeft, Padding = new Padding(16, 0, 0, 0), Cursor = Cursors.Hand };
        b.Click += (_, _) => ShowPage(key);
        _nav[key] = b;
        _sidebar.Controls.Add(b);
    }

    private void BuildGamePage()
    {
        var page = Page("game");
        Header(page, "app", "sub");

        var conn = Card(24, 145, 1090, 175);
        CardTitle(conn, "connTitle", 24, 18);
        AddLabel(conn, "host", 26, 62); Input(_host, 26, 90, 160); Input(_port, 198, 90, 95); ActionButton(_connect, 310, 86, 140, ButtonRole.Primary);
        AddLabel(conn, "user", 485, 62); Input(_user, 485, 90, 170); AddLabel(conn, "pass", 670, 62); Input(_pass, 670, 90, 170);
        ActionButton(_login, 858, 86, 100, ButtonRole.Success); ActionButton(_register, 970, 86, 110, ButtonRole.Secondary);
        page.Controls.Add(conn);

        _status.SetBounds(30, 335, 1080, 38);
        _status.Font = new Font("Segoe UI", 10, FontStyle.Bold);
        page.Controls.Add(_status);

        var arena = Card(24, 390, 1090, 340);
        CardTitle(arena, "gameTitle", 24, 20);
        AddLabel(arena, "level", 28, 70);
        _level.DropDownStyle = ComboBoxStyle.DropDownList;
        _level.Items.AddRange(new object[] { "1 - IPv4 básico", "2 - Sub-redes IPv4", "3 - Super-redes IPv4", "4 - IPv6", "5 - ACLs" });
        _level.SelectedIndex = 0;
        Input(_level, 88, 64, 230);
        ActionButton(_next, 340, 60, 160, ButtonRole.Info); ActionButton(_training, 515, 60, 150, ButtonRole.Warning); ActionButton(_submit, 680, 60, 125, ButtonRole.Success);
        _question.SetBounds(28, 120, 1010, 96);
        _question.Font = new Font("Segoe UI", 13, FontStyle.Bold);
        _question.AutoEllipsis = false;
        _question.TextAlign = ContentAlignment.MiddleLeft;
        arena.Controls.AddRange(new Control[] { _level, _next, _training, _submit, _question });
        for (int i = 0; i < 4; i++)
        {
            _answers[i] = new RadioButton { Left = 42, Top = 225 + i * 29, Width = 1000, Height = 28, FlatStyle = FlatStyle.Flat };
            arena.Controls.Add(_answers[i]);
        }
        page.Controls.Add(arena);
    }

    private void BuildRankingPage()
    {
        var page = Page("ranking");
        Header(page, "ranktitle", "sub");
        var card = Card(24, 150, 740, 500);
        _ranking.SetBounds(28, 30, 680, 420);
        _ranking.Font = new Font("Segoe UI", 14, FontStyle.Bold);
        _ranking.BorderStyle = BorderStyle.None;
        var refresh = new Button();
        ActionButton(refresh, 28, 455, 150, ButtonRole.Primary);
        refresh.Name = "tr_update";
        refresh.Click += async (_, _) => await LoadRanking();
        card.Controls.AddRange(new Control[] { _ranking, refresh });
        page.Controls.Add(card);
    }

    private void BuildStatsPage()
    {
        var page = Page("stats");
        Header(page, "statstitle", "sub");
        var card = Card(24, 150, 900, 500);
        _stats.SetBounds(28, 30, 840, 405);
        _stats.Multiline = true;
        _stats.ReadOnly = true;
        _stats.ScrollBars = ScrollBars.Vertical;
        _stats.BorderStyle = BorderStyle.None;
        var refresh = new Button();
        ActionButton(refresh, 28, 450, 150, ButtonRole.Primary);
        refresh.Name = "tr_update";
        refresh.Click += async (_, _) => await LoadStats();
        card.Controls.AddRange(new Control[] { _stats, refresh });
        page.Controls.Add(card);
    }

    private void BuildSettingsPage()
    {
        var page = Page("settings");
        Header(page, "settings", "visualnote");
        var card = Card(24, 175, 900, 360);
        AddLabel(card, "language", 28, 38);
        _language.DropDownStyle = ComboBoxStyle.DropDownList;
        _language.Items.AddRange(new object[] { "Português", "English", "Español", "Français", "Deutsch", "Italiano", "Português Brasil" });
        Input(_language, 28, 68, 230);
        AddLabel(card, "interface", 300, 38);
        _interfaceMode.DropDownStyle = ComboBoxStyle.DropDownList;
        _interfaceMode.Items.AddRange(new object[] { "Antigo", "Moderno", "Futurista" });
        Input(_interfaceMode, 300, 68, 220);
        AddLabel(card, "theme", 570, 38);
        _theme.DropDownStyle = ComboBoxStyle.DropDownList;
        _theme.Items.AddRange(new object[] { "Aurora", "Emerald", "Purple", "Light", "Dark", "Ocean", "Sunset", "Cyber" });
        Input(_theme, 570, 68, 220);
        ActionButton(_customColor, 28, 135, 180, ButtonRole.Warning);
        _modePreview.SetBounds(28, 205, 820, 82);
        _modePreview.Font = new Font("Segoe UI", 11, FontStyle.Bold);
        _modePreview.Text = "Antigo: simples | Moderno: cards e sombras | Futurista: neon e contraste alto";
        _modePreview.AutoEllipsis = false;
        card.Controls.AddRange(new Control[] { _language, _interfaceMode, _theme, _customColor, _modePreview });
        page.Controls.Add(card);
    }

    private Panel Page(string key)
    {
        var p = new Panel { Dock = DockStyle.Fill, Visible = false, Name = key };
        _pages[key] = p;
        _content.Controls.Add(p);
        return p;
    }

    private void Header(Control p, string titleKey, string subKey)
    {
        var h = new Label { Name = "tr_" + titleKey, Left = 24, Top = 18, Width = 980, Height = 64, Font = new Font("Segoe UI", 28, FontStyle.Bold), AutoEllipsis = true, TextAlign = ContentAlignment.MiddleLeft };
        var s = new Label { Name = "tr_" + subKey, Left = 28, Top = 86, Width = 980, Height = 70, Font = new Font("Segoe UI", 10, FontStyle.Bold), AutoEllipsis = false, TextAlign = ContentAlignment.TopLeft };
        p.Controls.AddRange(new Control[] { h, s });
    }

    private Panel Card(int x, int y, int w, int h)
    {
        var p = new RoundedPanel { Left = x, Top = y, Width = w, Height = h, Radius = 24, Padding = new Padding(12) };
        _cards.Add(p); return p;
    }

    private void CardTitle(Control p, string key, int x, int y) => p.Controls.Add(new Label { Name = "tr_" + key, Left = x, Top = y, Width = 520, Height = 32, Font = new Font("Segoe UI", 14, FontStyle.Bold), AutoEllipsis = true });
    private void AddLabel(Control p, string key, int x, int y) => p.Controls.Add(new Label { Name = "tr_" + key, Left = x, Top = y, Width = 160, Height = 22, Font = new Font("Segoe UI", 9, FontStyle.Bold), AutoEllipsis = true });

    private void Input(Control c, int x, int y, int w)
    {
        c.SetBounds(x, y, w, 34);
        _styledControls.Add(c);
    }

    private void ActionButton(Button b, int x, int y, int w, ButtonRole role)
    {
        b.SetBounds(x, y, w, 40);
        b.Tag = role;
        b.FlatStyle = FlatStyle.Flat;
        b.FlatAppearance.BorderSize = 0;
        b.Font = new Font("Segoe UI", 10, FontStyle.Bold);
        b.Cursor = Cursors.Hand;
        _styledControls.Add(b);
    }

    private void ShowPage(string key)
    {
        _currentPage = key;
        foreach (var kv in _pages) kv.Value.Visible = kv.Key == key;
        foreach (var kv in _nav) kv.Value.BackColor = kv.Key == key ? _accent : _sidebar.BackColor;
        ApplyVisuals();
    }

    private void ToggleGame(bool enabled) { _next.Enabled = enabled; _training.Enabled = enabled; _submit.Enabled = enabled; _level.Enabled = enabled; }
    private void Status(string text) { _status.Text = text; _status.ForeColor = _accent; }

    private void ApplyLanguage()
    {
        Text = Tr("app"); _brand.Text = "NetLearn"; _brandSub.Text = "Battle Arena";
        _connect.Text = Tr("connect"); _login.Text = Tr("login"); _register.Text = Tr("register"); _next.Text = Tr("newq"); _training.Text = Tr("training"); _submit.Text = Tr("submit"); _customColor.Text = Tr("custom");
        if (_current == null) _question.Text = Tr("ask");
        _nav["game"].Text = "▶  " + Tr("sideGame"); _nav["ranking"].Text = "★  " + Tr("sideRank"); _nav["stats"].Text = "▣  " + Tr("sideStats"); _nav["settings"].Text = "⚙  " + Tr("sideSettings");
        foreach (Control root in Controls) ApplyLanguageRecursive(root);
    }

    private void ApplyLanguageRecursive(Control c)
    {
        foreach (Control child in c.Controls)
        {
            if (child.Name.StartsWith("tr_")) child.Text = Tr(child.Name[3..]);
            ApplyLanguageRecursive(child);
        }
    }

    private string Tr(string key) => T.TryGetValue(_lang, out var d) && d.TryGetValue(key, out var v) ? v : key;

    private void ApplyTheme(string theme)
    {
        switch (theme)
        {
            case "Emerald": SetPalette(Color.FromArgb(16, 185, 129), Color.FromArgb(4, 44, 36), Color.FromArgb(13, 72, 61), Color.White); break;
            case "Purple": SetPalette(Color.FromArgb(168, 85, 247), Color.FromArgb(30, 16, 58), Color.FromArgb(51, 30, 91), Color.White); break;
            case "Light": SetPalette(Color.FromArgb(37, 99, 235), Color.FromArgb(238, 242, 247), Color.White, Color.FromArgb(15, 23, 42)); break;
            case "Dark": SetPalette(Color.FromArgb(148, 163, 184), Color.FromArgb(3, 7, 18), Color.FromArgb(15, 23, 42), Color.White); break;
            case "Ocean": SetPalette(Color.FromArgb(45, 212, 191), Color.FromArgb(5, 41, 68), Color.FromArgb(10, 72, 108), Color.White); break;
            case "Sunset": SetPalette(Color.FromArgb(249, 115, 22), Color.FromArgb(58, 21, 9), Color.FromArgb(104, 45, 18), Color.White); break;
            case "Cyber": SetPalette(Color.FromArgb(0, 245, 255), Color.FromArgb(9, 7, 26), Color.FromArgb(23, 18, 55), Color.White); break;
            default: SetPalette(Color.FromArgb(80, 130, 255), Color.FromArgb(10, 16, 34), Color.FromArgb(18, 27, 51), Color.White); break;
        }
        ApplyVisuals();
    }

    private void ApplyCustomColor(Color color)
    {
        _accent = color;
        bool lightAccent = Brightness(color) > 0.62;
        _bg = lightAccent ? Blend(color, Color.White, 0.78) : Blend(color, Color.Black, 0.76);
        _surface = lightAccent ? Blend(color, Color.White, 0.88) : Blend(color, Color.Black, 0.55);
        _surface2 = lightAccent ? Blend(color, Color.White, 0.80) : Blend(color, Color.Black, 0.42);
        _fg = Brightness(_bg) > 0.55 ? Color.FromArgb(15, 23, 42) : Color.White;
        _muted = Brightness(_bg) > 0.55 ? Color.FromArgb(70, 80, 95) : Color.FromArgb(190, 200, 215);
        ApplyVisuals();
    }

    private void SetPalette(Color accent, Color bg, Color surface, Color fg)
    {
        _accent = accent; _bg = bg; _surface = surface; _surface2 = Blend(surface, accent, 0.10); _fg = fg;
        _muted = Brightness(_bg) > 0.55 ? Color.FromArgb(70, 80, 95) : Color.FromArgb(190, 200, 215);
    }

    private void ApplyVisuals()
    {
        if (_mode == UiMode.Classic)
        {
            _root.BackColor = SystemColors.Control;
            _sidebar.BackColor = SystemColors.ControlLight;
            _content.BackColor = SystemColors.Control;
            _fg = Color.FromArgb(25, 25, 25);
            _surface = Color.White;
            _surface2 = Color.FromArgb(245, 245, 245);
        }
        else
        {
            _root.BackColor = _bg;
            _content.BackColor = _bg;
            _sidebar.BackColor = _mode == UiMode.Futuristic ? Blend(_bg, _accent, 0.14) : Blend(_bg, Color.Black, 0.18);
        }

        _brand.ForeColor = _accent;
        _brandSub.ForeColor = _muted;
        foreach (var p in _pages.Values) { p.BackColor = _content.BackColor; RepaintRecursive(p); }
        foreach (var card in _cards)
        {
            card.BackColor = _mode == UiMode.Classic ? Color.White : _surface;
            if (card is RoundedPanel rp) { rp.Radius = _mode == UiMode.Classic ? 6 : _mode == UiMode.Modern ? 24 : 30; rp.BorderColor = _mode == UiMode.Futuristic ? _accent : Blend(_surface, _fg, 0.12); }
        }
        foreach (var kv in _nav)
        {
            var selected = kv.Key == _currentPage;
            kv.Value.FlatStyle = FlatStyle.Flat;
            kv.Value.FlatAppearance.BorderSize = 0;
            kv.Value.Font = new Font("Segoe UI", _mode == UiMode.Futuristic ? 11 : 10, FontStyle.Bold);
            kv.Value.ForeColor = selected ? Contrast(_accent) : _fg;
            kv.Value.BackColor = selected ? _accent : _sidebar.BackColor;
        }
        foreach (var c in _styledControls) StyleControl(c);
        _modePreview.ForeColor = _muted;
        _status.ForeColor = _accent;
        Invalidate(true);
    }

    private void StyleControl(Control c)
    {
        if (c is Button b)
        {
            var role = b.Tag is ButtonRole r ? r : ButtonRole.Primary;
            var color = role switch { ButtonRole.Success => Color.FromArgb(34, 197, 94), ButtonRole.Secondary => Color.FromArgb(168, 85, 247), ButtonRole.Warning => Color.FromArgb(245, 158, 11), ButtonRole.Info => Color.FromArgb(14, 165, 233), _ => _accent };
            if (_mode == UiMode.Classic) color = role == ButtonRole.Primary ? SystemColors.Highlight : color;
            b.BackColor = color;
            b.ForeColor = Contrast(color);
            b.FlatAppearance.MouseOverBackColor = Blend(color, Color.White, 0.18);
            b.FlatAppearance.MouseDownBackColor = Blend(color, Color.Black, 0.18);
        }
        else if (c is TextBox or ComboBox or NumericUpDown or ListBox)
        {
            c.BackColor = _surface2;
            c.ForeColor = _fg;
        }
    }

    private void RepaintRecursive(Control c)
    {
        foreach (Control child in c.Controls)
        {
            if (child is Label or RadioButton) child.ForeColor = child == _status ? _accent : _fg;
            if (child is TextBox or ComboBox or NumericUpDown or ListBox) StyleControl(child);
            RepaintRecursive(child);
        }
    }

    private static Color Blend(Color a, Color b, double amountOfB)
    {
        amountOfB = Math.Clamp(amountOfB, 0, 1);
        double amountOfA = 1 - amountOfB;
        return Color.FromArgb((int)(a.R * amountOfA + b.R * amountOfB), (int)(a.G * amountOfA + b.G * amountOfB), (int)(a.B * amountOfA + b.B * amountOfB));
    }

    private static double Brightness(Color c) => (0.299 * c.R + 0.587 * c.G + 0.114 * c.B) / 255.0;
    private static Color Contrast(Color c) => Brightness(c) > 0.56 ? Color.FromArgb(10, 20, 35) : Color.White;

    private async Task Connect()
    {
        try
        {
            _client = new TcpClient(); _client.ReceiveTimeout = 30000; _client.SendTimeout = 30000;
            await _client.ConnectAsync(_host.Text.Trim(), (int)_port.Value);
            var stream = _client.GetStream();
            _reader = new StreamReader(stream, Encoding.UTF8);
            _writer = new StreamWriter(stream, Encoding.UTF8) { AutoFlush = true };
            Status(_lang == "pt" ? "Ligado ao servidor. Faz login ou cria conta." : "Connected. Login or create an account.");
            await LoadRanking();
        }
        catch (Exception ex) { Status((_lang == "pt" ? "Erro de ligação: " : "Connection error: ") + ex.Message); }
    }

    private async Task Login()
    {
        if (!Ready()) return;
        await Protocol.SendAsync(_writer!, new NetMessage { Type = "AUTH_REQUEST", Username = _user.Text.Trim(), Password = _pass.Text });
        var res = await Protocol.ReceiveAsync(_reader!);
        if (res?.Success == true) { _token = res.Token; ToggleGame(true); Status((_lang == "pt" ? "Bem-vindo, " : "Welcome, ") + res.Username + "!"); await LoadRanking(); await LoadStats(); }
        else Status(res?.Message ?? "Login falhou.");
    }

    private async Task Register()
    {
        if (!Ready()) return;
        await Protocol.SendAsync(_writer!, new NetMessage { Type = "REGISTER_REQUEST", Username = _user.Text.Trim(), Password = _pass.Text });
        var res = await Protocol.ReceiveAsync(_reader!);
        Status(res?.Message ?? "Sem resposta.");
    }

    private async Task NextQuestion(bool training)
    {
        if (!ReadyAuth()) return;
        await Protocol.SendAsync(_writer!, new NetMessage { Type = training ? "TRAINING_REQUEST" : "QUESTION_REQUEST", Token = _token, Level = _level.SelectedIndex + 1 });
        var res = await Protocol.ReceiveAsync(_reader!);
        if (res?.Question == null) { Status(res?.Message ?? "Não recebi pergunta."); return; }
        _current = res.Question; _questionStart = DateTime.Now; _question.Text = _current.Text;
        for (int i = 0; i < 4; i++) { _answers[i].Checked = false; _answers[i].Text = i < _current.Options.Count ? _current.Options[i] : ""; _answers[i].Visible = i < _current.Options.Count; }
        Status(Tr("received"));
    }

    private async Task SubmitAnswer()
    {
        if (!ReadyAuth() || _current == null) { Status(_lang == "pt" ? "Pede primeiro uma pergunta." : "Request a question first."); return; }
        int idx = Array.FindIndex(_answers, a => a.Checked);
        if (idx < 0) { Status(Tr("select")); return; }
        double secs = (DateTime.Now - _questionStart).TotalSeconds;
        await Protocol.SendAsync(_writer!, new NetMessage { Type = "ANSWER_SUBMIT", Token = _token, Question = _current, AnswerIndex = idx, DurationSeconds = secs });
        var res = await Protocol.ReceiveAsync(_reader!);
        if (res == null) { Status("Sem resposta do servidor."); return; }
        Status($"{res.Message} Pontos: {res.Points}. Score total: {res.Score}");
        await LoadRanking(); await LoadStats();
    }

    private async Task LoadRanking()
    {
        if (!Ready()) return;
        await Protocol.SendAsync(_writer!, new NetMessage { Type = "RANKING_REQUEST" });
        var res = await Protocol.ReceiveAsync(_reader!);
        _ranking.Items.Clear(); int i = 1; foreach (var s in res?.Ranking ?? new List<Score>()) _ranking.Items.Add($"#{i++}   {s.Username}       {s.TotalScore} pts");
    }

    private async Task LoadStats()
    {
        if (!ReadyAuth()) return;
        await Protocol.SendAsync(_writer!, new NetMessage { Type = "STATS_REQUEST", Token = _token });
        var res = await Protocol.ReceiveAsync(_reader!);
        _stats.Clear(); if (res?.Stats != null) foreach (var kv in res.Stats) _stats.AppendText($"{kv.Key}: {kv.Value}{Environment.NewLine}");
    }

    private bool Ready() { if (_writer == null || _reader == null) { Status(Tr("needconnect")); return false; } return true; }
    private bool ReadyAuth() { if (!Ready()) return false; if (_token == null) { Status(Tr("needlogin")); return false; } return true; }

    private enum UiMode { Classic, Modern, Futuristic }
    private enum ButtonRole { Primary, Success, Secondary, Warning, Info }

    private sealed class RoundedPanel : Panel
    {
        public int Radius { get; set; } = 22;
        public Color BorderColor { get; set; } = Color.Transparent;
        public RoundedPanel() { DoubleBuffered = true; }
        protected override void OnPaint(PaintEventArgs e)
        {
            base.OnPaint(e);
            e.Graphics.SmoothingMode = SmoothingMode.AntiAlias;
            using var path = RoundedRect(new Rectangle(0, 0, Width - 1, Height - 1), Radius);
            using var brush = new SolidBrush(BackColor);
            e.Graphics.FillPath(brush, path);
            if (BorderColor != Color.Transparent)
            {
                using var pen = new Pen(BorderColor, 1.5f);
                e.Graphics.DrawPath(pen, path);
            }
        }
        protected override void OnResize(EventArgs eventargs)
        {
            base.OnResize(eventargs);
            using var path = RoundedRect(new Rectangle(0, 0, Width, Height), Radius);
            Region = new Region(path);
        }
        private static GraphicsPath RoundedRect(Rectangle bounds, int radius)
        {
            int d = radius * 2;
            var path = new GraphicsPath();
            path.AddArc(bounds.X, bounds.Y, d, d, 180, 90);
            path.AddArc(bounds.Right - d, bounds.Y, d, d, 270, 90);
            path.AddArc(bounds.Right - d, bounds.Bottom - d, d, d, 0, 90);
            path.AddArc(bounds.X, bounds.Bottom - d, d, d, 90, 90);
            path.CloseFigure();
            return path;
        }
    }
}
