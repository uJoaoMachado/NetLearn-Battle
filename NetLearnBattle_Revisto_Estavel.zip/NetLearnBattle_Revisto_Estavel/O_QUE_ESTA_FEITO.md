# NetLearn Battle — estado do projeto

## Estado geral
Esta versão inclui uma base funcional para o projeto integrador: aplicação Cliente/Servidor em C# WinForms, comunicação TCP, protocolo JSON, autenticação, jogo por níveis, persistência em ficheiros JSON, ranking, estatísticas, Queue, Stack e melhorias extra da ficha.

## Requisitos da ficha já implementados

### Funcionamento local/rede
- Cliente e servidor separados.
- Servidor/professor cria sessão TCP numa porta configurável.
- Cliente/aluno liga por IP e porta.
- Comunicação por mensagens JSON.

### Perfis e autenticação
- Registo de utilizador.
- Login de utilizador.
- Password guardada com hash SHA-256 + salt.
- Utilizador autenticado pode jogar, ver score, histórico/estatísticas e ranking.
- Ranking Top 5 disponível no cliente.

### Persistência JSON
- `users.json`: utilizadores, hash e salt.
- `scores.json`: pontuação acumulada.
- `attempts.json`: tentativas/respostas, duração, nível e resultado.
- `acls.json`: biblioteca de ACLs usada no nível 5.

### Perguntas por níveis
- Nível 1: IPv4 básico com prefixos `/8`, `/16`, `/24`.
- Nível 2: sub-redes IPv4 com `/25`, `/26`, `/27`, `/28`, `/29`, `/30`.
- Nível 3: super-redes/sumarização IPv4 com `/21`, `/22`, `/23`.
- Nível 4: IPv6 com network ID e sub-redes.
- Nível 5: ACLs carregadas a partir de `acls.json`.
- Todas as perguntas são de escolha múltipla.

### Pontuação
- Nível 1: certo `+10`, errado `-5`.
- Nível 2: certo `+20`, errado `-10`.
- Nível 3: certo `+30`, errado `-15`.
- Nível 4: certo `+40`, errado `-20`.
- Nível 5: certo `+50`, errado `-25`.

### Estruturas de Dados
- `Queue<Question>`: fila de perguntas por jogador/nível.
- `Stack<Attempt>`: pilha de tentativas recentes por aluno.
- `Ipv4PrefixTrie`: árvore/trie IPv4 para validar pertença a redes em perguntas de segmento.

### Protocolo de comunicação
Mensagens existentes no projeto:
- `REGISTER_REQUEST`, `REGISTER_RESPONSE`
- `AUTH_REQUEST`, `AUTH_RESPONSE`
- `QUESTION_REQUEST`, `QUESTION_PUSH`
- `TRAINING_REQUEST`
- `ANSWER_SUBMIT`, `ANSWER_RESULT`
- `RANKING_REQUEST`, `RANKING_RESPONSE`
- `STATS_REQUEST`, `STATS_RESPONSE`
- `TEACHER_STATS_REQUEST`, `TEACHER_STATS_RESPONSE`
- `ACL_LIST_REQUEST`, `ACL_LIST_RESPONSE`

### Relatórios estatísticos
Aluno:
- Total de perguntas respondidas.
- Taxa de respostas certas.
- Taxa por nível.
- Média/mediana/moda aproximada do tempo de resposta.
- Evolução do score por tentativas/sessões.
- Tópicos com mais falhas.

Professor:
- Ranking Top 5.
- Total de tentativas.
- Taxa geral de acerto.
- Taxa por nível.
- Distribuição por quartis.

## Melhorias de valorização já adicionadas
- Geração de IPv4 mais realista com endereços privados.
- Modo treino com repetição de perguntas falhadas.
- Robustez em rede: timeouts, desconexões e JSON malformado.
- CRUD de ACLs no servidor/professor.
- Árvore/trie IPv4 para apoiar validação de pertença a redes.
- Interface gráfica com temas e idiomas.

## Melhorias de interface adicionadas
- Interface WinForms mais espaçada e corrigida para evitar texto sobreposto.
- Separadores: Jogar, Ranking, Estatísticas e Definições.
- Temas predefinidos: Azul, Verde, Roxo, Claro, Escuro, Ocean, Sunset e Cyber.
- Paleta de cores personalizada.
- A cor personalizada altera agora também o fundo e os cartões, não apenas o botão/acento.
- Idiomas disponíveis: Português, Inglês, Espanhol, Francês e Alemão.

## O que ainda pode ser melhorado se houver tempo
- Gráficos reais para estatísticas do professor.
- Guardar preferências de idioma/tema num ficheiro local.
- Acrescentar mais tipos de perguntas ACL: ordenação de regras, regra em falta e geração completa de ACL.
- Melhorar visualmente para WPF/Maui se o professor aceitar outra tecnologia.
