# Alterações feitas nesta versão

Esta versão mantém o projeto funcional que enviaste: servidor, cliente, Shared, TCP, JSON, autenticação, perguntas, ranking, estatísticas, Queue, Stack e ficheiros JSON.

## O que foi alterado

- Substituída a interface do cliente por uma estrutura nova, sem mexer na lógica TCP/JSON.
- Removido o layout antigo com separadores visíveis como interface principal.
- Criado menu lateral com páginas: Jogar, Ranking, Estatísticas e Definições.
- Criados cartões visuais para ligação, conta e arena de perguntas.
- Corrigido texto desformatado com labels maiores e `AutoEllipsis`.
- Mantidas as línguas anteriores e adicionadas Italiano e Português Brasil.
- Adicionada escolha de interface: Antigo, Moderno e Futurista.
- Melhorado o sistema de temas para mudar mais do que apenas uma cor.
- Corrigido o problema da paleta de cores com cálculo automático de contraste.
- A cor personalizada passa a alterar fundo, cartões, botões e contraste.

## Como testar

1. Abrir `NetLearnBattle.sln` no Visual Studio.
2. Recompilar a solução.
3. Configurar múltiplos projetos de inicialização:
   - `NetLearnBattle.Server` = Iniciar
   - `NetLearnBattle.Client` = Iniciar
   - `NetLearnBattle.Shared` = Nenhuma
4. Executar.
5. No cliente usar IP `127.0.0.1` e porta `5000`.

## Nota

O projeto foi ajustado em cima da versão funcional enviada pelo utilizador. Não é uma estrutura vazia nem uma versão separada sem servidor.
