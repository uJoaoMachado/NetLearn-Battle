using System.Text.Json;

namespace NetLearnBattle.Shared;

public class DataStore
{
    private readonly string _dataDir;
    private readonly object _lock = new();
    private readonly JsonSerializerOptions _json = new() { WriteIndented = true, PropertyNameCaseInsensitive = true };

    public DataStore(string? dataDir = null)
    {
        _dataDir = dataDir ?? Path.Combine(AppContext.BaseDirectory, "data");
        Directory.CreateDirectory(_dataDir);
        EnsureFiles();
    }

    private string PathFor(string file) => Path.Combine(_dataDir, file);

    private void EnsureFiles()
    {
        Ensure("users.json", new List<User>());
        Ensure("scores.json", new List<Score>());
        Ensure("attempts.json", new List<Attempt>());
        Ensure("acls.json", new List<AclSet>
        {
            new("WebServer", new()
            {
                new("permit", "tcp", "any", "192.168.1.10/32", 80, "HTTP público"),
                new("permit", "tcp", "any", "192.168.1.10/32", 443, "HTTPS público"),
                new("deny", "ip", "any", "any", null, "bloquear resto")
            }),
            new("MailServer", new()
            {
                new("permit", "tcp", "any", "10.0.0.20/32", 25, "SMTP"),
                new("permit", "tcp", "any", "10.0.0.20/32", 993, "IMAPS"),
                new("deny", "ip", "any", "any", null, "deny final")
            })
        });
    }

    private void Ensure<T>(string file, T value)
    {
        string path = PathFor(file);
        if (!File.Exists(path)) File.WriteAllText(path, JsonSerializer.Serialize(value, _json));
    }

    public List<T> Load<T>(string file)
    {
        lock (_lock)
        {
            string path = PathFor(file);
            try
            {
                string text = File.ReadAllText(path);
                return JsonSerializer.Deserialize<List<T>>(text, _json) ?? new List<T>();
            }
            catch
            {
                string backup = path + ".broken_" + DateTime.Now.ToString("yyyyMMdd_HHmmss");
                if (File.Exists(path)) File.Copy(path, backup, overwrite: true);
                var empty = new List<T>();
                File.WriteAllText(path, JsonSerializer.Serialize(empty, _json));
                return empty;
            }
        }
    }

    public void Save<T>(string file, List<T> items)
    {
        lock (_lock) File.WriteAllText(PathFor(file), JsonSerializer.Serialize(items, _json));
    }

    public bool Register(string username, string password, string role = "Aluno")
    {
        username = username.Trim();
        if (username.Length < 3 || password.Length < 4) return false;
        var users = Load<User>("users.json");
        if (users.Any(u => u.Username.Equals(username, StringComparison.OrdinalIgnoreCase))) return false;
        string salt = Crypto.NewSalt();
        users.Add(new User(username, Crypto.HashPassword(password, salt), salt, role));
        Save("users.json", users);
        return true;
    }

    public bool ValidateLogin(string username, string password)
    {
        var user = Load<User>("users.json").FirstOrDefault(u => u.Username.Equals(username, StringComparison.OrdinalIgnoreCase));
        return user is not null && Crypto.HashPassword(password, user.Salt) == user.PasswordHash;
    }

    public int AddAttempt(Attempt attempt)
    {
        var attempts = Load<Attempt>("attempts.json");
        attempts.Add(attempt);
        Save("attempts.json", attempts);

        var scores = Load<Score>("scores.json");
        var old = scores.FirstOrDefault(s => s.Username.Equals(attempt.Username, StringComparison.OrdinalIgnoreCase));
        int total = (old?.TotalScore ?? 0) + attempt.Points;
        scores.RemoveAll(s => s.Username.Equals(attempt.Username, StringComparison.OrdinalIgnoreCase));
        scores.Add(new Score(attempt.Username, total, DateTime.Now));
        Save("scores.json", scores);
        return total;
    }

    public List<Score> Top5() => Load<Score>("scores.json").OrderByDescending(s => s.TotalScore).Take(5).ToList();

    public Dictionary<string, object> StudentStats(string username)
    {
        var list = Load<Attempt>("attempts.json").Where(a => a.Username.Equals(username, StringComparison.OrdinalIgnoreCase)).ToList();
        var times = list.Select(a => a.DurationSeconds).OrderBy(x => x).ToList();
        double avg = times.Count == 0 ? 0 : times.Average();
        double median = Median(times);
        double mode = ModeRounded(times);
        double rate = list.Count == 0 ? 0 : list.Count(a => a.IsCorrect) * 100.0 / list.Count;
        string weak = list.Where(a => !a.IsCorrect).GroupBy(a => $"N{a.Level} {a.Type}").OrderByDescending(g => g.Count()).Select(g => g.Key).FirstOrDefault() ?? "Sem falhas";
        return new Dictionary<string, object>
        {
            ["Total perguntas"] = list.Count,
            ["Taxa global"] = $"{rate:0.0}%",
            ["Tempo médio"] = $"{avg:0.0}s",
            ["Mediana tempo"] = $"{median:0.0}s",
            ["Moda tempo"] = $"{mode:0.0}s",
            ["Tópico com mais falhas"] = weak,
            ["Por nível"] = string.Join(" | ", list.GroupBy(a => a.Level).OrderBy(g => g.Key).Select(g => $"N{g.Key}: {g.Count(x => x.IsCorrect)}/{g.Count()}"))
        };
    }

    public Dictionary<string, object> TeacherStats()
    {
        var attempts = Load<Attempt>("attempts.json");
        var scores = Load<Score>("scores.json").OrderBy(s => s.TotalScore).ToList();
        return new Dictionary<string, object>
        {
            ["Alunos com score"] = scores.Count,
            ["Tentativas totais"] = attempts.Count,
            ["Ranking Top 5"] = string.Join(" | ", Top5().Select(s => $"{s.Username}: {s.TotalScore}")),
            ["Taxa certa por nível"] = string.Join(" | ", attempts.GroupBy(a => a.Level).OrderBy(g => g.Key).Select(g => $"N{g.Key}: {(g.Count(x => x.IsCorrect) * 100.0 / Math.Max(1, g.Count())):0.0}%")),
            ["Score Q1"] = scores.Count == 0 ? 0 : Quartile(scores.Select(s => (double)s.TotalScore).ToList(), .25),
            ["Score Mediana"] = scores.Count == 0 ? 0 : Quartile(scores.Select(s => (double)s.TotalScore).ToList(), .50),
            ["Score Q3"] = scores.Count == 0 ? 0 : Quartile(scores.Select(s => (double)s.TotalScore).ToList(), .75)
        };
    }

    public List<Attempt> FailedAttempts(string username) => Load<Attempt>("attempts.json").Where(a => a.Username.Equals(username, StringComparison.OrdinalIgnoreCase) && !a.IsCorrect).OrderByDescending(a => a.CreatedAt).ToList();

    public List<AclSet> GetAcls() => Load<AclSet>("acls.json");
    public void SaveAcls(List<AclSet> sets) => Save("acls.json", sets);
    public bool UpsertAcl(AclSet set)
    {
        if (string.IsNullOrWhiteSpace(set.Name) || set.Rules.Count == 0) return false;
        var all = GetAcls();
        all.RemoveAll(a => a.Name.Equals(set.Name, StringComparison.OrdinalIgnoreCase));
        all.Add(set);
        SaveAcls(all);
        return true;
    }
    public bool DeleteAcl(string name)
    {
        var all = GetAcls();
        int removed = all.RemoveAll(a => a.Name.Equals(name, StringComparison.OrdinalIgnoreCase));
        SaveAcls(all);
        return removed > 0;
    }

    private static double Median(List<double> values) => values.Count == 0 ? 0 : values.Count % 2 == 1 ? values[values.Count / 2] : (values[values.Count / 2 - 1] + values[values.Count / 2]) / 2.0;
    private static double ModeRounded(List<double> values) => values.Count == 0 ? 0 : values.Select(v => Math.Round(v)).GroupBy(v => v).OrderByDescending(g => g.Count()).First().Key;
    private static double Quartile(List<double> values, double q)
    {
        values.Sort();
        if (values.Count == 0) return 0;
        double pos = (values.Count - 1) * q;
        int lo = (int)Math.Floor(pos), hi = (int)Math.Ceiling(pos);
        if (lo == hi) return values[lo];
        return values[lo] + (values[hi] - values[lo]) * (pos - lo);
    }
}
