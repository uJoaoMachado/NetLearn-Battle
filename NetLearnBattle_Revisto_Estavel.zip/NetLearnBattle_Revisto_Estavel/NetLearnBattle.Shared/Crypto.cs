using System.Security.Cryptography;
using System.Text;

namespace NetLearnBattle.Shared;

public static class Crypto
{
    public static string NewSalt()
    {
        byte[] bytes = RandomNumberGenerator.GetBytes(16);
        return Convert.ToBase64String(bytes);
    }

    public static string HashPassword(string password, string salt)
    {
        using var sha = SHA256.Create();
        byte[] data = Encoding.UTF8.GetBytes(password + salt);
        return Convert.ToHexString(sha.ComputeHash(data));
    }
}
