using System.Net;

namespace NetLearnBattle.Shared;

public static class QuestionGenerator
{
    private static readonly Random Rng = Random.Shared;

    public static Queue<Question> BuildQueue(int level, int count = 10, List<AclSet>? acls = null)
    {
        var q = new Queue<Question>();
        for (int i = 0; i < count; i++) q.Enqueue(Create(level, acls));
        return q;
    }

    public static int PointsFor(int level, bool correct) => level switch
    {
        1 => correct ? 10 : -5,
        2 => correct ? 20 : -10,
        3 => correct ? 30 : -15,
        4 => correct ? 40 : -20,
        5 => correct ? 50 : -25,
        _ => correct ? 10 : -5
    };

    public static Question Create(int level, List<AclSet>? acls = null) => level switch
    {
        1 => Ipv4Question(level, new[] { 8, 16, 24 }),
        2 => Ipv4Question(level, new[] { 25, 26, 27, 28, 29, 30 }),
        3 => Ipv4Question(level, new[] { 21, 22, 23 }),
        4 => Ipv6Question(),
        5 => AclQuestion(acls),
        _ => Ipv4Question(1, new[] { 8, 16, 24 })
    };

    public static Question TrainingFromAttempt(Attempt failed)
    {
        var opts = new[] { failed.CorrectAnswer, failed.UserAnswer, "Não sei", "Outra opção" }.Where(x => !string.IsNullOrWhiteSpace(x)).Distinct().Take(4).ToList();
        while (opts.Count < 4) opts.Add($"Opção {opts.Count + 1}");
        opts = opts.OrderBy(_ => Rng.Next()).ToList();
        return new Question { Level = failed.Level, Type = "Treino", Text = "Modo treino: tenta novamente - " + failed.QuestionText, Options = opts, CorrectIndex = opts.IndexOf(failed.CorrectAnswer) };
    }

    private static Question Ipv4Question(int level, int[] prefixes)
    {
        int prefix = prefixes[Rng.Next(prefixes.Length)];
        string ip = RandomPrivateIpv4();
        uint ipNum = ToUInt(ip);
        uint mask = prefix == 0 ? 0 : uint.MaxValue << (32 - prefix);
        uint network = ipNum & mask;
        uint broadcast = network | ~mask;
        int kind = Rng.Next(3);
        string correct;
        string text;
        if (kind == 0)
        {
            correct = FromUInt(network);
            text = $"Nível {level}: Qual é o Network ID de {ip}/{prefix}?";
        }
        else if (kind == 1)
        {
            correct = FromUInt(broadcast);
            text = $"Nível {level}: Qual é o Broadcast de {ip}/{prefix}?";
        }
        else
        {
            bool sameSegment = Rng.Next(2) == 0;
            uint range = Math.Max(2, Math.Min(200, broadcast - network));
            string ip2;
            if (sameSegment)
            {
                ip2 = FromUInt(network + (uint)Rng.Next(1, (int)range));
            }
            else
            {
                uint blockSize = prefix == 32 ? 1u : 1u << (32 - prefix);
                uint otherNetwork = network > blockSize ? network - blockSize : network + blockSize;
                ip2 = FromUInt(otherNetwork + 1);
            }
            var trie = new Ipv4PrefixTrie();
            trie.Insert(FromUInt(network), prefix);
            correct = trie.Contains(ip2) ? "Sim" : "Não";
            text = $"Nível {level}: {ip} e {ip2} pertencem ao mesmo segmento /{prefix}?";
            return Mcq(level, "IPv4", text, correct, new[] { "Sim", "Não", "Depende da gateway", "Só em IPv6" });
        }
        return Mcq(level, "IPv4", text, correct, MakeIpv4Distractors(correct));
    }

    private static string RandomPrivateIpv4()
    {
        int block = Rng.Next(3);
        return block switch
        {
            0 => $"10.{Rng.Next(0,256)}.{Rng.Next(0,256)}.{Rng.Next(1,255)}",
            1 => $"172.{Rng.Next(16,32)}.{Rng.Next(0,256)}.{Rng.Next(1,255)}",
            _ => $"192.168.{Rng.Next(0,256)}.{Rng.Next(1,255)}"
        };
    }

    private static Question Ipv6Question()
    {
        string prefix = "2001:db8:abcd";
        int subnet = Rng.Next(1, 65535);
        string ip = $"{prefix}:{subnet:x4}::{Rng.Next(1,999):x}";
        int kind = Rng.Next(2);
        if (kind == 0)
        {
            string correct = $"{prefix}:{subnet:x4}::/64";
            return Mcq(4, "IPv6", $"Nível 4: Qual é o Network ID IPv6 de {ip}/64?", correct, new[] { correct, $"{prefix}:{(subnet + 1):x4}::/64", $"{prefix}:0000::/48", "fe80::/10" });
        }
        return Mcq(4, "IPv6", "Nível 4: Quantas sub-redes /64 existem dentro de uma rede /56?", "256", new[] { "16", "64", "256", "1024" });
    }

    private static Question AclQuestion(List<AclSet>? acls)
    {
        var set = (acls != null && acls.Count > 0) ? acls[Rng.Next(acls.Count)] : new AclSet("Default", new() { new("permit", "tcp", "any", "192.168.1.10/32", 443), new("deny", "ip", "any", "any", null) });
        var permit = set.Rules.FirstOrDefault(r => r.Action.Equals("permit", StringComparison.OrdinalIgnoreCase)) ?? set.Rules.First();
        string port = permit.Port.HasValue ? $" porta {permit.Port}" : "";
        string text = $"Nível 5: ACL '{set.Name}'. Primeira regra: {permit.Action} {permit.Protocol} {permit.Source} {permit.Destination}{port}. Qual é a ação para um pacote que faz match nesta regra?";
        return Mcq(5, "ACL", text, permit.Action.ToLowerInvariant(), new[] { "permit", "deny", "sem match", "depende da gateway" });
    }

    private static Question Mcq(int level, string type, string text, string correct, IEnumerable<string> options)
    {
        var distinct = options.Where(o => !string.IsNullOrWhiteSpace(o)).Distinct(StringComparer.OrdinalIgnoreCase).ToList();
        if (!distinct.Any(o => o.Equals(correct, StringComparison.OrdinalIgnoreCase))) distinct.Insert(0, correct);
        while (distinct.Count < 4) distinct.Add(type == "IPv4" ? $"192.168.{Rng.Next(0,255)}.{Rng.Next(0,255)}" : $"Opção {distinct.Count + 1}");
        distinct = distinct.Take(4).OrderBy(_ => Rng.Next()).ToList();
        int correctIndex = distinct.FindIndex(o => o.Equals(correct, StringComparison.OrdinalIgnoreCase));
        if (correctIndex < 0)
        {
            distinct[0] = correct;
            correctIndex = 0;
        }
        return new Question { Level = level, Type = type, Text = text, Options = distinct, CorrectIndex = correctIndex };
    }

    private static IEnumerable<string> MakeIpv4Distractors(string correct)
    {
        var parts = correct.Split('.').Select(int.Parse).ToArray();
        yield return correct;
        yield return $"{parts[0]}.{parts[1]}.{Math.Clamp(parts[2] + 1, 0, 255)}.{parts[3]}";
        yield return $"{parts[0]}.{parts[1]}.{parts[2]}.0";
        yield return $"{parts[0]}.{parts[1]}.255.255";
    }

    private static uint ToUInt(string ip)
    {
        var b = IPAddress.Parse(ip).GetAddressBytes();
        if (BitConverter.IsLittleEndian) Array.Reverse(b);
        return BitConverter.ToUInt32(b, 0);
    }

    private static string FromUInt(uint value)
    {
        var b = BitConverter.GetBytes(value);
        if (BitConverter.IsLittleEndian) Array.Reverse(b);
        return new IPAddress(b).ToString();
    }
}
