using System.Net;

namespace NetLearnBattle.Shared;

public sealed class Ipv4PrefixTrie
{
    private sealed class Node
    {
        public Node? Zero { get; set; }
        public Node? One { get; set; }
        public bool IsNetwork { get; set; }
    }

    private readonly Node _root = new();

    public void Insert(string networkIp, int prefix)
    {
        uint value = ToUInt(networkIp);
        Node current = _root;
        for (int i = 31; i >= 32 - prefix; i--)
        {
            bool bit = ((value >> i) & 1) == 1;
            if (bit) current = current.One ??= new Node();
            else current = current.Zero ??= new Node();
        }
        current.IsNetwork = true;
    }

    public bool Contains(string ip)
    {
        uint value = ToUInt(ip);
        Node? current = _root;
        bool matched = false;
        for (int i = 31; i >= 0 && current != null; i--)
        {
            if (current.IsNetwork) matched = true;
            bool bit = ((value >> i) & 1) == 1;
            current = bit ? current.One : current.Zero;
        }
        return matched || current?.IsNetwork == true;
    }

    private static uint ToUInt(string ip)
    {
        var b = IPAddress.Parse(ip).GetAddressBytes();
        if (BitConverter.IsLittleEndian) Array.Reverse(b);
        return BitConverter.ToUInt32(b, 0);
    }
}
