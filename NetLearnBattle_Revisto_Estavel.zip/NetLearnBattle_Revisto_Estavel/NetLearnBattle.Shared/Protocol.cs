using System.Net.Sockets;
using System.Text.Json;

namespace NetLearnBattle.Shared;

public static class Protocol
{
    private static readonly JsonSerializerOptions Json = new() { PropertyNameCaseInsensitive = true };

    public static async Task SendAsync(StreamWriter writer, NetMessage msg)
    {
        string line = JsonSerializer.Serialize(msg, Json);
        await writer.WriteLineAsync(line);
        await writer.FlushAsync();
    }

    public static async Task<NetMessage?> ReceiveAsync(StreamReader reader)
    {
        string? line = await reader.ReadLineAsync();
        if (string.IsNullOrWhiteSpace(line)) return null;
        try { return JsonSerializer.Deserialize<NetMessage>(line, Json); }
        catch { return new NetMessage { Type = "INVALID_JSON", Success = false, Message = "JSON malformado." }; }
    }
}
