using System.Text.Json.Serialization;

namespace NetLearnBattle.Shared;

public record User(string Username, string PasswordHash, string Salt, string Role = "Aluno");
public record Score(string Username, int TotalScore, DateTime UpdatedAt);
public record Attempt(string Username, string QuestionId, int Level, string Type, string QuestionText, string UserAnswer, string CorrectAnswer, bool IsCorrect, double DurationSeconds, int Points, DateTime CreatedAt);
public record AceRule(string Action, string Protocol, string Source, string Destination, int? Port, string Description = "");
public record AclSet(string Name, List<AceRule> Rules);

public class Question
{
    public string Id { get; set; } = Guid.NewGuid().ToString("N");
    public int Level { get; set; }
    public string Type { get; set; } = "IPv4";
    public string Text { get; set; } = "";
    public List<string> Options { get; set; } = new();
    public int CorrectIndex { get; set; }
    [JsonIgnore] public string CorrectAnswer => Options.Count > CorrectIndex && CorrectIndex >= 0 ? Options[CorrectIndex] : "";
}

public class NetMessage
{
    public string Type { get; set; } = "";
    public string? Token { get; set; }
    public string? Username { get; set; }
    public string? Password { get; set; }
    public int Level { get; set; }
    public string? QuestionId { get; set; }
    public int AnswerIndex { get; set; }
    public double DurationSeconds { get; set; }
    public string? Message { get; set; }
    public Question? Question { get; set; }
    public bool Success { get; set; }
    public bool IsCorrect { get; set; }
    public int Points { get; set; }
    public int Score { get; set; }
    public List<Score> Ranking { get; set; } = new();
    public Dictionary<string, object> Stats { get; set; } = new();
    public List<AclSet> Acls { get; set; } = new();
    public AclSet? Acl { get; set; }
}
