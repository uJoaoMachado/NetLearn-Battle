# NetLearn Battle

Projeto integrador de ALGED/RCOM2/PROG2/ESTAD.

## Como executar no Visual Studio

1. Abrir `NetLearnBattle.sln` no Visual Studio 2022.
2. Clicar com botão direito na solução > Propriedades.
3. Ir a Projetos de Inicialização.
4. Selecionar Vários projetos de inicialização.
5. Definir:
   - `NetLearnBattle.Server` = Iniciar
   - `NetLearnBattle.Client` = Iniciar
   - `NetLearnBattle.Shared` = Nenhuma
6. Carregar em F5.
7. No servidor, clicar em `Iniciar sessão`.
8. No cliente, usar:
   - IP: `127.0.0.1`
   - Porta: `5000`
9. Criar conta, fazer login e jogar.

## Ficheiros JSON

Os ficheiros são criados automaticamente na pasta `data` da aplicação:

- `users.json`
- `scores.json`
- `attempts.json`
- `acls.json`

## Comunicação

A comunicação Cliente/Servidor usa TCP com mensagens JSON, incluindo:

- `REGISTER_REQUEST`
- `AUTH_REQUEST`
- `QUESTION_REQUEST`
- `TRAINING_REQUEST`
- `ANSWER_SUBMIT`
- `RANKING_REQUEST`
- `STATS_REQUEST`

## Nota

O projeto foi preparado para WinForms em `.NET 8.0-windows`. No Visual Studio, instala o workload **Desenvolvimento para ambiente de trabalho .NET**.
