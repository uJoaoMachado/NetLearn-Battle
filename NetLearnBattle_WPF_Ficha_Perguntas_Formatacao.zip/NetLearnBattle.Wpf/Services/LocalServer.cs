using System.Net;
using System.Net.Sockets;
using System.Text;
namespace NetLearnBattle.Wpf.Services;
public sealed class LocalServer
{
    private TcpListener? _tcp;
    private UdpClient? _udp;
    private CancellationTokenSource? _cts;
    public bool IsRunning => _cts is not null;
    public event Action<string>? Log;
    public void Start(int tcpPort, int udpPort)
    {
        if (IsRunning) return;
        _cts = new CancellationTokenSource();
        _tcp = new TcpListener(IPAddress.Any, tcpPort); _tcp.Start();
        _udp = new UdpClient(udpPort);
        Log?.Invoke($"Servidor iniciado | TCP {tcpPort} | UDP {udpPort}");
        _ = Task.Run(() => TcpLoop(_cts.Token));
        _ = Task.Run(() => UdpLoop(_cts.Token));
    }
    public void Stop()
    {
        _cts?.Cancel(); _cts=null; _tcp?.Stop(); _udp?.Close();
        Log?.Invoke("Servidor parado.");
    }
    private async Task TcpLoop(CancellationToken ct)
    {
        while(!ct.IsCancellationRequested && _tcp is not null)
        {
            try { var client = await _tcp.AcceptTcpClientAsync(ct); _ = Task.Run(async()=>{
                using var s = client.GetStream(); var msg = Encoding.UTF8.GetBytes("NETLEARN_OK\n"); await s.WriteAsync(msg, ct); Log?.Invoke("Cliente TCP ligado."); }); }
            catch { if(!ct.IsCancellationRequested) Log?.Invoke("Erro TCP controlado."); }
        }
    }
    private async Task UdpLoop(CancellationToken ct)
    {
        while(!ct.IsCancellationRequested && _udp is not null)
        {
            try { var res = await _udp.ReceiveAsync(ct); var data = Encoding.UTF8.GetBytes("NETLEARN_UDP_OK"); await _udp.SendAsync(data, res.RemoteEndPoint, ct); Log?.Invoke("Pedido UDP recebido."); }
            catch { if(!ct.IsCancellationRequested) Log?.Invoke("Erro UDP controlado."); }
        }
    }
}
