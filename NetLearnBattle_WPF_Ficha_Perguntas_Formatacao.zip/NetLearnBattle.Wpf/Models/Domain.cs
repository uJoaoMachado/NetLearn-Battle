namespace NetLearnBattle.Wpf.Models;

public enum Role { Guest, Student, Teacher }
public enum AppLanguage { PT, EN, ES, FR, DE }
public enum ProtocolMode { TCP, UDP }

public sealed class User
{
    public string Username { get; set; } = "";
    public string PasswordHash { get; set; } = "";
    public Role Role { get; set; } = Role.Student;
    public DateTime CreatedAt { get; set; } = DateTime.Now;
}

public sealed class ScoreEntry
{
    public string Username { get; set; } = "";
    public int Score { get; set; }
    public int Correct { get; set; }
    public int Total { get; set; }
    public DateTime Date { get; set; } = DateTime.Now;
}

public sealed class Attempt
{
    public string Username { get; set; } = "";
    public int Level { get; set; }
    public string Question { get; set; } = "";
    public string Answer { get; set; } = "";
    public bool Correct { get; set; }
    public int DurationSeconds { get; set; }
    public DateTime Date { get; set; } = DateTime.Now;
}

public sealed class Question
{
    public string Text { get; set; } = "";
    public List<string> Options { get; set; } = new();
    public int CorrectIndex { get; set; }
    public int Level { get; set; }
    public int PointsCorrect { get; set; }
    public int PointsWrong { get; set; }
    public string Explanation { get; set; } = "";
}

public sealed class AppSettings
{
    public AppLanguage Language { get; set; } = AppLanguage.PT;
    public string Background { get; set; } = "#07061A";
    public string Card { get; set; } = "#12103A";
    public string Button { get; set; } = "#7C3AED";
    public string Accent { get; set; } = "#06B6D4";
    public double FontSize { get; set; } = 15;
}
