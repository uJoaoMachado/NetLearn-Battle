# NetLearn Battle — WPF

Projeto em C# / WPF para o jogo educativo NetLearn Battle.

## Como executar

1. Abrir `NetLearnBattle.Wpf.sln` no Visual Studio 2022.
2. Garantir que tem .NET 8 Desktop Development instalado.
3. Executar o projeto `NetLearnBattle.Wpf`.

## Login

Professor:

```txt
professor / professor
```

Aluno:

- Criar conta no ecrã inicial.

Guest:

- Botão **Entrar como Guest**.
- Apenas pode ver **Ranking Top 5** e **Regras**.

## Servidor

Para ligar o servidor:

1. Entrar como professor.
2. O programa abre automaticamente o painel **Servidor / Professor**.
3. Definir portas TCP/UDP, por exemplo:

```txt
TCP: 5000
UDP: 5001
```

4. Clicar em **Iniciar servidor TCP/UDP**.
5. O estado aparece na barra lateral.

No ecrã inicial, o aluno pode testar a ligação com:

```txt
IP: 127.0.0.1
Porta TCP: 5000
Porta UDP: 5001
```

Se for noutro computador, usar o IP do computador do professor na mesma rede.

## Idiomas

Em Configurações existem 5 idiomas:

- Português
- English
- Español
- Français
- Deutsch

A mudança de idioma atualiza a interface, menus, botões, mensagens, regras, professor, login e estatísticas.

## Cores

As cores usam o formato:

```txt
#RRGGBB
```

Exemplo:

```txt
#7C3AED
```

Se uma cor estiver inválida, a aplicação mostra erro e não fecha.
