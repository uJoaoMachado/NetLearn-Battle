namespace NetLearnBattle.Wpf;
public partial class App { }
