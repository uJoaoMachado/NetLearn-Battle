using System.IO;
using System.Security.Cryptography;
using System.Text;
using System.Text.Json;
using NetLearnBattle.Wpf.Models;

namespace NetLearnBattle.Wpf.Services;

public sealed class JsonStore
{
    private readonly string _dataDir = Path.Combine(AppContext.BaseDirectory, "Data");
    private readonly JsonSerializerOptions _json = new() { WriteIndented = true };
    public JsonStore()
    {
        Directory.CreateDirectory(_dataDir);
        Ensure("users.json", new List<User> { new() { Username="professor", PasswordHash = Hash("professor"), Role=Role.Teacher }});
        Ensure("scores.json", new List<ScoreEntry>());
        Ensure("attempts.json", new List<Attempt>());
        Ensure("acls.json", new List<object>());
        Ensure("appsettings.json", new AppSettings());
    }
    private string PathOf(string file) => Path.Combine(_dataDir, file);
    private void Ensure<T>(string f, T data){ if(!File.Exists(PathOf(f))) File.WriteAllText(PathOf(f), JsonSerializer.Serialize(data,_json)); }
    public T Read<T>(string file, T fallback){ try { return JsonSerializer.Deserialize<T>(File.ReadAllText(PathOf(file))) ?? fallback; } catch { return fallback; } }
    public void Write<T>(string file, T data) => File.WriteAllText(PathOf(file), JsonSerializer.Serialize(data,_json));
    public List<User> Users { get => Read("users.json", new List<User>()); set => Write("users.json", value); }
    public List<ScoreEntry> Scores { get => Read("scores.json", new List<ScoreEntry>()); set => Write("scores.json", value); }
    public List<Attempt> Attempts { get => Read("attempts.json", new List<Attempt>()); set => Write("attempts.json", value); }
    public AppSettings Settings { get => Read("appsettings.json", new AppSettings()); set => Write("appsettings.json", value); }
    public static string Hash(string text)
    {
        using var sha = SHA256.Create();
        return Convert.ToHexString(sha.ComputeHash(Encoding.UTF8.GetBytes("netlearn-salt:" + text)));
    }
}
