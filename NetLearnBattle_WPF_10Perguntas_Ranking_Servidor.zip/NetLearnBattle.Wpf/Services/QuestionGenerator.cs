using NetLearnBattle.Wpf.Models;

namespace NetLearnBattle.Wpf.Services;

public sealed class QuestionGenerator
{
    private readonly Random _r = new();

    public Question Next(int level)
    {
        var list = level switch
        {
            1 => Level1(),
            2 => Level2(),
            3 => Level3(),
            4 => Level4(),
            _ => Level5()
        };
        return list[_r.Next(list.Count)];
    }

    public List<Question> GenerateSet(int level, int count = 10)
    {
        var result = new List<Question>();
        for (int i = 0; i < count; i++)
            result.Add(Next(level));
        return result.OrderBy(_ => _r.Next()).ToList();
    }

    public static (int Correct, int Wrong) PointsForLevel(int level) => level switch
    {
        1 => (10, -5),
        2 => (20, -10),
        3 => (30, -15),
        4 => (40, -20),
        _ => (50, -25)
    };

    private List<Question> Level1()
    {
        int third = _r.Next(1, 220);
        int host = _r.Next(10, 240);
        return new()
        {
            Make($"Qual é o Network ID de 192.168.{third}.{host}/24?", new[] {$"192.168.{third}.0", $"192.168.{third}.255", "192.168.0.0", $"192.168.{host}.0"}, 0, 1, "Em /24, os três primeiros octetos identificam a rede."),
            Make($"Qual é o Broadcast de 10.{third}.0.{host}/16?", new[] {$"10.{third}.255.255", $"10.{third}.0.255", "10.255.255.255", $"10.{third}.0.0"}, 0, 1, "Em /16, os dois primeiros octetos são da rede e o broadcast termina em 255.255."),
            Make("Dois endereços 172.16.1.10/24 e 172.16.1.200/24 estão no mesmo segmento?", new[] {"Sim", "Não", "Só em IPv6", "Depende da porta"}, 0, 1, "Com /24, ambos pertencem à rede 172.16.1.0.")
        };
    }

    private List<Question> Level2() => new()
    {
        Make("Para uma rede /26, quantos endereços existem por sub-rede?", new[]{"32","64","128","256"}, 1, 2, "/26 deixa 6 bits para endereços: 2^6 = 64."),
        Make("Qual é o incremento de bloco numa sub-rede /27?", new[]{"8","16","32","64"}, 2, 2, "/27 deixa blocos de 32 endereços no último octeto."),
        Make("192.168.1.70/26 pertence a que sub-rede?", new[]{"192.168.1.0","192.168.1.64","192.168.1.96","192.168.1.128"}, 1, 2, "Em /26 os blocos são 0, 64, 128 e 192.")
    };

    private List<Question> Level3() => new()
    {
        Make("Qual prefixo sumariza quatro redes /24 consecutivas?", new[]{"/22","/23","/25","/30"}, 0, 3, "Quatro redes /24 consecutivas são agregadas num /22."),
        Make("Que sumarização cobre 10.0.0.0/24 até 10.0.3.0/24?", new[]{"10.0.0.0/22","10.0.0.0/23","10.0.0.0/21","10.0.3.0/24"}, 0, 3, "As quatro redes /24 formam 10.0.0.0/22."),
        Make("Uma super-rede /21 contém quantas redes /24?", new[]{"2","4","8","16"}, 2, 3, "A diferença 24 - 21 = 3 bits, logo 2^3 = 8 redes /24.")
    };

    private List<Question> Level4() => new()
    {
        Make("Em IPv6, qual é o tamanho normal do prefixo de uma LAN?", new[]{"/32","/48","/64","/128"}, 2, 4, "Em IPv6, uma LAN usa tipicamente /64."),
        Make("Em IPv6, qual endereço representa loopback?", new[]{"::1","::","fe80::1","ff02::1"}, 0, 4, "::1 é o endereço de loopback IPv6."),
        Make("O prefixo fe80::/10 é usado para quê?", new[]{"Link-local","Multicast","Loopback","Broadcast"}, 0, 4, "Endereços fe80::/10 são link-local.")
    };

    private List<Question> Level5() => new()
    {
        Make("Numa ACL, a regra 'deny tcp any any eq 80' faz o quê?", new[]{"Permite HTTP","Bloqueia HTTP TCP","Bloqueia ICMP","Permite DNS"}, 1, 5, "A regra nega tráfego TCP com porta 80."),
        Make("Qual regra permite HTTPS de qualquer origem para qualquer destino?", new[]{"permit tcp any any eq 443","deny tcp any any eq 443","permit udp any any eq 443","permit icmp any any"}, 0, 5, "HTTPS usa normalmente TCP porta 443."),
        Make("Numa ACL, a ordem das regras importa?", new[]{"Sim, a primeira correspondência aplica-se","Não, todas são somadas","Só em UDP","Só em IPv6"}, 0, 5, "As ACLs são avaliadas por ordem até encontrar uma regra compatível.")
    };

    private static Question Make(string text, IEnumerable<string> options, int correct, int level, string explanation)
    {
        var pts = PointsForLevel(level);
        return new Question
        {
            Text = text,
            Options = options.ToList(),
            CorrectIndex = correct,
            Level = level,
            PointsCorrect = pts.Correct,
            PointsWrong = pts.Wrong,
            Explanation = explanation
        };
    }
}
