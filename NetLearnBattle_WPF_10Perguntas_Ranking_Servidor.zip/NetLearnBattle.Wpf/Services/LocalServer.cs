using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Text.Json;
using NetLearnBattle.Wpf.Models;

namespace NetLearnBattle.Wpf.Services;

public sealed class LocalServer
{
    private TcpListener? _tcp;
    private UdpClient? _udp;
    private CancellationTokenSource? _cts;
    private readonly JsonStore _store = new();
    private readonly JsonSerializerOptions _json = new() { WriteIndented = true };

    public bool IsRunning => _cts is not null;
    public event Action<string>? Log;
    public event Action? DataChanged;

    public void Start(int tcpPort, int udpPort)
    {
        if (IsRunning) return;
        _cts = new CancellationTokenSource();
        _tcp = new TcpListener(IPAddress.Any, tcpPort);
        _tcp.Start();
        _udp = new UdpClient(udpPort);
        Log?.Invoke($"Servidor iniciado | TCP {tcpPort} | UDP {udpPort}");
        _ = Task.Run(() => TcpLoop(_cts.Token));
        _ = Task.Run(() => UdpLoop(_cts.Token));
    }

    public void Stop()
    {
        _cts?.Cancel();
        _cts = null;
        try { _tcp?.Stop(); } catch { }
        try { _udp?.Close(); } catch { }
        Log?.Invoke("Servidor parado.");
    }

    private async Task TcpLoop(CancellationToken ct)
    {
        while (!ct.IsCancellationRequested && _tcp is not null)
        {
            try
            {
                var client = await _tcp.AcceptTcpClientAsync(ct);
                _ = Task.Run(async () =>
                {
                    using var c = client;
                    using var s = c.GetStream();
                    using var reader = new StreamReader(s, Encoding.UTF8, leaveOpen: true);
                    using var writer = new StreamWriter(s, Encoding.UTF8, leaveOpen: true) { AutoFlush = true };
                    var line = await reader.ReadLineAsync(ct) ?? "PING";
                    var response = HandleMessage(line, c.Client.RemoteEndPoint?.ToString() ?? "TCP");
                    await writer.WriteLineAsync(response.AsMemory(), ct);
                }, ct);
            }
            catch { if (!ct.IsCancellationRequested) Log?.Invoke("Erro TCP controlado."); }
        }
    }

    private async Task UdpLoop(CancellationToken ct)
    {
        while (!ct.IsCancellationRequested && _udp is not null)
        {
            try
            {
                var res = await _udp.ReceiveAsync(ct);
                var line = Encoding.UTF8.GetString(res.Buffer);
                var response = HandleMessage(line, res.RemoteEndPoint.ToString());
                var data = Encoding.UTF8.GetBytes(response);
                await _udp.SendAsync(data, res.RemoteEndPoint, ct);
            }
            catch { if (!ct.IsCancellationRequested) Log?.Invoke("Erro UDP controlado."); }
        }
    }

    private string HandleMessage(string raw, string endpoint)
    {
        try
        {
            var line = (raw ?? string.Empty).Trim();
            if (string.IsNullOrWhiteSpace(line) || line.Equals("PING", StringComparison.OrdinalIgnoreCase))
            {
                Log?.Invoke($"Teste de ligação recebido de {endpoint}.");
                return "NETLEARN_OK";
            }

            if (line.StartsWith("SUBMIT\t", StringComparison.OrdinalIgnoreCase))
            {
                var payload = line[7..];
                var json = Encoding.UTF8.GetString(Convert.FromBase64String(payload));
                var dto = JsonSerializer.Deserialize<NetworkAttemptDto>(json);
                if (dto is null || string.IsNullOrWhiteSpace(dto.Username)) return "ERROR Invalid submit";

                var attempts = _store.Attempts;
                attempts.Add(new Attempt
                {
                    Username = dto.Username,
                    Level = dto.Level,
                    Question = dto.Question,
                    Answer = dto.Answer,
                    Correct = dto.Correct,
                    DurationSeconds = dto.DurationSeconds,
                    Date = dto.Date
                });
                _store.Attempts = attempts;

                var scores = _store.Scores;
                scores.Add(new ScoreEntry
                {
                    Username = dto.Username,
                    Score = dto.Score,
                    Correct = dto.Correct ? 1 : 0,
                    Total = 1,
                    Date = dto.Date
                });
                _store.Scores = scores;

                Log?.Invoke($"Resposta recebida: {dto.Username} | Nível {dto.Level} | {(dto.Correct ? "certa" : "errada")} | {dto.Score} pts");
                DataChanged?.Invoke();
                return "OK SUBMITTED";
            }

            if (line.Equals("RANKING", StringComparison.OrdinalIgnoreCase))
            {
                var ranking = _store.Scores
                    .GroupBy(s => s.Username)
                    .Select(g => new RankingDto { Username = g.Key, Score = g.Sum(x => x.Score), Total = g.Sum(x => x.Total), Correct = g.Sum(x => x.Correct) })
                    .OrderByDescending(x => x.Score)
                    .Take(5)
                    .ToList();
                Log?.Invoke($"Ranking enviado para {endpoint}.");
                return "RANKING\t" + Convert.ToBase64String(Encoding.UTF8.GetBytes(JsonSerializer.Serialize(ranking, _json)));
            }

            return "ERROR Unknown command";
        }
        catch (Exception ex)
        {
            Log?.Invoke("Erro ao processar mensagem: " + ex.Message);
            return "ERROR " + ex.Message;
        }
    }
}
