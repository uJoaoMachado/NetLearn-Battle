# Revisão completa — servidor, permissões e idiomas

Alterações aplicadas nesta versão:

- O professor, ao iniciar sessão com `professor / professor`, é enviado diretamente para o painel **Servidor / Professor**.
- O botão lateral foi renomeado para **Servidor/Professor**, para ficar claro onde se inicia o servidor.
- O painel do professor explica como iniciar TCP/UDP e como o aluno deve ligar.
- Estado do servidor aparece na barra lateral.
- Guest continua limitado a **Ranking Top 5** e **Regras**, conforme a ficha.
- Aluno autenticado pode jogar e consultar estatísticas.
- Professor pode iniciar/parar servidor e ver relatórios.
- Configurações agora têm 5 idiomas: Português, English, Español, Français e Deutsch.
- A troca de idioma atualiza menus, botões, títulos, mensagens, regras, painel professor, login, estatísticas e configurações.
- Cores personalizadas continuam validadas com `#RRGGBB`, sem fechar a aplicação quando há erro.

Credenciais do professor:

```txt
professor / professor
```

Fluxo recomendado:

1. Abrir a app.
2. Entrar como professor.
3. Abrir/iniciar o servidor TCP/UDP no painel **Servidor / Professor**.
4. Noutro cliente, usar IP `127.0.0.1` no mesmo PC ou o IP do professor na rede.
5. Testar ligação no ecrã de entrada.
6. Entrar como aluno ou registar aluno.
