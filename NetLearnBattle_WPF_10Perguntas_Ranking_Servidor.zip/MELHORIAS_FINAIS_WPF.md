# Melhorias finais WPF

Esta versão junta a versão WPF moderna com correções de estabilidade e melhorias visuais.

## Corrigido

- A app já não fecha ao mudar cores inválidas.
- Todas as cores são validadas antes de aplicar.
- Se uma cor inválida estiver no ficheiro JSON, é substituída por uma cor segura.
- A área de configurações foi refeita com temas rápidos, amostras de cor e pré-visualização.
- A interface do professor/servidor foi melhorada com estado visual, portas TCP/UDP, logs e estatísticas.
- O ecrã inicial agora tem teste de ligação TCP/UDP ao servidor.

## Como usar o servidor

1. Entrar com `professor / professor`.
2. Abrir `Professor`.
3. Clicar em `Iniciar servidor TCP/UDP`.
4. Voltar ao ecrã inicial ou abrir outro cliente.
5. Testar ligação com `127.0.0.1` e porta `5000` para TCP, ou `5001` para UDP.

## Configurações

- Idioma: PT, EN, ES.
- Temas rápidos.
- Cores avançadas em formato `#RRGGBB`.
- Tamanho do texto.
- Guardado automaticamente no ficheiro JSON de definições.
