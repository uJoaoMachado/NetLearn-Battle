using System.IO;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Text.Json;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using NetLearnBattle.Wpf.Models;
using NetLearnBattle.Wpf.Services;

namespace NetLearnBattle.Wpf;

public partial class MainWindow : Window
{
    private readonly JsonStore _store = new();
    private readonly QuestionGenerator _questions = new();
    private readonly LocalServer _server = new();
    private User? _current;
    private Question? _currentQuestion;
    private Queue<Question> _sessionQuestions = new();
    private int _sessionLevel;
    private int _sessionIndex;
    private int _sessionScore;
    private DateTime _questionStart;
    private AppSettings _settings;
    private ListBox? _serverLog;
    private string _connectedHost = "127.0.0.1";
    private int _connectedPort = 5000;
    private ProtocolMode _connectedProtocol = ProtocolMode.TCP;
    private bool _connectionOk;
    private int _lastTcpPort = 5000;
    private int _lastUdpPort = 5001;

    private readonly Dictionary<string, (string Bg, string Card, string Button, string Accent)> _themes = new()
    {
        ["Roxo moderno"] = ("#07061A", "#12103A", "#7C3AED", "#06B6D4"),
        ["Azul profissional"] = ("#071827", "#0F2A3D", "#2563EB", "#38BDF8"),
        ["Verde técnico"] = ("#04110B", "#0B2317", "#16A34A", "#22C55E"),
        ["Claro limpo"] = ("#F4F7FB", "#FFFFFF", "#2563EB", "#0891B2"),
        ["Preto neon"] = ("#050505", "#151515", "#E11D48", "#A3E635")
    };

    public MainWindow()
    {
        InitializeComponent();
        _settings = SanitizeSettings(_store.Settings);
        _store.Settings = _settings;
        _server.Log += msg => Dispatcher.Invoke(() => _serverLog?.Items.Insert(0, $"{DateTime.Now:HH:mm:ss}  {msg}"));
        _server.DataChanged += () => Dispatcher.Invoke(() => { if (_current?.Role == Role.Teacher) ApplySettings(); });
        ApplySettings();
        ShowLogin();
    }

    private string T(string pt, string en, string es, string fr = "", string de = "") => _settings.Language switch
    {
        AppLanguage.EN => en,
        AppLanguage.ES => es,
        AppLanguage.FR => string.IsNullOrWhiteSpace(fr) ? en : fr,
        AppLanguage.DE => string.IsNullOrWhiteSpace(de) ? en : de,
        _ => pt
    };

    private string RoleText(Role role) => role switch
    {
        Role.Student => T("Aluno", "Student", "Alumno", "Élève", "Schüler"),
        Role.Teacher => T("Professor", "Teacher", "Profesor", "Professeur", "Lehrer"),
        _ => "Guest"
    };

    private string LevelName(int i) => i switch
    {
        1 => T("IPv4 básico", "Basic IPv4", "IPv4 básico", "IPv4 de base", "IPv4 Grundlagen"),
        2 => T("Sub-redes IPv4", "IPv4 subnetting", "Subredes IPv4", "Sous-réseaux IPv4", "IPv4 Subnetting"),
        3 => T("Sumarização IPv4", "IPv4 summarization", "Sumarización IPv4", "Résumé IPv4", "IPv4 Zusammenfassung"),
        4 => "IPv6",
        _ => "ACLs"
    };

    private static bool IsValidHex(string? value)
    {
        if (string.IsNullOrWhiteSpace(value)) return false;
        value = value.Trim();
        if (!value.StartsWith("#")) return false;
        if (value.Length != 7 && value.Length != 9) return false;
        return value.Skip(1).All(c => char.IsDigit(c) || "abcdefABCDEF".Contains(c));
    }
    private static string SafeHex(string? value, string fallback) => IsValidHex(value) ? value!.Trim() : fallback;
    private static Brush SafeBrush(string? hex, string fallback = "#12103A")
    {
        try { return (Brush)new BrushConverter().ConvertFromString(SafeHex(hex, fallback))!; }
        catch { return (Brush)new BrushConverter().ConvertFromString(fallback)!; }
    }
    private static AppSettings SanitizeSettings(AppSettings s)
    {
        s.Background = SafeHex(s.Background, "#07061A");
        s.Card = SafeHex(s.Card, "#12103A");
        s.Button = SafeHex(s.Button, "#7C3AED");
        s.Accent = SafeHex(s.Accent, "#06B6D4");
        if (s.FontSize < 12 || s.FontSize > 24) s.FontSize = 15;
        return s;
    }
    private static string Blend(string a, string b, double amount)
    {
        try
        {
            var ca = (Color)ColorConverter.ConvertFromString(SafeHex(a, "#000000"));
            var cb = (Color)ColorConverter.ConvertFromString(SafeHex(b, "#FFFFFF"));
            byte r = (byte)(ca.R + (cb.R - ca.R) * amount);
            byte g = (byte)(ca.G + (cb.G - ca.G) * amount);
            byte bl = (byte)(ca.B + (cb.B - ca.B) * amount);
            return $"#{r:X2}{g:X2}{bl:X2}";
        }
        catch { return "#221C55"; }
    }

    private TextBlock Txt(string text, double size = 16, FontWeight? weight = null, string color = "#EDE9FF") => new()
    {
        Text = text,
        FontSize = size,
        FontWeight = weight ?? FontWeights.Normal,
        Foreground = SafeBrush(color, "#EDE9FF"),
        TextWrapping = TextWrapping.Wrap,
        Margin = new Thickness(0, 0, 0, 8)
    };
    private Border Card(UIElement child, Thickness? margin = null) => new()
    {
        Child = child,
        Style = (Style)FindResource("Card"),
        Margin = margin ?? new Thickness(0, 0, 0, 18),
        Background = SafeBrush(_settings.Card, "#12103A"),
        BorderBrush = SafeBrush(Blend(_settings.Accent, _settings.Card, 0.35), "#337C3AED")
    };
    private Button Btn(string text, RoutedEventHandler click, bool primary = true)
    {
        var b = new Button { Content = text, Style = (Style)FindResource(primary ? "PrimaryButton" : "GhostButton"), Margin = new Thickness(0, 8, 0, 0), MinHeight = 46 };
        b.Click += click;
        b.Background = primary ? SafeBrush(_settings.Button, "#7C3AED") : SafeBrush(Blend(_settings.Card, _settings.Button, 0.24), "#221C55");
        b.Foreground = Brushes.White;
        return b;
    }
    private TextBox Input(string value = "") => new() { Text = value, Margin = new Thickness(0, 4, 0, 12) };
    private void Clear() => ViewHost.Children.Clear();

    private void ApplySettings()
    {
        _settings = SanitizeSettings(_settings);
        Root.Background = SafeBrush(_settings.Background, "#07061A");
        Sidebar.Background = SafeBrush(Blend(_settings.Background, "#000000", 0.40), "#0D0B26");
        FontSize = _settings.FontSize;
        BtnHome.Content = "🏠 " + T("Início", "Home", "Inicio", "Accueil", "Start");
        BtnGame.Content = "🎮 " + T("Jogar", "Play", "Jugar", "Jouer", "Spielen");
        BtnRanking.Content = "🏆 " + T("Ranking", "Ranking", "Ranking", "Classement", "Rangliste");
        BtnRules.Content = "📘 " + T("Regras", "Rules", "Reglas", "Règles", "Regeln");
        BtnStats.Content = "📊 " + T("Estatísticas", "Statistics", "Estadísticas", "Statistiques", "Statistiken");
        BtnTeacher.Content = "🧑‍🏫 " + T("Servidor/Professor", "Server/Teacher", "Servidor/Profesor", "Serveur/Professeur", "Server/Lehrer");
        BtnSettings.Content = "⚙ " + T("Configurações", "Settings", "Configuración", "Paramètres", "Einstellungen");
        ConnectionBadge.Text = _server.IsRunning
            ? T($"Servidor local ativo: TCP {_lastTcpPort} · UDP {_lastUdpPort}", $"Local server running: TCP {_lastTcpPort} · UDP {_lastUdpPort}", $"Servidor local activo: TCP {_lastTcpPort} · UDP {_lastUdpPort}", $"Serveur local actif : TCP {_lastTcpPort} · UDP {_lastUdpPort}", $"Lokaler Server aktiv: TCP {_lastTcpPort} · UDP {_lastUdpPort}")
            : (_connectionOk ? T($"Ligado: {_connectedProtocol} {_connectedHost}:{_connectedPort}", $"Connected: {_connectedProtocol} {_connectedHost}:{_connectedPort}", $"Conectado: {_connectedProtocol} {_connectedHost}:{_connectedPort}", $"Connecté : {_connectedProtocol} {_connectedHost}:{_connectedPort}", $"Verbunden: {_connectedProtocol} {_connectedHost}:{_connectedPort}") : T("Servidor: não ligado", "Server: not connected", "Servidor: no conectado", "Serveur : non connecté", "Server: nicht verbunden"));
        ConnectionBadge.Foreground = (_connectionOk || _server.IsRunning) ? SafeBrush("#86EFAC", "#86EFAC") : SafeBrush("#9A94C7", "#9A94C7");
        UpdateNavigationAccess();
    }

    private void UpdateNavigationAccess()
    {
        var role = _current?.Role ?? Role.Guest;
        var loggedIn = _current is not null && role != Role.Guest;
        BtnHome.IsEnabled = true;
        BtnRanking.IsEnabled = true;
        BtnRules.IsEnabled = true;
        BtnGame.IsEnabled = loggedIn && role == Role.Student;
        BtnStats.IsEnabled = loggedIn && role == Role.Student;
        BtnTeacher.IsEnabled = loggedIn && role == Role.Teacher;
        BtnSettings.IsEnabled = loggedIn;
        foreach (var b in new[] { BtnGame, BtnStats, BtnTeacher, BtnSettings }) b.Opacity = b.IsEnabled ? 1 : 0.35;
    }

    private void ShowLogin()
    {
        Clear();
        _current = null;
        UserBadge.Text = T("Sem sessão", "No session", "Sin sesión", "Sans session", "Keine Sitzung");
        ApplySettings();

        var grid = new Grid();
        grid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
        grid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });

        var left = new StackPanel { Margin = new Thickness(0, 0, 28, 0) };
        left.Children.Add(Txt("NetLearn Battle", 46, FontWeights.Black));
        left.Children.Add(Txt(T("Jogo educativo de redes com IPv4, IPv6, ACLs, ranking e comunicação TCP/UDP.", "Educational networking game with IPv4, IPv6, ACLs, ranking and TCP/UDP communication.", "Juego educativo de redes con IPv4, IPv6, ACLs, ranking y comunicación TCP/UDP.", "Jeu éducatif de réseaux avec IPv4, IPv6, ACL, classement et communication TCP/UDP.", "Lernspiel zu Netzwerken mit IPv4, IPv6, ACLs, Rangliste und TCP/UDP-Kommunikation."), 18, FontWeights.SemiBold, "#9A94C7"));
        left.Children.Add(Card(new StackPanel { Children = { Txt("🎯 " + T("Regras da ficha", "Assignment rules", "Reglas de la ficha", "Règles du sujet", "Aufgabenregeln"), 22, FontWeights.Bold), Txt(T("Guest só vê Ranking Top 5 e Regras. Aluno autenticado joga e vê estatísticas. Professor inicia o servidor.", "Guest only sees Top 5 Ranking and Rules. Authenticated students play and see statistics. Teacher starts the server.", "Guest solo ve Ranking Top 5 y Reglas. El alumno autenticado juega y ve estadísticas. El profesor inicia el servidor.", "Guest voit seulement le Top 5 et les règles. L'élève connecté joue et voit les statistiques. Le professeur démarre le serveur.", "Guest sieht nur Top-5-Rangliste und Regeln. Angemeldete Schüler spielen und sehen Statistiken. Lehrer starten den Server."), 15, null, "#9A94C7") } }, new Thickness(0, 22, 0, 14)));
        left.Children.Add(Card(new StackPanel { Children = { Txt("🌐 " + T("Servidor obrigatório no modo rede", "Server required for network mode", "Servidor obligatorio en modo red", "Serveur requis en mode réseau", "Server für Netzwerkmodus erforderlich"), 22, FontWeights.Bold), Txt(T("Entra como professor para abrir o painel Servidor/Professor e iniciar TCP/UDP. No ecrã de entrada podes testar a ligação.", "Sign in as teacher to open Server/Teacher and start TCP/UDP. On this screen you can test the connection.", "Entra como profesor para abrir Servidor/Profesor e iniciar TCP/UDP. En esta pantalla puedes probar la conexión.", "Connecte-toi comme professeur pour ouvrir Serveur/Professeur et démarrer TCP/UDP. Tu peux tester la connexion ici.", "Melde dich als Lehrer an, um Server/Lehrer zu öffnen und TCP/UDP zu starten. Hier kannst du die Verbindung testen."), 15, null, "#9A94C7") } }));
        Grid.SetColumn(left, 0); grid.Children.Add(left);

        var form = new StackPanel();
        form.Children.Add(Txt(T("Entrar / Registar", "Sign in / Register", "Entrar / Registrar", "Connexion / Inscription", "Anmelden / Registrieren"), 32, FontWeights.Black));

        var host = Input(_connectedHost);
        var port = Input(_connectedPort.ToString());
        var protocol = new ComboBox { Height = 42, Margin = new Thickness(0, 4, 0, 12), ItemsSource = Enum.GetValues(typeof(ProtocolMode)), SelectedItem = _connectedProtocol };
        var connectionMsg = Txt(_connectionOk ? T("Ligação validada.", "Connection validated.", "Conexión validada.", "Connexion validée.", "Verbindung geprüft.") : T("Testa a ligação ao servidor do professor antes de jogar em rede.", "Test the teacher server connection before network play.", "Prueba la conexión al servidor del profesor antes de jugar en red.", "Teste la connexion au serveur du professeur avant le jeu réseau.", "Teste die Verbindung zum Lehrer-Server vor dem Netzwerkspiel."), 13, FontWeights.Bold, _connectionOk ? "#86EFAC" : "#9A94C7");
        form.Children.Add(Card(new StackPanel { Children = { Txt("🔌 " + T("Ligação ao servidor", "Server connection", "Conexión al servidor", "Connexion au serveur", "Serververbindung"), 20, FontWeights.Black), Txt("IP / Host", 13, FontWeights.Bold, "#9A94C7"), host, Txt(T("Porta", "Port", "Puerto", "Port", "Port"), 13, FontWeights.Bold, "#9A94C7"), port, Txt(T("Protocolo", "Protocol", "Protocolo", "Protocole", "Protokoll"), 13, FontWeights.Bold, "#9A94C7"), protocol, Btn(T("Testar ligação", "Test connection", "Probar conexión", "Tester la connexion", "Verbindung testen"), async (_, __) => await TestConnectionAsync(host.Text, port.Text, (ProtocolMode)protocol.SelectedItem, connectionMsg), false), connectionMsg } }, new Thickness(0, 8, 0, 18)));

        var username = Input("");
        var password = new PasswordBox { Margin = new Thickness(0, 4, 0, 12) };
        var msg = Txt("", 14, FontWeights.Bold, "#FCA5A5");
        form.Children.Add(Txt(T("Utilizador", "Username", "Usuario", "Utilisateur", "Benutzer"), 14, FontWeights.Bold, "#9A94C7")); form.Children.Add(username);
        form.Children.Add(Txt(T("Palavra-passe", "Password", "Contraseña", "Mot de passe", "Passwort"), 14, FontWeights.Bold, "#9A94C7")); form.Children.Add(password);
        form.Children.Add(Btn(T("Entrar", "Sign in", "Entrar", "Se connecter", "Anmelden"), (_, __) => DoLogin(username.Text, password.Password, msg)));
        form.Children.Add(Btn(T("Criar conta de aluno", "Create student account", "Crear cuenta de alumno", "Créer un compte élève", "Schülerkonto erstellen"), (_, __) => DoRegister(username.Text, password.Password, msg), false));
        form.Children.Add(Btn(T("Entrar como Guest", "Continue as Guest", "Entrar como invitado", "Continuer comme Guest", "Als Guest fortfahren"), (_, __) => { _current = new User { Username = "Guest", Role = Role.Guest }; UserBadge.Text = T("Guest · acesso limitado", "Guest · limited access", "Guest · acceso limitado", "Guest · accès limité", "Guest · eingeschränkter Zugriff"); ApplySettings(); ShowHome(); }, false));
        form.Children.Add(Txt(T("Professor: professor / professor", "Teacher: professor / professor", "Profesor: professor / professor", "Professeur : professor / professor", "Lehrer: professor / professor"), 13, FontWeights.Bold, "#9A94C7"));
        form.Children.Add(msg);
        Grid.SetColumn(form, 1); grid.Children.Add(Card(form));
        ViewHost.Children.Add(grid);
    }


    private string GetLocalIpAddress()
    {
        try
        {
            return Dns.GetHostEntry(Dns.GetHostName())
                .AddressList
                .FirstOrDefault(ip => ip.AddressFamily == AddressFamily.InterNetwork && !IPAddress.IsLoopback(ip))
                ?.ToString() ?? "127.0.0.1";
        }
        catch { return "127.0.0.1"; }
    }

    private async Task TestConnectionAsync(string host, string portText, ProtocolMode mode, TextBlock status)
    {
        if (!int.TryParse(portText, out var port) || port <= 0 || port > 65535)
        { status.Text = T("Porta inválida.", "Invalid port.", "Puerto inválido.", "Port invalide.", "Ungültiger Port."); status.Foreground = SafeBrush("#FCA5A5"); return; }
        try
        {
            if (mode == ProtocolMode.TCP)
            {
                using var tcp = new TcpClient();
                var connectTask = tcp.ConnectAsync(host.Trim(), port);
                if (await Task.WhenAny(connectTask, Task.Delay(1800)) != connectTask) throw new TimeoutException();
                if (!tcp.Connected) throw new SocketException();
                using var stream = tcp.GetStream();
                using var writer = new StreamWriter(stream, Encoding.UTF8, leaveOpen: true) { AutoFlush = true };
                using var reader = new StreamReader(stream, Encoding.UTF8, leaveOpen: true);
                await writer.WriteLineAsync("PING");
                var responseTask = reader.ReadLineAsync();
                if (await Task.WhenAny(responseTask, Task.Delay(1800)) != responseTask) throw new TimeoutException();
            }
            else
            {
                using var udp = new UdpClient();
                var data = Encoding.UTF8.GetBytes("PING");
                await udp.SendAsync(data, data.Length, host.Trim(), port);
                var receive = udp.ReceiveAsync();
                if (await Task.WhenAny(receive, Task.Delay(1800)) != receive) throw new TimeoutException();
            }
            _connectedHost = host.Trim(); _connectedPort = port; _connectedProtocol = mode; _connectionOk = true;
            status.Text = T("Ligação feita com sucesso.", "Connection successful.", "Conexión correcta.", "Connexion réussie.", "Verbindung erfolgreich.");
            status.Foreground = SafeBrush("#86EFAC");
        }
        catch
        {
            _connectionOk = false;
            status.Text = T("Não foi possível ligar. Confirma se o professor iniciou o servidor TCP/UDP.", "Could not connect. Check if the teacher started the TCP/UDP server.", "No fue posible conectar. Confirma si el profesor inició el servidor TCP/UDP.", "Connexion impossible. Vérifie que le professeur a démarré le serveur TCP/UDP.", "Verbindung nicht möglich. Prüfe, ob der Lehrer den TCP/UDP-Server gestartet hat.");
            status.Foreground = SafeBrush("#FCA5A5");
        }
        ApplySettings();
    }

    private void DoLogin(string name, string pass, TextBlock msg)
    {
        var u = _store.Users.FirstOrDefault(x => x.Username.Equals(name.Trim(), StringComparison.OrdinalIgnoreCase) && x.PasswordHash == JsonStore.Hash(pass));
        if (u is null) { msg.Text = T("Dados inválidos.", "Invalid credentials.", "Datos inválidos.", "Identifiants invalides.", "Ungültige Daten."); return; }
        _current = u; UserBadge.Text = $"{u.Username} · {RoleText(u.Role)}"; ApplySettings();
        if (u.Role == Role.Teacher) ShowTeacher(); else ShowHome();
    }

    private void DoRegister(string name, string pass, TextBlock msg)
    {
        name = name.Trim();
        if (string.IsNullOrWhiteSpace(name) || string.IsNullOrWhiteSpace(pass)) { msg.Text = T("Preenche utilizador e palavra-passe.", "Fill username and password.", "Completa usuario y contraseña.", "Remplis utilisateur et mot de passe.", "Benutzer und Passwort ausfüllen."); return; }
        var users = _store.Users;
        if (users.Any(x => x.Username.Equals(name, StringComparison.OrdinalIgnoreCase))) { msg.Text = T("Utilizador já existe.", "User already exists.", "Usuario ya existe.", "Utilisateur déjà existant.", "Benutzer existiert bereits."); return; }
        var nu = new User { Username = name, PasswordHash = JsonStore.Hash(pass), Role = Role.Student };
        users.Add(nu); _store.Users = users; _current = nu; UserBadge.Text = $"{nu.Username} · {RoleText(nu.Role)}"; ApplySettings(); ShowHome();
    }

    private void ShowHome()
    {
        Clear();
        if (_current is null) { ShowLogin(); return; }
        ViewHost.Children.Add(Txt($"{T("Bem-vindo", "Welcome", "Bienvenido", "Bienvenue", "Willkommen")}, {_current.Username} 👋", 38, FontWeights.Black));
        if (_current.Role == Role.Guest)
            ViewHost.Children.Add(Txt(T("Guest tem acesso limitado: apenas Ranking Top 5 e Regras do Jogo.", "Guest has limited access: only Top 5 Ranking and Game Rules.", "Guest tiene acceso limitado: solo Ranking Top 5 y Reglas.", "Guest a un accès limité : seulement Top 5 et règles.", "Guest hat eingeschränkten Zugriff: nur Top-5-Rangliste und Regeln."), 17, FontWeights.Bold, "#FDE68A"));
        else if (_current.Role == Role.Student)
            ViewHost.Children.Add(Txt(T("Aluno autenticado: podes jogar, ver histórico, score e estatísticas.", "Authenticated student: you can play, view history, score and statistics.", "Alumno autenticado: puedes jugar, ver historial, puntuación y estadísticas.", "Élève connecté : tu peux jouer, voir l'historique, le score et les statistiques.", "Angemeldeter Schüler: Du kannst spielen, Verlauf, Punkte und Statistiken sehen."), 17, null, "#9A94C7"));
        else
            ViewHost.Children.Add(Txt(T("Professor autenticado: inicia/parar servidor TCP/UDP e consulta relatórios.", "Authenticated teacher: start/stop TCP/UDP server and view reports.", "Profesor autenticado: inicia/para servidor TCP/UDP y consulta informes.", "Professeur connecté : démarrer/arrêter serveur TCP/UDP et voir rapports.", "Angemeldeter Lehrer: TCP/UDP-Server starten/stoppen und Berichte ansehen."), 17, null, "#9A94C7"));

        var wrap = new WrapPanel { Margin = new Thickness(0, 20, 0, 0) };
        void Tile(string title, string desc, string emoji, RoutedEventHandler click, bool primary=true)
        {
            var sp = new StackPanel { Width = 250 };
            sp.Children.Add(Txt(emoji, 34, FontWeights.Bold)); sp.Children.Add(Txt(title, 22, FontWeights.Black)); sp.Children.Add(Txt(desc, 14, null, "#9A94C7")); sp.Children.Add(Btn(T("Abrir", "Open", "Abrir", "Ouvrir", "Öffnen"), click, primary));
            wrap.Children.Add(Card(sp, new Thickness(0, 0, 18, 18)));
        }
        if (_current.Role == Role.Student)
        {
            Tile(T("Jogar", "Play", "Jugar", "Jouer", "Spielen"), T("Escolhe nível e responde a perguntas.", "Choose a level and answer questions.", "Elige nivel y responde preguntas.", "Choisis un niveau et réponds.", "Wähle ein Level und antworte."), "🎮", Game_Click);
            Tile(T("Estatísticas", "Statistics", "Estadísticas", "Statistiques", "Statistiken"), T("Histórico, score e taxa de acerto.", "History, score and accuracy.", "Historial, puntuación y acierto.", "Historique, score et réussite.", "Verlauf, Punkte und Trefferquote."), "📊", Stats_Click);
            Tile(T("Configurações", "Settings", "Configuración", "Paramètres", "Einstellungen"), T("Idioma, tema, cores e texto.", "Language, theme, colors and text.", "Idioma, tema, colores y texto.", "Langue, thème, couleurs et texte.", "Sprache, Design, Farben und Text."), "⚙", Settings_Click, false);
        }
        if (_current.Role == Role.Teacher)
        {
            Tile(T("Servidor/Professor", "Server/Teacher", "Servidor/Profesor", "Serveur/Professeur", "Server/Lehrer"), T("Inicia TCP/UDP para os alunos ligarem.", "Start TCP/UDP for students to connect.", "Inicia TCP/UDP para que conecten los alumnos.", "Démarre TCP/UDP pour les élèves.", "TCP/UDP für Schüler starten."), "🖥️", Teacher_Click);
            Tile(T("Configurações", "Settings", "Configuración", "Paramètres", "Einstellungen"), T("Idioma, tema, cores e texto.", "Language, theme, colors and text.", "Idioma, tema, colores y texto.", "Langue, thème, couleurs et texte.", "Sprache, Design, Farben und Text."), "⚙", Settings_Click, false);
        }
        Tile(T("Ranking Top 5", "Top 5 Ranking", "Ranking Top 5", "Top 5", "Top 5 Rangliste"), T("Acesso permitido a todos.", "Allowed for everyone.", "Permitido para todos.", "Autorisé pour tous.", "Für alle erlaubt."), "🏆", Ranking_Click, false);
        Tile(T("Regras", "Rules", "Reglas", "Règles", "Regeln"), T("Consulta permissões, níveis e pontuação.", "View permissions, levels and scoring.", "Consulta permisos, niveles y puntuación.", "Voir permissions, niveaux et score.", "Berechtigungen, Level und Punkte ansehen."), "📘", Rules_Click, false);
        ViewHost.Children.Add(wrap);
    }

    private void ShowGame()
    {
        if (_current?.Role != Role.Student) { MessageBox.Show(T("Só alunos autenticados podem jogar. Guest apenas vê Ranking Top 5 e Regras.", "Only authenticated students can play. Guest only sees Top 5 Ranking and Rules.", "Solo alumnos autenticados pueden jugar. Guest solo ve Ranking Top 5 y Reglas.", "Seuls les élèves connectés peuvent jouer. Guest voit seulement Top 5 et règles.", "Nur angemeldete Schüler können spielen. Guest sieht nur Top 5 und Regeln.")); ShowHome(); return; }
        Clear(); ViewHost.Children.Add(Txt(T("Escolher nível", "Choose level", "Elegir nivel", "Choisir niveau", "Level wählen"), 36, FontWeights.Black));
        var wrap = new WrapPanel { Margin = new Thickness(0, 18, 0, 0) };
        for (int i = 1; i <= 5; i++)
        {
            int level = i;
            var pts = QuestionGenerator.PointsForLevel(level);
            var sp = new StackPanel { Width = 225 };
            sp.Children.Add(Txt($"{T("Nível", "Level", "Nivel", "Niveau", "Level")} {i}", 24, FontWeights.Black));
            sp.Children.Add(Txt(LevelName(i), 14, null, "#9A94C7"));
            sp.Children.Add(Txt($"✅ +{pts.Correct} pts   ❌ {pts.Wrong} pts", 14, FontWeights.Bold, pts.Correct >= 40 ? "#FDE68A" : "#86EFAC"));
            sp.Children.Add(Txt(T("Perguntas aleatórias", "Random questions", "Preguntas aleatorias", "Questions aléatoires", "Zufällige Fragen"), 13, null, "#9A94C7"));
            sp.Children.Add(Btn(T("Começar 10 perguntas", "Start 10 questions", "Empezar 10 preguntas", "Commencer 10 questions", "10 Fragen starten"), (_, __) => StartLevel(level)));
            wrap.Children.Add(Card(sp, new Thickness(0, 0, 14, 14)));
        }
        ViewHost.Children.Add(wrap);
    }
    private void StartLevel(int level)
    {
        _sessionLevel = level;
        _sessionIndex = 0;
        _sessionScore = 0;
        _sessionQuestions = new Queue<Question>(_questions.GenerateSet(level, 10));
        AskNext();
    }

    private void AskNext()
    {
        if (_current?.Role != Role.Student) { ShowHome(); return; }
        if (_sessionQuestions.Count == 0)
        {
            Clear();
            var done = new StackPanel();
            done.Children.Add(Txt("🏁 " + T("Sessão terminada", "Session finished", "Sesión terminada", "Session terminée", "Sitzung beendet"), 36, FontWeights.Black));
            done.Children.Add(Txt($"{T("Nível", "Level", "Nivel", "Niveau", "Level")} {_sessionLevel} · 10 {T("perguntas", "questions", "preguntas", "questions", "Fragen")}", 18, FontWeights.Bold, "#9A94C7"));
            done.Children.Add(Txt($"{T("Pontuação nesta sessão", "Score this session", "Puntuación de esta sesión", "Score de cette session", "Punkte dieser Sitzung")}: {(_sessionScore >= 0 ? "+" : "")}{_sessionScore} pts", 28, FontWeights.Black, _sessionScore >= 0 ? "#86EFAC" : "#FCA5A5"));
            done.Children.Add(Btn(T("Escolher outro nível", "Choose another level", "Elegir otro nivel", "Choisir un autre niveau", "Anderes Level wählen"), (_, __) => ShowGame()));
            done.Children.Add(Btn(T("Ver ranking", "View ranking", "Ver ranking", "Voir classement", "Rangliste ansehen"), (_, __) => ShowRanking(), false));
            ViewHost.Children.Add(Card(done));
            return;
        }

        Clear();
        _currentQuestion = _sessionQuestions.Dequeue();
        _sessionIndex++;
        _questionStart = DateTime.Now;
        var sp = new StackPanel();
        sp.Children.Add(Txt($"{T("Nível", "Level", "Nivel", "Niveau", "Level")} {_sessionLevel} · {LevelName(_sessionLevel)}", 15, FontWeights.Bold, _settings.Accent));
        sp.Children.Add(Txt($"{T("Pergunta", "Question", "Pregunta", "Question", "Frage")} {_sessionIndex}/10 · ✅ +{_currentQuestion.PointsCorrect} pts · ❌ {_currentQuestion.PointsWrong} pts", 15, FontWeights.Bold, "#FDE68A"));
        sp.Children.Add(Txt(_currentQuestion.Text, 30, FontWeights.Black));
        for (int i = 0; i < _currentQuestion.Options.Count; i++)
        {
            int idx = i;
            sp.Children.Add(Btn($"{(char)('A' + i)}  {_currentQuestion.Options[i]}", (_, __) => Answer(idx), false));
        }
        ViewHost.Children.Add(Card(sp));
    }

    private async void Answer(int idx)
    {
        if (_currentQuestion is null || _current is null) return;
        var ok = idx == _currentQuestion.CorrectIndex;
        var secs = Math.Max(1, (int)(DateTime.Now - _questionStart).TotalSeconds);
        var pts = ok ? _currentQuestion.PointsCorrect : _currentQuestion.PointsWrong;
        _sessionScore += pts;

        var attempt = new Attempt { Username = _current.Username, Level = _currentQuestion.Level, Question = _currentQuestion.Text, Answer = _currentQuestion.Options[idx], Correct = ok, DurationSeconds = secs, Date = DateTime.Now };
        var attempts = _store.Attempts;
        attempts.Add(attempt);
        _store.Attempts = attempts;

        var scores = _store.Scores;
        scores.Add(new ScoreEntry { Username = _current.Username, Score = pts, Correct = ok ? 1 : 0, Total = 1, Date = attempt.Date });
        _store.Scores = scores;

        await SendAttemptToServerAsync(attempt, pts);

        Clear();
        var sp = new StackPanel();
        sp.Children.Add(Txt(ok ? "✅ " + T("Correto", "Correct", "Correcto", "Correct", "Richtig") : "❌ " + T("Errado", "Wrong", "Incorrecto", "Faux", "Falsch"), 34, FontWeights.Black, ok ? "#86EFAC" : "#FCA5A5"));
        sp.Children.Add(Txt($"{T("Pontuação desta pergunta", "Score for this question", "Puntuación de esta pregunta", "Points de cette question", "Punkte für diese Frage")}: {(pts > 0 ? "+" : "")}{pts} pts", 20, FontWeights.Black, pts > 0 ? "#86EFAC" : "#FCA5A5"));
        sp.Children.Add(Txt($"{T("Progresso", "Progress", "Progreso", "Progression", "Fortschritt")}: {_sessionIndex}/10 · {T("Total da sessão", "Session total", "Total de la sesión", "Total session", "Sitzung gesamt")}: {(_sessionScore >= 0 ? "+" : "")}{_sessionScore} pts", 16, FontWeights.Bold, "#FDE68A"));
        sp.Children.Add(Txt(_currentQuestion.Explanation, 17, null, "#9A94C7"));
        sp.Children.Add(Btn(_sessionQuestions.Count == 0 ? T("Terminar sessão", "Finish session", "Terminar sesión", "Finir session", "Sitzung beenden") : T("Próxima pergunta", "Next question", "Siguiente pregunta", "Question suivante", "Nächste Frage"), (_, __) => AskNext()));
        ViewHost.Children.Add(Card(sp));
    }

    private async Task SendAttemptToServerAsync(Attempt attempt, int points)
    {
        if (!_connectionOk || _server.IsRunning) return;
        try
        {
            var dto = new NetworkAttemptDto
            {
                Username = attempt.Username,
                Level = attempt.Level,
                Question = attempt.Question,
                Answer = attempt.Answer,
                Correct = attempt.Correct,
                DurationSeconds = attempt.DurationSeconds,
                Score = points,
                Date = attempt.Date
            };
            var json = JsonSerializer.Serialize(dto);
            var line = "SUBMIT\t" + Convert.ToBase64String(Encoding.UTF8.GetBytes(json));

            if (_connectedProtocol == ProtocolMode.TCP)
            {
                using var tcp = new TcpClient();
                await tcp.ConnectAsync(_connectedHost, _connectedPort);
                using var stream = tcp.GetStream();
                using var writer = new StreamWriter(stream, Encoding.UTF8, leaveOpen: true) { AutoFlush = true };
                using var reader = new StreamReader(stream, Encoding.UTF8, leaveOpen: true);
                await writer.WriteLineAsync(line);
                await reader.ReadLineAsync();
            }
            else
            {
                using var udp = new UdpClient();
                var data = Encoding.UTF8.GetBytes(line);
                await udp.SendAsync(data, data.Length, _connectedHost, _connectedPort);
                var receive = udp.ReceiveAsync();
                await Task.WhenAny(receive, Task.Delay(1200));
            }
        }
        catch
        {
            // A resposta fica guardada localmente mesmo se a rede falhar.
        }
    }

    private async Task<List<RankingDto>?> TryFetchRankingFromServerAsync()
    {
        if (!_connectionOk || _server.IsRunning) return null;
        try
        {
            string response;
            if (_connectedProtocol == ProtocolMode.TCP)
            {
                using var tcp = new TcpClient();
                await tcp.ConnectAsync(_connectedHost, _connectedPort);
                using var stream = tcp.GetStream();
                using var writer = new StreamWriter(stream, Encoding.UTF8, leaveOpen: true) { AutoFlush = true };
                using var reader = new StreamReader(stream, Encoding.UTF8, leaveOpen: true);
                await writer.WriteLineAsync("RANKING");
                response = await reader.ReadLineAsync() ?? string.Empty;
            }
            else
            {
                using var udp = new UdpClient();
                var data = Encoding.UTF8.GetBytes("RANKING");
                await udp.SendAsync(data, data.Length, _connectedHost, _connectedPort);
                var receive = udp.ReceiveAsync();
                if (await Task.WhenAny(receive, Task.Delay(1500)) != receive) return null;
                response = Encoding.UTF8.GetString(receive.Result.Buffer);
            }

            if (!response.StartsWith("RANKING\t", StringComparison.OrdinalIgnoreCase)) return null;
            var json = Encoding.UTF8.GetString(Convert.FromBase64String(response[8..]));
            return JsonSerializer.Deserialize<List<RankingDto>>(json);
        }
        catch { return null; }
    }

    private async void ShowRanking()
    {
        Clear();
        ViewHost.Children.Add(Txt("🏆 " + T("Ranking Top 5", "Top 5 Ranking", "Ranking Top 5", "Top 5", "Top 5 Rangliste"), 36, FontWeights.Black));
        var remote = await TryFetchRankingFromServerAsync();
        var sp = new StackPanel();
        if (remote is not null)
            sp.Children.Add(Txt(T("Ranking recebido do servidor do professor.", "Ranking received from the teacher server.", "Ranking recibido del servidor del profesor.", "Classement reçu du serveur du professeur.", "Rangliste vom Lehrer-Server empfangen."), 15, FontWeights.Bold, "#86EFAC"));
        var list = remote ?? _store.Scores
            .GroupBy(s => s.Username)
            .Select(g => new RankingDto { Username = g.Key, Score = g.Sum(x => x.Score), Total = g.Sum(x => x.Total), Correct = g.Sum(x => x.Correct) })
            .OrderByDescending(x => x.Score)
            .Take(5)
            .ToList();
        int pos = 1;
        foreach (var e in list) sp.Children.Add(Txt($"#{pos++}  {e.Username} — {e.Score} pts · {e.Total} {T("perguntas", "questions", "preguntas", "questions", "Fragen")} · {e.Correct} {T("certas", "correct", "correctas", "correctes", "richtig")}", 22, FontWeights.Bold));
        if (!list.Any()) sp.Children.Add(Txt(T("Ainda não existem pontuações.", "No scores yet.", "Aún no hay puntuaciones.", "Pas encore de scores.", "Noch keine Punkte."), 18, null, "#9A94C7"));
        ViewHost.Children.Add(Card(sp));
    }

    private void ShowStats()
    {
        if (_current?.Role != Role.Student) { MessageBox.Show(T("Estatísticas pessoais só para alunos autenticados.", "Personal statistics are only for authenticated students.", "Estadísticas personales solo para alumnos autenticados.", "Statistiques personnelles seulement pour élèves connectés.", "Persönliche Statistiken nur für angemeldete Schüler.")); ShowHome(); return; }
        Clear(); ViewHost.Children.Add(Txt("📊 " + T("Minhas estatísticas", "My statistics", "Mis estadísticas", "Mes statistiques", "Meine Statistiken"), 36, FontWeights.Black));
        var mine = _store.Attempts.Where(a => a.Username.Equals(_current.Username, StringComparison.OrdinalIgnoreCase)).OrderByDescending(a => a.Date).ToList();
        var score = _store.Scores.Where(a => a.Username.Equals(_current.Username, StringComparison.OrdinalIgnoreCase)).Sum(a => a.Score); var correct = mine.Count(a => a.Correct); var total = mine.Count; var accuracy = total == 0 ? 0 : Math.Round(correct * 100.0 / total, 1);
        var sp = new StackPanel(); sp.Children.Add(Txt($"{T("Score total", "Total score", "Puntuación total", "Score total", "Gesamtpunktzahl")}: {score} pts", 24, FontWeights.Black)); sp.Children.Add(Txt($"{T("Perguntas respondidas", "Answered questions", "Preguntas respondidas", "Questions répondues", "Beantwortete Fragen")}: {total}", 19, FontWeights.Bold)); sp.Children.Add(Txt($"{T("Taxa de acerto", "Accuracy", "Tasa de acierto", "Taux de réussite", "Trefferquote")}: {accuracy}%", 19, FontWeights.Bold));
        sp.Children.Add(Txt(T("Histórico recente", "Recent history", "Histórico reciente", "Historique récent", "Aktueller Verlauf"), 24, FontWeights.Black));
        if (!mine.Any()) sp.Children.Add(Txt(T("Ainda não respondeste a perguntas.", "You have not answered questions yet.", "Aún no has respondido preguntas.", "Tu n'as pas encore répondu.", "Du hast noch keine Fragen beantwortet."), 16, null, "#9A94C7"));
        foreach (var a in mine.Take(12)) { sp.Children.Add(Txt($"{a.Date:g} · {T("Nível", "Level", "Nivel", "Niveau", "Level")} {a.Level} · {(a.Correct ? T("correto", "correct", "correcto", "correct", "richtig") : T("errado", "wrong", "incorrecto", "faux", "falsch"))} · {a.DurationSeconds}s", 15, FontWeights.Bold, a.Correct ? "#86EFAC" : "#FCA5A5")); sp.Children.Add(Txt(a.Question, 13, null, "#9A94C7")); }
        ViewHost.Children.Add(Card(sp));
    }

    private void ShowRules()
    {
        Clear(); ViewHost.Children.Add(Txt("📘 " + T("Regras do jogo", "Game rules", "Reglas del juego", "Règles du jeu", "Spielregeln"), 36, FontWeights.Black));
        var sp = new StackPanel();
        sp.Children.Add(Txt(T("Permissões", "Permissions", "Permisos", "Permissions", "Berechtigungen"), 24, FontWeights.Black));
        sp.Children.Add(Txt(T("Guest: apenas Ranking Top 5 e Regras. Aluno autenticado: jogar, score, histórico e estatísticas. Professor: criar sessão TCP/UDP e consultar relatórios.", "Guest: only Top 5 Ranking and Rules. Authenticated student: play, score, history and statistics. Teacher: create TCP/UDP session and view reports.", "Guest: solo Ranking Top 5 y Reglas. Alumno autenticado: jugar, puntuación, historial y estadísticas. Profesor: crear sesión TCP/UDP y ver informes.", "Guest : seulement Top 5 et règles. Élève connecté : jouer, score, historique et statistiques. Professeur : créer session TCP/UDP et voir rapports.", "Guest: nur Top 5 und Regeln. Schüler: spielen, Punkte, Verlauf und Statistiken. Lehrer: TCP/UDP-Sitzung erstellen und Berichte ansehen."), 16, null, "#9A94C7"));
        sp.Children.Add(Txt(T("Níveis", "Levels", "Niveles", "Niveaux", "Level"), 24, FontWeights.Black));
        for (int i=1;i<=5;i++)
        {
            var pts = QuestionGenerator.PointsForLevel(i);
            sp.Children.Add(Txt($"{i}. {LevelName(i)} — ✅ +{pts.Correct} pts / ❌ {pts.Wrong} pts", 16, FontWeights.Bold, "#9A94C7"));
        }
        sp.Children.Add(Txt(T("Perguntas", "Questions", "Preguntas", "Questions", "Fragen"), 24, FontWeights.Black));
        sp.Children.Add(Txt(T("Cada nível tem 10 perguntas aleatórias. Quando o aluno acerta ou erra, o jogo mostra o feedback e passa para a próxima pergunta. As respostas ficam guardadas para ranking, histórico e relatórios do professor.", "Each level has 10 random questions. When the student is right or wrong, the game shows feedback and moves to the next question. Answers are stored for ranking, history and teacher reports.", "Cada nivel tiene 10 preguntas aleatorias. Cuando el alumno acierta o falla, el juego muestra feedback y pasa a la siguiente pregunta. Las respuestas se guardan para ranking, historial e informes del profesor.", "Chaque niveau contient 10 questions aléatoires. Après une bonne ou mauvaise réponse, le jeu affiche le feedback et passe à la question suivante. Les réponses sont enregistrées pour le classement, l’historique et les rapports du professeur.", "Jedes Level hat 10 zufällige Fragen. Nach richtiger oder falscher Antwort zeigt das Spiel Feedback und geht zur nächsten Frage. Antworten werden für Rangliste, Verlauf und Lehrerberichte gespeichert."), 16, null, "#9A94C7"));
        sp.Children.Add(Txt(T("Rede", "Network", "Red", "Réseau", "Netzwerk"), 24, FontWeights.Black));
        sp.Children.Add(Txt(T("O professor deve iniciar o servidor no painel Servidor/Professor. O aluno testa a ligação no ecrã de entrada com IP/porta/protocolo.", "The teacher must start the server in Server/Teacher. The student tests the connection on the entry screen with IP/port/protocol.", "El profesor debe iniciar el servidor en Servidor/Profesor. El alumno prueba la conexión en la pantalla de entrada con IP/puerto/protocolo.", "Le professeur démarre le serveur dans Serveur/Professeur. L'élève teste la connexion à l'entrée avec IP/port/protocole.", "Der Lehrer startet den Server unter Server/Lehrer. Der Schüler testet die Verbindung am Startbildschirm mit IP/Port/Protokoll."), 16, null, "#9A94C7"));
        ViewHost.Children.Add(Card(sp));
    }

    private void ShowTeacher()
    {
        if (_current is null || _current.Role != Role.Teacher)
        {
            MessageBox.Show(T("Entra como professor para ligar o servidor.", "Sign in as teacher to start the server.", "Entra como profesor para iniciar el servidor.", "Connecte-toi comme professeur pour démarrer le serveur.", "Melde dich als Lehrer an, um den Server zu starten."));
            ShowLogin();
            return;
        }

        Clear();
        var localIp = GetLocalIpAddress();
        ViewHost.Children.Add(Txt("🖥️ " + T("Servidor / Professor", "Server / Teacher", "Servidor / Profesor", "Serveur / Professeur", "Server / Lehrer"), 32, FontWeights.Black));
        ViewHost.Children.Add(Txt(T("Painel principal para iniciar a sessão de rede. Sem isto, os alunos não conseguem testar a ligação TCP/UDP.", "Main panel to start the network session. Without this, students cannot test the TCP/UDP connection.", "Panel principal para iniciar la sesión de red. Sin esto, los alumnos no pueden probar TCP/UDP.", "Panneau principal pour démarrer la session réseau. Sans cela, les élèves ne peuvent pas tester TCP/UDP.", "Hauptbereich zum Starten der Netzwerksitzung. Ohne dies können Schüler TCP/UDP nicht testen."), 16, FontWeights.Bold, "#FDE68A"));

        var grid = new Grid { Margin = new Thickness(0, 18, 0, 0) };
        grid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1.1, GridUnitType.Star) });
        grid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(0.9, GridUnitType.Star) });

        var left = new StackPanel { Margin = new Thickness(0, 0, 18, 0) };
        var status = Txt(_server.IsRunning
            ? "🟢 " + T("Servidor ligado", "Server running", "Servidor activo", "Serveur actif", "Server aktiv")
            : "🔴 " + T("Servidor desligado", "Server off", "Servidor apagado", "Serveur arrêté", "Server aus"),
            18, FontWeights.Bold, _server.IsRunning ? "#86EFAC" : "#FCA5A5");

        var tcp = Input(_lastTcpPort.ToString());
        var udp = Input(_lastUdpPort.ToString());
        tcp.FontSize = 16; tcp.FontWeight = FontWeights.SemiBold; tcp.Height = 42;
        udp.FontSize = 16; udp.FontWeight = FontWeights.SemiBold; udp.Height = 42;

        var serverCard = new StackPanel();
        serverCard.Children.Add(Txt("🚀 " + T("Ligar servidor", "Start server", "Iniciar servidor", "Démarrer serveur", "Server starten"), 24, FontWeights.Black));
        serverCard.Children.Add(status);
        serverCard.Children.Add(Txt(T("Endereço para alunos no mesmo computador", "Address for students on the same computer", "Dirección para alumnos en el mismo ordenador", "Adresse pour élèves sur le même PC", "Adresse für Schüler am gleichen PC"), 14, FontWeights.Bold, "#9A94C7"));
        serverCard.Children.Add(Txt($"127.0.0.1", 18, FontWeights.Black, _settings.Accent));
        serverCard.Children.Add(Txt(T("Endereço para alunos noutro computador da mesma rede", "Address for students on another computer in the same network", "Dirección para alumnos en otro ordenador de la misma red", "Adresse pour élèves sur un autre PC du même réseau", "Adresse für Schüler auf anderem PC im selben Netzwerk"), 14, FontWeights.Bold, "#9A94C7"));
        serverCard.Children.Add(Txt(localIp, 18, FontWeights.Black, _settings.Accent));

        var portGrid = new Grid();
        portGrid.ColumnDefinitions.Add(new ColumnDefinition());
        portGrid.ColumnDefinitions.Add(new ColumnDefinition());
        var tcpBox = new StackPanel { Margin = new Thickness(0, 0, 10, 0) };
        tcpBox.Children.Add(Txt("TCP", 16, FontWeights.Black, "#9A94C7")); tcpBox.Children.Add(tcp);
        var udpBox = new StackPanel { Margin = new Thickness(10, 0, 0, 0) };
        udpBox.Children.Add(Txt("UDP", 16, FontWeights.Black, "#9A94C7")); udpBox.Children.Add(udp);
        Grid.SetColumn(tcpBox, 0); Grid.SetColumn(udpBox, 1); portGrid.Children.Add(tcpBox); portGrid.Children.Add(udpBox);
        serverCard.Children.Add(portGrid);

        var startBtn = Btn("▶  " + T("Ligar servidor TCP/UDP", "Start TCP/UDP server", "Iniciar servidor TCP/UDP", "Démarrer serveur TCP/UDP", "TCP/UDP-Server starten"), (_, __) =>
        {
            if (!int.TryParse(tcp.Text.Trim(), out var t) || !int.TryParse(udp.Text.Trim(), out var u) || t <= 0 || u <= 0 || t > 65535 || u > 65535)
            {
                MessageBox.Show(T("As portas devem estar entre 1 e 65535.", "Ports must be between 1 and 65535.", "Los puertos deben estar entre 1 y 65535.", "Les ports doivent être entre 1 et 65535.", "Ports müssen zwischen 1 und 65535 liegen."));
                return;
            }
            try
            {
                if (_server.IsRunning) _server.Stop();
                _lastTcpPort = t; _lastUdpPort = u;
                _server.Start(t, u);
                status.Text = "🟢 " + T("Servidor ligado", "Server running", "Servidor activo", "Serveur actif", "Server aktiv");
                status.Foreground = SafeBrush("#86EFAC");
                _serverLog?.Items.Insert(0, $"{DateTime.Now:HH:mm:ss}  {T("Servidor ligado", "Server started", "Servidor iniciado", "Serveur démarré", "Server gestartet")} TCP {t} / UDP {u}");
                ApplySettings();
                MessageBox.Show(T($"Servidor ligado. Alunos usam IP 127.0.0.1 ou {localIp}, TCP {t}, UDP {u}.", $"Server started. Students use IP 127.0.0.1 or {localIp}, TCP {t}, UDP {u}.", $"Servidor iniciado. Alumnos usan IP 127.0.0.1 o {localIp}, TCP {t}, UDP {u}.", $"Serveur démarré. Élèves utilisent IP 127.0.0.1 ou {localIp}, TCP {t}, UDP {u}.", $"Server gestartet. Schüler nutzen IP 127.0.0.1 oder {localIp}, TCP {t}, UDP {u}."));
            }
            catch (Exception ex)
            {
                MessageBox.Show(T("Não foi possível ligar o servidor. Verifica se a porta já está ocupada. Erro: ", "Could not start the server. Check if the port is already in use. Error: ", "No fue posible iniciar el servidor. Comprueba si el puerto está ocupado. Error: ", "Impossible de démarrer le serveur. Vérifie si le port est déjà utilisé. Erreur : ", "Server konnte nicht gestartet werden. Prüfe, ob der Port belegt ist. Fehler: ") + ex.Message);
            }
        });
        startBtn.FontSize = 15; startBtn.MinHeight = 48;
        serverCard.Children.Add(startBtn);
        serverCard.Children.Add(Btn("⏹  " + T("Desligar servidor", "Stop server", "Parar servidor", "Arrêter serveur", "Server stoppen"), (_, __) =>
        {
            _server.Stop();
            status.Text = "🔴 " + T("Servidor desligado", "Server off", "Servidor apagado", "Serveur arrêté", "Server aus");
            status.Foreground = SafeBrush("#FCA5A5");
            _serverLog?.Items.Insert(0, $"{DateTime.Now:HH:mm:ss}  {T("Servidor desligado", "Server stopped", "Servidor parado", "Serveur arrêté", "Server gestoppt")}");
            ApplySettings();
        }, false));
        left.Children.Add(Card(serverCard));

        var how = new StackPanel();
        how.Children.Add(Txt("📌 " + T("Como o aluno liga", "How the student connects", "Cómo conecta el alumno", "Connexion de l'élève", "So verbindet sich der Schüler"), 24, FontWeights.Black));
        how.Children.Add(Txt(T("1. Professor clica em Ligar servidor TCP/UDP.", "1. Teacher clicks Start TCP/UDP server.", "1. El profesor hace clic en Iniciar servidor TCP/UDP.", "1. Le professeur clique sur Démarrer serveur TCP/UDP.", "1. Lehrer klickt TCP/UDP-Server starten."), 16, FontWeights.Bold));
        how.Children.Add(Txt(T("2. Aluno abre a app, coloca IP/Host e porta.", "2. Student opens the app and enters IP/Host and port.", "2. El alumno abre la app e introduce IP/Host y puerto.", "2. L'élève ouvre l'app et saisit IP/Host et port.", "2. Schüler öffnet die App und gibt IP/Host und Port ein."), 16, FontWeights.Bold));
        how.Children.Add(Txt(T("3. Aluno clica em Testar ligação e depois faz login/registo.", "3. Student clicks Test connection and then signs in/registers.", "3. El alumno prueba la conexión y luego inicia sesión/registro.", "3. L'élève teste la connexion puis se connecte/s'inscrit.", "3. Schüler testet die Verbindung und meldet sich an/registriert sich."), 16, FontWeights.Bold));
        left.Children.Add(Card(how));
        Grid.SetColumn(left, 0); grid.Children.Add(left);

        var right = new StackPanel();
        right.Children.Add(Txt("📡 " + T("Atividade do servidor", "Server activity", "Actividad del servidor", "Activité du serveur", "Serveraktivität"), 26, FontWeights.Black));
        _serverLog = new ListBox
        {
            Height = 300,
            Background = SafeBrush(Blend(_settings.Card, "#000000", 0.35), "#0D0B26"),
            Foreground = Brushes.White,
            BorderThickness = new Thickness(0),
            Padding = new Thickness(10)
        };
        if (_server.IsRunning) _serverLog.Items.Insert(0, $"{DateTime.Now:HH:mm:ss}  {T("Servidor ativo", "Server active", "Servidor activo", "Serveur actif", "Server aktiv")} TCP {_lastTcpPort} / UDP {_lastUdpPort}");
        right.Children.Add(_serverLog);

        var reports = new StackPanel();
        reports.Children.Add(Txt("📊 " + T("Relatórios rápidos", "Quick reports", "Informes rápidos", "Rapports rapides", "Schnellberichte"), 24, FontWeights.Black));
        reports.Children.Add(Txt($"{T("Tentativas registadas", "Registered attempts", "Intentos registrados", "Tentatives enregistrées", "Registrierte Versuche")}: {_store.Attempts.Count}", 18, FontWeights.Bold));
        reports.Children.Add(Txt($"{T("Jogadores com pontuação", "Players with score", "Jugadores con puntuación", "Joueurs avec score", "Spieler mit Punkten")}: {_store.Scores.Select(s => s.Username).Distinct().Count()}", 18, FontWeights.Bold));
        var recentAttempts = _store.Attempts.OrderByDescending(a => a.Date).Take(8).ToList();
        reports.Children.Add(Txt(T("Últimas respostas recebidas", "Latest received answers", "Últimas respuestas recibidas", "Dernières réponses reçues", "Letzte empfangene Antworten"), 20, FontWeights.Black));
        if (!recentAttempts.Any())
            reports.Children.Add(Txt(T("Ainda não há respostas dos alunos.", "No student answers yet.", "Aún no hay respuestas de alumnos.", "Pas encore de réponses des élèves.", "Noch keine Schülerantworten."), 14, null, "#9A94C7"));
        foreach (var a in recentAttempts)
            reports.Children.Add(Txt($"{a.Date:HH:mm} · {a.Username} · {T("Nível", "Level", "Nivel", "Niveau", "Level")} {a.Level} · {(a.Correct ? T("certa", "correct", "correcta", "correcte", "richtig") : T("errada", "wrong", "incorrecta", "fausse", "falsch"))}", 14, FontWeights.Bold, a.Correct ? "#86EFAC" : "#FCA5A5"));
        reports.Children.Add(Btn(T("Atualizar relatórios", "Refresh reports", "Actualizar informes", "Actualiser rapports", "Berichte aktualisieren"), (_, __) => ShowTeacher(), false));
        right.Children.Add(Card(reports, new Thickness(0, 18, 0, 0)));
        Grid.SetColumn(right, 1); grid.Children.Add(right);
        ViewHost.Children.Add(grid);
    }

    private void ShowSettings()
    {
        if (_current is null || _current.Role == Role.Guest) { MessageBox.Show(T("Configurações só disponíveis após login/registo.", "Settings are only available after login/register.", "Configuración solo disponible tras iniciar sesión/registro.", "Paramètres disponibles seulement après connexion/inscription.", "Einstellungen nur nach Anmeldung/Registrierung verfügbar.")); ShowHome(); return; }
        Clear(); ViewHost.Children.Add(Txt("⚙ " + T("Configurações", "Settings", "Configuración", "Paramètres", "Einstellungen"), 36, FontWeights.Black));
        var root = new StackPanel();
        var langItems = new Dictionary<AppLanguage,string> { [AppLanguage.PT]="Português", [AppLanguage.EN]="English", [AppLanguage.ES]="Español", [AppLanguage.FR]="Français", [AppLanguage.DE]="Deutsch" };
        var lang = new ComboBox { Height = 42, Margin = new Thickness(0, 4, 0, 12), ItemsSource = langItems, DisplayMemberPath="Value", SelectedValuePath="Key", SelectedValue = _settings.Language };
        var size = new Slider { Minimum = 12, Maximum = 24, Value = _settings.FontSize, TickFrequency = 1, IsSnapToTickEnabled = true, Margin = new Thickness(0, 6, 0, 16) };
        var sizeLabel = Txt($"{T("Tamanho do texto", "Text size", "Tamaño del texto", "Taille du texte", "Textgröße")}: {_settings.FontSize:0}", 14, FontWeights.Bold, "#9A94C7");
        size.ValueChanged += (_, __) => sizeLabel.Text = $"{T("Tamanho do texto", "Text size", "Tamaño del texto", "Taille du texte", "Textgröße")}: {size.Value:0}";
        root.Children.Add(Txt(T("Idioma da aplicação", "Application language", "Idioma de la aplicación", "Langue de l'application", "App-Sprache"), 14, FontWeights.Bold, "#9A94C7")); root.Children.Add(lang); root.Children.Add(sizeLabel); root.Children.Add(size);
        root.Children.Add(Txt(T("Temas rápidos", "Quick themes", "Temas rápidos", "Thèmes rapides", "Schnelle Designs"), 22, FontWeights.Black));
        var themeWrap = new WrapPanel { Margin = new Thickness(0, 4, 0, 18) };
        foreach (var kv in _themes)
        {
            var name = kv.Key; var colors = kv.Value;
            var tile = new Button { Width = 180, Height = 92, Margin = new Thickness(0, 0, 12, 12), Background = SafeBrush(colors.Card), BorderBrush = SafeBrush(colors.Accent), BorderThickness = new Thickness(2), Cursor = System.Windows.Input.Cursors.Hand };
            tile.Content = new StackPanel { Children = { Txt(name, 15, FontWeights.Black), new Border { Height = 14, Background = SafeBrush(colors.Button), CornerRadius = new CornerRadius(7), Margin = new Thickness(0, 6, 0, 0) } } };
            tile.Click += (_, __) => { _settings.Background = colors.Bg; _settings.Card = colors.Card; _settings.Button = colors.Button; _settings.Accent = colors.Accent; _store.Settings = _settings; ApplySettings(); ShowSettings(); };
            themeWrap.Children.Add(tile);
        }
        root.Children.Add(themeWrap);
        root.Children.Add(Txt(T("Cores personalizadas", "Custom colors", "Colores personalizados", "Couleurs personnalisées", "Benutzerdefinierte Farben"), 22, FontWeights.Black));
        root.Children.Add(Txt(T("Usa o formato #RRGGBB. A pré-visualização avisa se o valor estiver inválido e não fecha o programa.", "Use #RRGGBB. Preview warns if a value is invalid and will not close the program.", "Usa #RRGGBB. La vista previa avisa si el valor es inválido y no cierra el programa.", "Utilise #RRGGBB. L'aperçu avertit si la valeur est invalide et ne ferme pas le programme.", "Verwende #RRGGBB. Die Vorschau warnt bei ungültigem Wert und beendet das Programm nicht."), 14, null, "#9A94C7"));
        var bg = Input(_settings.Background); var card = Input(_settings.Card); var btn = Input(_settings.Button); var accent = Input(_settings.Accent); var error = Txt("", 14, FontWeights.Bold, "#FCA5A5");
        AddColorField(root, T("Fundo", "Background", "Fondo", "Fond", "Hintergrund"), bg); AddColorField(root, T("Cartões", "Cards", "Tarjetas", "Cartes", "Karten"), card); AddColorField(root, T("Botões", "Buttons", "Botones", "Boutons", "Schaltflächen"), btn); AddColorField(root, T("Destaque", "Accent", "Destacado", "Accent", "Akzent"), accent);
        root.Children.Add(Btn(T("Guardar e aplicar tudo", "Save and apply all", "Guardar y aplicar todo", "Enregistrer et appliquer", "Speichern und anwenden"), (_, __) =>
        {
            var values = new[] { bg.Text, card.Text, btn.Text, accent.Text };
            if (values.Any(v => !IsValidHex(v))) { error.Text = T("Há cores inválidas. Usa #RRGGBB, exemplo #7C3AED.", "Invalid colors. Use #RRGGBB, example #7C3AED.", "Hay colores inválidos. Usa #RRGGBB, ejemplo #7C3AED.", "Couleurs invalides. Utilise #RRGGBB, exemple #7C3AED.", "Ungültige Farben. Nutze #RRGGBB, Beispiel #7C3AED."); return; }
            _settings.Language = (AppLanguage)lang.SelectedValue; _settings.Background = bg.Text.Trim(); _settings.Card = card.Text.Trim(); _settings.Button = btn.Text.Trim(); _settings.Accent = accent.Text.Trim(); _settings.FontSize = size.Value; _store.Settings = _settings; ApplySettings(); ShowSettings();
        }));
        root.Children.Add(Btn(T("Repor tema padrão", "Reset default theme", "Restablecer tema", "Réinitialiser thème", "Design zurücksetzen"), (_, __) => { _settings = new AppSettings(); _store.Settings = _settings; ApplySettings(); ShowSettings(); }, false)); root.Children.Add(error);
        ViewHost.Children.Add(Card(root));
    }

    private void AddColorField(StackPanel root, string label, TextBox box)
    {
        root.Children.Add(Txt(label + " (#RRGGBB)", 14, FontWeights.Bold, "#9A94C7"));
        var row = new DockPanel(); var swatch = new Border { Width = 42, Height = 42, CornerRadius = new CornerRadius(12), Background = SafeBrush(box.Text), Margin = new Thickness(0, 4, 10, 12) }; DockPanel.SetDock(swatch, Dock.Left); row.Children.Add(swatch); row.Children.Add(box);
        box.TextChanged += (_, __) => { swatch.Background = IsValidHex(box.Text) ? SafeBrush(box.Text) : SafeBrush("#EF4444"); };
        root.Children.Add(row); var presets = new WrapPanel { Margin = new Thickness(0, -6, 0, 8) };
        foreach (var c in new[] { "#07061A", "#12103A", "#7C3AED", "#06B6D4", "#2563EB", "#16A34A", "#F4F7FB", "#FFFFFF", "#111827", "#E11D48", "#F59E0B", "#EC4899" }) { var b = new Button { Width = 28, Height = 28, Background = SafeBrush(c), BorderBrush = Brushes.White, BorderThickness = new Thickness(1), Margin = new Thickness(0, 0, 6, 6), ToolTip = c }; b.Click += (_, __) => box.Text = c; presets.Children.Add(b); }
        root.Children.Add(presets);
    }

    private void Home_Click(object s, RoutedEventArgs e) => ShowHome();
    private void Game_Click(object s, RoutedEventArgs e) => ShowGame();
    private void Ranking_Click(object s, RoutedEventArgs e) => ShowRanking();
    private void Teacher_Click(object s, RoutedEventArgs e) => ShowTeacher();
    private void Stats_Click(object s, RoutedEventArgs e) => ShowStats();
    private void Rules_Click(object s, RoutedEventArgs e) => ShowRules();
    private void Settings_Click(object s, RoutedEventArgs e) => ShowSettings();
    private void Logout_Click(object s, RoutedEventArgs e) { _current = null; _connectionOk = false; UserBadge.Text = T("Sem sessão", "No session", "Sin sesión", "Sans session", "Keine Sitzung"); ApplySettings(); ShowLogin(); }
}
